<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="googlebot" content="noodp">
    <meta name="description" content="One  stop solution for engineering students">
    <meta name="keywords" content="GGSIPU,IPU,NotesHub,Notes,B.Tech,engg,engineering,study,material,books,question,paper,papers,practical,files,download,pdf,buy,sell,college,btech,quality,last,year,supplementary,note,notes,indraprastha,university,NotesHub,Computer,science,information,technology,mechanical,civil,electrical,electronics,cs,it,mae,me,eee,ece,cse,download,search,find">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">
    <meta name="theme-color" content="#ca2c2c">
    <link rel="manifest" href="/manifest.json">

    <title>NotesHub</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--<script src="preloader.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/css/preloader.css">-->
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Dont actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="dist/css/select2.css" rel="stylesheet">
    <link href="dist/css/select2-bootstrap.css" rel="stylesheet">
    <link href="dist/css/modify.css" rel="stylesheet">
    <link href="dist/css/buyBooks.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="dist/css/sellBooks.css">


    <link href="dist/css/carousel.css" rel="stylesheet">
    <link href="dist/css/index.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="dist/css/footer-basic-centered.css">

    <link href="tables/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="dist/css/datatables customization.css">

    <!--Google ads customization -->
    <link rel="stylesheet" type="text/css" href="dist/css/google ads customization.css">
    <!-- Google Analytics -->
	<script>
  	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  	ga('create', 'UA-86458385-1', 'auto');
  	ga('send', 'pageview');

	</script>

     <!--Google adsense -->
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
     <script>

     (adsbygoogle = window.adsbygoogle || []).push({
     google_ad_client: "ca-pub-6153632791841759",
     enable_page_level_ads: true
     });

      //install service worker
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
          navigator.serviceWorker.register('/sw.js').then(function(registration) {
            // Registration was successful
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
          }, function(err) {
            // registration failed :(
            console.log('ServiceWorker registration failed: ', err);
          });
        });
      }

     </script>

  </head>
<!-- NAVBAR
================================================== -->
  <body>
  <!--PRELOADER -->
    <!--<div id="preloader-container"">
    <div id="preloader-screen">
      <div class="preloader-content">
        <div class="row1">
          <span class="logo">  <img src="images/72.png"/>  </span>
          <span class="text"> NotesHub <span class=" highlighted-text">hai na...</span>  </span>
        </div>
        <div class="bar-container">
          <div class="bar">

          </div>
        </div>
        <div class="loading">Loading . . . <span id="load-percentage" class="highlighted-text">100</span>%</div>
      </div>
    </div>
    </div>-->

<!--APP LINK-->
	<a style="text-decoration:none; color: #fff;" href='https://goo.gl/RmUPsG' target='_blank'>
          <div style="background-color:#ca2c2c; text-align:center; color:#ffffff; width:100%;  position: fixed; z-index:100000; padding: 3px 0;">
            <span style="vertical-align:middle; white-space: nowrap;">Application now available on Google Play. Download now!</span>
          </div>
          </a>
    <!--NAVBAR-->
    <div class="navbar-wrapper">


      <div class="container">
           <nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" style="margin-top:25px;">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="search.php">NotesHub</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">


              <ul class="nav navbar-nav">
                <li><a href="search.php">Search</a></li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Download <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="notes.php">Notes</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="practicalFiles.php">Practical Files</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="questionPapers.php">Question Papers</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="eBooks.php">eBooks</a></li>

                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Books <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="buyBooks.php">Buy Books</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="sellBooks.php">Sell Books</a></li>
                  </ul>
                </li>

                <li><a href="videos.php">Video Tutorials</a></li>
                <!--<li><a href="#contact">Contact Us</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="team.php">Team</a></li>-->

              </ul>

              <ul class="nav navbar-nav navbar-right">
                                  <li><a href="#" data-toggle="modal" data-target="#signUp">Sign Up</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#userLogin">User Login</a></li>
                                </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>

	<!-- Wrap the rest of the page in another container to center all the content. -->
<link rel="stylesheet" type="text/css" href="dist/css/search.css">
<script src="dist/js/search.js"></script>
	<div class="search-banner">
		<div class="container center-content" style="position: relative; top:110px;padding-bottom: 140px;">
			<div class="searchbar-branding">
					<div class="searchbar-logo">
						<img src="images/192.png">
					</div>
					<div class="text-left">
						<p> NotesHub</p>
						<h1 style="font-size: 5em;">Search</h1>
						<p style="font-size: 1.1em;"> Find anything you need to study.</p>
					</div>	
			</div>
			<form class="" action="search-redirect.php" method="GET">
					<div class="searchbar-container">
						<div class="searchbar-wrapper">
						<input type="text" class="searchbar" name="searchquery" id="searchquery" placeholder="Enter Subject or Topic" autocomplete="off" required>
						<button type="submit" class="" id="search-button"><span class="glyphicon glyphicon-search"></span></button>
						</div>
						<div id="searchqueryList"></div>
					</div>
			</form>
			
		</div>
	</div>
	<div class="container center-content">
	
			<div id="searchresult" style="margin-top:5px;"></div>
	</div>
 <script>
 $(document).ready(function(){
	  $('#searchquery').keyup(function(e){
	  	var code= e.keycode | e.which;
	  	//alert(code);
	  	if(code!=38&&code!==40) { 
	  	//var e= $.Event('keyup'); e.which=code; $("#searchquery").trigger(e); 
		   var query = $(this).val();
		   if(query != '')
		   {
				$.ajax({
					 url:"search_autocomplete.php",
					 method:"POST",
					 data:{query:query},
					 success:function(data)
					 {
						  $('#searchqueryList').fadeIn();
						  $('#searchqueryList').html(data);
					 }
				});
		   }else if(query == ''){
			$('#searchqueryList').fadeOut();
		   }
	  }
	  });
	  
	  $(document).on('click', '#searchqueryList li', function(){
		   $('#searchquery').val($(this).text());
		   $('#searchqueryList').fadeOut();
		   $('#search-button').trigger('click'); // search on click
	  });
 });
 </script>
 <!--Modals-->

<!-- user login -->
<div class="modal fade"  id="userLogin" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">User Login</h4>
			</div>
			<form action="loginScript.php" method="post">
			<div class="modal-body">

					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword2">Password</label>
						<input required type="password" class="form-control" id="exampleInputPassword2" placeholder="Password" name="password">
						<span><a href="#" data-toggle="modal" data-target="#forgotPassword">Forgot Password?</a></span>

					</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Login</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- forgot password -->
<div class="modal fade"  id="forgotPassword" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Forgot Password?</h4>
			</div>
			<form action="recovery.php" method="post">
			<div class="modal-body">
					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Your registered email id" name="email">
					</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- signup -->
<div class="modal fade" id="signUp" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Sign Up</h4>
			</div>
			<form action = "register.php" method="post">
				<div class="modal-body">
					<div class="form-group">
						<label for="">Name</label>
						<input required type="text" name="name" pattern="[a-zA-Z]+[a-zA-Z ]*" class="form-control"  placeholder="Name (only letters and spaces are alllowed)">
					</div>

					<div class="form-group">
						<label for="">Email ID</label>
						<input required type="email" name="email" class="form-control" placeholder="Email">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input required type="password" name="password" minlength="8" maxlength="32" class="form-control" id="exampleInputPassword1" placeholder="Password (must be of at least 8 characters)">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Mobile Number</label>
						<input required type="tel" name="phno" pattern="[7-9]{1}[0-9]{9}" class="form-control" id="phoneNumber" placeholder="Mobile Number (must start with7, 8, or 9 and be of 10 digits)">
					</div>

					<div class="form-group">
					<label for="college">College</label>
					<select required name="college" class="form-control">
							<option value="" selected disabled>Select College</option>
							<option value="Ambedkar Institute of Advanced Communication Technologies and Research">Ambedkar Institute of Advanced Communication Technologies and Research</option><option value="Amity School of Engineering and Technology">Amity School of Engineering and Technology</option><option value="B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat">B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat</option><option value="Bhagwan Parshuram Institute of Technology">Bhagwan Parshuram Institute of Technology</option><option value="Bharati Vidyapeeth's College of Engineering">Bharati Vidyapeeth's College of Engineering</option><option value="Ch. B.P. Government Engineering College, Delhi">Ch. B.P. Government Engineering College, Delhi</option><option value="Delhi Technical Campus">Delhi Technical Campus</option><option value="Guru Tegh Bahadur Institute of Technology">Guru Tegh Bahadur Institute of Technology</option><option value="HMR Institute of Technology & Management">HMR Institute of Technology & Management</option><option value="JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)">JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)</option><option value="Maharaja Agrasen Institute of Technology">Maharaja Agrasen Institute of Technology</option><option value="Maharaja Surajmal Institute of Technology">Maharaja Surajmal Institute of Technology</option><option value="Northern India Engineering College">Northern India Engineering College</option><option value="University School of Information and Communication Technology">University School of Information and Communication Technology</option>					</select>
					</div>

					<div class="form-group">
					<label for="college">Branch</label>
					<select required name = "branch" class="form-control">
							<option value="" selected disabled>Select Branch</option>
							<option value="cse">CSE</option>
							<option value="it">IT</option>
							<option value="mae">MAE</option>
							<option value="civil">CIVIL</option>
							<option value="eee">EEE</option>
							<option value="ece">ECE</option>
					</select>
					</div>

					<div class="form-group">
					<label for="college">Nearest Metro Station</label>
					<select required name = "nms" class="form-control">
							<option value="" selected disabled>Select Nearest Metro Station</option>
							<option value="ADARSH NAGAR">ADARSH NAGAR</option><option value="AIIMS">AIIMS</option><option value="AKSHARDHAM">AKSHARDHAM</option><option value="ANAND VIHAR">ANAND VIHAR</option><option value="ARJANGARH">ARJANGARH</option><option value="ASHOK PARK MAIN">ASHOK PARK MAIN</option><option value="AZADPUR">AZADPUR</option><option value="BADARPUR">BADARPUR</option><option value="BADKAL MOR">BADKAL MOR</option><option value="BARAKHAMBA">BARAKHAMBA</option><option value="BATA CHOWK">BATA CHOWK</option><option value="BOTANICAL GARDEN">BOTANICAL GARDEN</option><option value="CENTRAL SECRETARIAT">CENTRAL SECRETARIAT</option><option value="CHANDNI CHOWK">CHANDNI CHOWK</option><option value="CHAWRI BAZAR">CHAWRI BAZAR</option><option value="CHHATTARPUR">CHHATTARPUR</option><option value="CIVIL LINES">CIVIL LINES</option><option value="DELHI AERO CITY">DELHI AERO CITY</option><option value="DELHI GATE">DELHI GATE</option><option value="DHAULA KUAN">DHAULA KUAN</option><option value="DILSHAD GARDEN">DILSHAD GARDEN</option><option value="DWARKA">DWARKA</option><option value="DWARKA MOR">DWARKA MOR</option><option value="DWARKA SEC 10">DWARKA SEC 10</option><option value="DWARKA SEC 11">DWARKA SEC 11</option><option value="DWARKA SEC 12">DWARKA SEC 12</option><option value="DWARKA SEC 13">DWARKA SEC 13</option><option value="DWARKA SEC 14">DWARKA SEC 14</option><option value="DWARKA SEC 21">DWARKA SEC 21</option><option value="DWARKA SEC 8">DWARKA SEC 8</option><option value="DWARKA SEC 9">DWARKA SEC 9</option><option value="ESCORTS MUJESAR">ESCORTS MUJESAR</option><option value="G.T.B. NAGAR">G.T.B. NAGAR</option><option value="GHITORNI">GHITORNI</option><option value="GOLF COURSE">GOLF COURSE</option><option value="GOVIND PURI">GOVIND PURI</option><option value="GREEN PARK">GREEN PARK</option><option value="GURU DRONACHARYA">GURU DRONACHARYA</option><option value="HAIDERPUR BADLI MOR">HAIDERPUR BADLI MOR</option><option value="HAUZ KHAS">HAUZ KHAS</option><option value="HUDA CITY CENTRE">HUDA CITY CENTRE</option><option value="I.G.I. AIRPORT">I.G.I. AIRPORT</option><option value="IFFCO CHOWK">IFFCO CHOWK</option><option value="INA">INA</option><option value="INDER LOK">INDER LOK</option><option value="INDRAPRASTHA">INDRAPRASTHA</option><option value="ITO">ITO</option><option value="JAHANGIRPURI">JAHANGIRPURI</option><option value="JAMA MASJID">JAMA MASJID</option><option value="JAMIA MILIA ISLAMIYA">JAMIA MILIA ISLAMIYA</option><option value="JANAK PURI EAST">JANAK PURI EAST</option><option value="JANAK PURI WEST">JANAK PURI WEST</option><option value="JANGPURA">JANGPURA</option><option value="JANPATH">JANPATH</option><option value="JASOLA APOLLO">JASOLA APOLLO</option><option value="JASOLA VIHAR">JASOLA VIHAR</option><option value="JHANDEWALAN">JHANDEWALAN</option><option value="JHIL MIL">JHIL MIL</option><option value="JLN STADIUM">JLN STADIUM</option><option value="JORBAGH">JORBAGH</option><option value="KAILASH COLONY">KAILASH COLONY</option><option value="KALINDI KUNJ">KALINDI KUNJ</option><option value="KALKAJI MANDIR">KALKAJI MANDIR</option><option value="KANHAIYA NAGAR">KANHAIYA NAGAR</option><option value="KARKAR DUMA">KARKAR DUMA</option><option value="KAROL BAGH">KAROL BAGH</option><option value="KASHMERE GATE">KASHMERE GATE</option><option value="KAUSHAMBI">KAUSHAMBI</option><option value="KESHAV PURAM">KESHAV PURAM</option><option value="KHAN MARKET">KHAN MARKET</option><option value="KIRTI NAGAR">KIRTI NAGAR</option><option value="KOHAT ENCLAVE">KOHAT ENCLAVE</option><option value="LAJPAT NAGAR">LAJPAT NAGAR</option><option value="LAL QUILA">LAL QUILA</option><option value="LAXMI NAGAR">LAXMI NAGAR</option><option value="LOK KALYAN MARG">LOK KALYAN MARG</option><option value="M G ROAD">M G ROAD</option><option value="MADI PUR">MADI PUR</option><option value="MALVIYA NAGAR">MALVIYA NAGAR</option><option value="MANDI HOUSE">MANDI HOUSE</option><option value="MANSAROVAR PARK">MANSAROVAR PARK</option><option value="MAYUR VIHAR-I">MAYUR VIHAR-I</option><option value="MAYUR VIHAR-I EXT">MAYUR VIHAR-I EXT</option><option value="MEWALA MAHARAJPUR">MEWALA MAHARAJPUR</option><option value="MODEL TOWN">MODEL TOWN</option><option value="MOHAN ESTATE">MOHAN ESTATE</option><option value="MOOLCHAND">MOOLCHAND</option><option value="MOTI NAGAR">MOTI NAGAR</option><option value="MUNDKA">MUNDKA</option><option value="NANGLOI">NANGLOI</option><option value="NANGLOI RLY. STATION">NANGLOI RLY. STATION</option><option value="NAWADA">NAWADA</option><option value="NEELAM CHOWK AJRONDA">NEELAM CHOWK AJRONDA</option><option value="NEHRU PLACE">NEHRU PLACE</option><option value="NETAJI SUBHASH PLACE">NETAJI SUBHASH PLACE</option><option value="NEW ASHOK NAGAR">NEW ASHOK NAGAR</option><option value="NEW DELHI">NEW DELHI</option><option value="NHPC CHOWK">NHPC CHOWK</option><option value="NIRMAN VIHAR">NIRMAN VIHAR</option><option value="NOIDA CITY CENTRE">NOIDA CITY CENTRE</option><option value="NOIDA SEC 15">NOIDA SEC 15</option><option value="NOIDA SEC 16">NOIDA SEC 16</option><option value="NOIDA SEC 18">NOIDA SEC 18</option><option value="NSIC OKHLA">NSIC OKHLA</option><option value="OKHLA">OKHLA</option><option value="OKHLA BIRD SANCTUARY">OKHLA BIRD SANCTUARY</option><option value="OKHLA VIHAR">OKHLA VIHAR</option><option value="OLD FARIDABAD">OLD FARIDABAD</option><option value="PASCHIM VIHAR (EAST)">PASCHIM VIHAR (EAST)</option><option value="PASCHIM VIHAR (WEST)">PASCHIM VIHAR (WEST)</option><option value="PATEL CHOWK">PATEL CHOWK</option><option value="PATEL NAGAR">PATEL NAGAR</option><option value="PEERA GARHI">PEERA GARHI</option><option value="PITAM PURA">PITAM PURA</option><option value="PRAGATI MAIDAN">PRAGATI MAIDAN</option><option value="PRATAP NAGAR">PRATAP NAGAR</option><option value="PREET VIHAR">PREET VIHAR</option><option value="PUL BANGASH">PUL BANGASH</option><option value="PUNJABI BAGH">PUNJABI BAGH</option><option value="QUTAB MINAR">QUTAB MINAR</option><option value="RAJDHANI PARK">RAJDHANI PARK</option><option value="RAJENDRA PLACE">RAJENDRA PLACE</option><option value="RAJIV CHOWK">RAJIV CHOWK</option><option value="RAJOURI GARDEN">RAJOURI GARDEN</option><option value="RAMESH NAGAR">RAMESH NAGAR</option><option value="RITHALA">RITHALA</option><option value="RK ASHRAM MARG">RK ASHRAM MARG</option><option value="ROHINI EAST">ROHINI EAST</option><option value="ROHINI SECTOR 18,19">ROHINI SECTOR 18,19</option><option value="ROHINI WEST">ROHINI WEST</option><option value="SAKET">SAKET</option><option value="SAMAYPUR BADLI">SAMAYPUR BADLI</option><option value="SARAI">SARAI</option><option value="SARITA VIHAR">SARITA VIHAR</option><option value="SATGURU RAM SINGH MARG">SATGURU RAM SINGH MARG</option><option value="SECTOR-28">SECTOR-28</option><option value="SEELAMPUR">SEELAMPUR</option><option value="SHADIPUR">SHADIPUR</option><option value="SHAHDARA">SHAHDARA</option><option value="SHASTRI NAGAR">SHASTRI NAGAR</option><option value="SHASTRI PARK">SHASTRI PARK</option><option value="SHIVAJI PARK">SHIVAJI PARK</option><option value="SHIVAJI STADIUM">SHIVAJI STADIUM</option><option value="SIKANDARPUR">SIKANDARPUR</option><option value="SUBHASH NAGAR">SUBHASH NAGAR</option><option value="SUKHDEV VIHAR">SUKHDEV VIHAR</option><option value="SULTANPUR">SULTANPUR</option><option value="SURAJMAL STADIUM">SURAJMAL STADIUM</option><option value="TAGORE GARDEN">TAGORE GARDEN</option><option value="TILAK NAGAR">TILAK NAGAR</option><option value="TIS HAZARI">TIS HAZARI</option><option value="TUGHLAKABAD">TUGHLAKABAD</option><option value="UDYOG BHAWAN">UDYOG BHAWAN</option><option value="UDYOG NAGAR">UDYOG NAGAR</option><option value="UTTAM NAGAR EAST">UTTAM NAGAR EAST</option><option value="UTTAM NAGAR WEST">UTTAM NAGAR WEST</option><option value="VAISHALI">VAISHALI</option><option value="VIDHAN SABHA">VIDHAN SABHA</option><option value="VISHWAVIDYALAYA">VISHWAVIDYALAYA</option><option value="WELCOME">WELCOME</option><option value="YAMUNA BANK">YAMUNA BANK</option>					</select>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Sign Up" />
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- OPEN UPLOAD CSS FILE -->
<link rel="stylesheet" type="text/css" href="dist/css/openUpload.css">

<!-- OPEN UPLOAD BUTTON -->
<div href="#" id="open-upload-button" class="btn btn-circle btn-primary" data-toggle="modal" data-target="#openUpload">
	+ &nbsp;upload
</div>

<!-- OPEN UPLOAD MODAL -->
<div class="modal fade" id="openUpload" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<div class="container" style="padding:0;">
				<span class="close" type="button" data-dismiss="modal" aria-label="Close"><span style="vertical-align: text-top;" aria-hidden="true" class="glyphicon glyphicon-menu-left"></span></span>
				<h2 class="modal-title" style="display: inline-block;">&nbsp;&nbsp;Upload and Share</h2>
			</div>
		</div>
		
		<div class="modal-body container">
			<p>Upload your study material and be a helping hand to your buddies out there.</p>
			<br/>
			<div style="display:none;">
				<span id="uploadpercentage"></span>
				<div class="progress">
				    <div style="background:#000;" class="bar"></div >
				    <div class="percent">0%</div >
				</div>
				<div id="status"></div>
			</div>
			  <progress id="progressBar" value="0" max="100" style="width:100%; transition:.2s ease-in-out; display:none"></progress>
			  <h3 id="status"></h3>
			  <p id="loaded_n_total"></p>
			  
			  <!--<div id="bar_blank">
			   <div id="bar_color"></div>
			  </div>
			  <div id="status"></div>-->
			
			<form action="open_upload_request.php" enctype="multipart/form-data" method="post" class="form-horizontal" id="open-upload-form">
			           <!--<input type="hidden" value="open-upload-form"
    name="PHP_SESSION_UPLOAD_PROGRESS">-->

			        <div class="form-group container row">
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios1" value="notes" required>
			            <label class="form-check-label" for="exampleRadios1">
			              Notes
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios2" value="practicalfiles" required>
			            <label class="form-check-label" for="exampleRadios2">
			              Practical Files
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios3" value="questionpapers" required>
			            <label class="form-check-label" for="exampleRadios3">
			              Question Papers
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios4" value="ebooks" required>
			            <label class="form-check-label" for="exampleRadios4">
			              eBooks
			            </label>
			          </div>
			        </div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Attach file</label>
					<div class="col-sm-10">
						<input required type="file" class="form-control" placeholder="" name="file" accept=".pdf,.doc,.docx,.rtf,.ppt,.pptx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" >
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Topic</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Topic" name="topic">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Subject</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Subject" name="subject" id="subject" autocomplete="off">
						<div id="subjectList"></div>
					</div>
				</div>
			        <div class="form-group">
			          <label class="col-sm-2 control-label" for="">Credits</label>
			          <div class="col-sm-10">
			            <input required type="text" class="form-control" placeholder="Your Name" name="credit">
			          </div>
			        </div>
			
				<div class="col-sm-offset-2">
					<input type="submit" class="btn btn-primary" value="Upload :)" onSubmit="uploadFile();">
				</div>
			</form>
		</div>
		
	</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
 $(document).ready(function(){
	  $('#subject').keyup(function(e){
	  	var code= e.keycode | e.which;
	  	//alert(code);
	  	if(code!=38&&code!==40) { 
	  	//var e= $.Event('keyup'); e.which=code; $("#subject").trigger(e); 
		   var query = $(this).val();
		   if(query != '')
		   {
				$.ajax({
					 url:"subject_autocomplete.php",
					 method:"POST",
					 data:{query:query},
					 success:function(data)
					 {
						  $('#subjectList').fadeIn();
						  $('#subjectList').html(data);
					 }
				});
		   }else if(query == ''){
			$('#subjectList').fadeOut();
		   }
	  }
	  });
	  
	  $(document).on('click', '.list-group-item', function(){
		   $('#subject').val($(this).text());
		   $('#subjectList').fadeOut();
	  });
 });

</script>

<!--<script>

//Upload Progress bar
/*function toggleBarVisibility() {
    var e = document.getElementById("bar_blank");
   // e.style.display = (e.style.display == "block") ? "none" : "block";
}

function createRequestObject() {
    var http;
    if (navigator.appName == "Microsoft Internet Explorer") {
        http = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else {
        http = new XMLHttpRequest();
    }
    return http;
}

function sendRequest() {
    var http = createRequestObject();
    http.open("GET", "progress.php");
    http.onreadystatechange = function () { handleResponse(http); };
    http.send(null);
}

function handleResponse(http) {
    var response;
    if (http.readyState == 4) {
        response = http.responseText;
        alert("Response"+response);
        document.getElementById("bar_color").style.width = response + "%";
        document.getElementById("status").innerHTML = response + "%";

        if (response < 100) {
            setTimeout("sendRequest()", 1000);
        }
        else {
            toggleBarVisibility();
            document.getElementById("status").innerHTML = "Done.";
        }
    }
}

function startUpload() {
    toggleBarVisibility();
    setTimeout("sendRequest()", 1000);
}

(function () {
    document.getElementById("open-upload-form").onsubmit = startUpload;
})();*/
</script>-->

<script>

//FETCHING FILE UPLOAD PERCENTAGE 
function get(el) {
  return document.getElementById(el);
}

function uploadFile() {
  var file = $('input[name="file"]')[0].files[0];
  var title = $('input[name="title"]');
  var subject = $('input[name="subject"]');
  var credit = $('input[name="credit"]');
  var category = $('input[name="category"]');
  // alert(file.name+" | "+file.size+" | "+file.type);
  var formdata = new FormData();
  formdata.append("file", file);
  formdata.append("title", title);
  formdata.append("subject", subject);
  formdata.append("credit", credit);
  formdata.append("category", category);
  var ajax = new XMLHttpRequest();
  ajax.upload.addEventListener("progress", progressHandler, false);
  ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  ajax.open("POST", "open_upload_request.php");
  ajax.send(formdata);
}

function progressHandler(event) {
$('progress').show();
$('#open-upload-form').fadeOut();
  get("loaded_n_total").innerHTML = Number(event.loaded/event.total*100).toFixed(2) + " % Uploaded ";
  var percent = (event.loaded / event.total) * 100;
  get("progressBar").value = Math.round(percent);
  get("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
  get("status").innerHTML = event.target.responseText;
  get("progressBar").value = 0;
}

function errorHandler(event) {
  get("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
  get("status").innerHTML = "Upload Aborted";
}
</script>


<script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="dist/js/bootstrap.min.js"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="assets/js/vendor/holder.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>


<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="tables/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
<!--<script>
      window.fbMessengerPlugins = window.fbMessengerPlugins || {
        init: function () {
          FB.init({
            appId            : '1678638095724206',
            autoLogAppEvents : true,
            xfbml            : true,
            version          : 'v2.10'
          });
        }, callable: []
      };
      window.fbAsyncInit = window.fbAsyncInit || function () {
        window.fbMessengerPlugins.callable.forEach(function (item) { item(); });
        window.fbMessengerPlugins.init();
      };
      setTimeout(function () {
        (function (d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) { return; }
          js = d.createElement(s);
          js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      }, 0);
      </script>

      <div
        class="fb-customerchat"
        page_id="910123809127452"
        ref="">
      </div>-->

     </body>
     </html>
