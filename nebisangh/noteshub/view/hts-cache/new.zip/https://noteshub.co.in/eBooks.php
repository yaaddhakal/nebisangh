<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="googlebot" content="noodp">
    <meta name="description" content="One  stop solution for engineering students">
    <meta name="keywords" content="GGSIPU,IPU,NotesHub,Notes,B.Tech,engg,engineering,study,material,books,question,paper,papers,practical,files,download,pdf,buy,sell,college,btech,quality,last,year,supplementary,note,notes,indraprastha,university,NotesHub,Computer,science,information,technology,mechanical,civil,electrical,electronics,cs,it,mae,me,eee,ece,cse,download,search,find">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">
    <meta name="theme-color" content="#ca2c2c">
    <link rel="manifest" href="/manifest.json">

    <title>NotesHub</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--<script src="preloader.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/css/preloader.css">-->
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Dont actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="dist/css/select2.css" rel="stylesheet">
    <link href="dist/css/select2-bootstrap.css" rel="stylesheet">
    <link href="dist/css/modify.css" rel="stylesheet">
    <link href="dist/css/buyBooks.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="dist/css/sellBooks.css">


    <link href="dist/css/carousel.css" rel="stylesheet">
    <link href="dist/css/index.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="dist/css/footer-basic-centered.css">

    <link href="tables/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="dist/css/datatables customization.css">

    <!--Google ads customization -->
    <link rel="stylesheet" type="text/css" href="dist/css/google ads customization.css">
    <!-- Google Analytics -->
	<script>
  	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  	ga('create', 'UA-86458385-1', 'auto');
  	ga('send', 'pageview');

	</script>

     <!--Google adsense -->
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
     <script>

     (adsbygoogle = window.adsbygoogle || []).push({
     google_ad_client: "ca-pub-6153632791841759",
     enable_page_level_ads: true
     });

      //install service worker
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
          navigator.serviceWorker.register('/sw.js').then(function(registration) {
            // Registration was successful
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
          }, function(err) {
            // registration failed :(
            console.log('ServiceWorker registration failed: ', err);
          });
        });
      }

     </script>

  </head>
<!-- NAVBAR
================================================== -->
  <body>
  <!--PRELOADER -->
    <!--<div id="preloader-container"">
    <div id="preloader-screen">
      <div class="preloader-content">
        <div class="row1">
          <span class="logo">  <img src="images/72.png"/>  </span>
          <span class="text"> NotesHub <span class=" highlighted-text">hai na...</span>  </span>
        </div>
        <div class="bar-container">
          <div class="bar">

          </div>
        </div>
        <div class="loading">Loading . . . <span id="load-percentage" class="highlighted-text">100</span>%</div>
      </div>
    </div>
    </div>-->

<!--APP LINK-->
	<a style="text-decoration:none; color: #fff;" href='https://goo.gl/RmUPsG' target='_blank'>
          <div style="background-color:#ca2c2c; text-align:center; color:#ffffff; width:100%;  position: fixed; z-index:100000; padding: 3px 0;">
            <span style="vertical-align:middle; white-space: nowrap;">Application now available on Google Play. Download now!</span>
          </div>
          </a>
    <!--NAVBAR-->
    <div class="navbar-wrapper">


      <div class="container">
           <nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" style="margin-top:25px;">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="search.php">NotesHub</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">


              <ul class="nav navbar-nav">
                <li><a href="search.php">Search</a></li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Download <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="notes.php">Notes</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="practicalFiles.php">Practical Files</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="questionPapers.php">Question Papers</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="eBooks.php">eBooks</a></li>

                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Books <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="buyBooks.php">Buy Books</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="sellBooks.php">Sell Books</a></li>
                  </ul>
                </li>

                <li><a href="videos.php">Video Tutorials</a></li>
                <!--<li><a href="#contact">Contact Us</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="team.php">Team</a></li>-->

              </ul>

              <ul class="nav navbar-nav navbar-right">
                                  <li><a href="#" data-toggle="modal" data-target="#signUp">Sign Up</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#userLogin">User Login</a></li>
                                </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>

    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->


    <div class="jumbotron">
      <div class="container">
        <br>
        <br>
        <h1>Download eBooks.</h1>
        <p>We are trying to get all the eBooks that are out there, just for you. Okay?</p>

      </div>
    </div>



    <!--select starts here-->
    <div class="container-fluid center-content">

      <form class="form-horizontal" action="#" method="get">
                         <div class="row">
                         <div class="col-md-4 col-sm-4 col-xs-12 col-semester">
                            <div class="form-group">

                              <label for="id_label_single">
                              Select your Semester
                              </label>
                              <br>

                                <select required id="semester" class="form-control js-example-basic-single semester">
                                <option value=""></option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                </select>
                            </div>
                          </div>

                          <div class="col-md-4 col-sm-4 col-xs-12 col-branch">
                            <div class="form-group">

                            <label for="id_label_single">
                              Select your Branch
                            </label>
                              <br>

                                <select required id="branch" class="form-control js-example-basic-single branch" >
                                      <option value=""></option>
                                      <option value="cse">CSE</option>
                                      <option value="it">IT</option>
                                      <option value="mae">MAE</option>
                                      <option value="civil">CIVIL</option>
                                      <option value="eee">EEE</option>
                                      <option value="ece">ECE</option>
                                </select>
                            </div>
                          </div>

                          <div class="col-md-4 col-sm-4 col-xs-12 col-subject">
                            <div class="form-group">

                              <label for="id_label_single">
                                    Select your Subject
                              </label>
                              <br>

                              <select required id="subjects" name="subjects" class="form-control js-example-basic-single subject" >
                                <option value=""></option>

                              </select>
                            </div>
                          </div>

                          </div>


                            <div class="row">

                            <div class="col-md-4 col-md-offset-4 col-recommend">
                            <div class="form-group">

                                <button name="recommend" type="submit" class="btn btn-primary btn-lg">Recommend Me</button>

                            </div>
                            </div>
                            </div>
                          </form>
      </div>
      <!--selection ends here-->

       <hr style="width: 50%;
                                 height: 10px;
                                 border: 0;
                                 box-shadow: 0 10px 10px -10px #8c8b8b inset;">


       <div class="container results-table center-content">

         <table class="table display responsive" cellspacing="0" width="100%" id="resultsTable">

           <thead>
             <th>S No.</th>
             <th>Topic</th>
             <th>Subject</th>
             <th>Branch</th>
             <th>Downloads</th>
             <th>Credits</th>
             <th>Filesize</th>
           </thead>
           <tbody>

                            <tr>
                 <td>1</td>
                 <td><a href="download.php?table=ebooks&id=53&file=publicuploads/2018/ebooks/letusc-yashwantkanetkar2018-04-04 18:30:46.pdf">c programming</a></td>
                 <td>Introduction to Programming</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>11</td>
                 <!--<td></td>-->
                 <td>priyansh singhal</td>
                 <td>7.2MB</td>
               </tr>
                              <tr>
                 <td>2</td>
                 <td><a href="download.php?table=ebooks&id=52&file=publicuploads/2018/ebooks/Balaguruswamy Object Oriented Programming With C Fourth Edition2018-02-24 08:27:29.pdf">Balaguruswamy Fourth Edition 4th sem </a></td>
                 <td>Object Oriented Programming</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>30</td>
                 <!--<td></td>-->
                 <td>Ahraar</td>
                 <td>20.7MB</td>
               </tr>
                              <tr>
                 <td>3</td>
                 <td><a href="download.php?table=ebooks&id=51&file=2017/ebooks/Envinromental Studies By Erach Bharucha2018-02-16 18:03:28.pdf">Envinromental Studies By Erach Bharucha</a></td>
                 <td>Environmental Studies</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>80</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.6MB</td>
               </tr>
                              <tr>
                 <td>4</td>
                 <td><a href="download.php?table=ebooks&id=50&file=2017/ebooks/English grammar and composition by wren and martin2018-02-16 18:02:11.pdf">English Grammar and Composition by Wren and Martin</a></td>
                 <td>Communication Skills</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>46</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.3MB</td>
               </tr>
                              <tr>
                 <td>5</td>
                 <td><a href="download.php?table=ebooks&id=49&file=2017/ebooks/engineering mechanics- RS khurmi2018-02-16 17:58:54.pdf">Engineering Mechanics by RS Khurmi</a></td>
                 <td>Engineering Mechanics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>62</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>23.9MB</td>
               </tr>
                              <tr>
                 <td>6</td>
                 <td><a href="download.php?table=ebooks&id=48&file=2017/ebooks/Devraj Singh e-book AP22018-02-16 17:55:32.pdf">Devraj Singh Vol 2</a></td>
                 <td>Applied Physics II</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>102</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>20.1MB</td>
               </tr>
                              <tr>
                 <td>7</td>
                 <td><a href="download.php?table=ebooks&id=47&file=2017/ebooks/Engineering Mechanics by S2018-02-04 18:22:15.pdf">Engineering Mechanics by S S Bhavikatti</a></td>
                 <td>Engineering Mechanics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>90</td>
                 <!--<td></td>-->
                 <td>Lalit Gupta</td>
                 <td>3.5MB</td>
               </tr>
                              <tr>
                 <td>8</td>
                 <td><a href="download.php?table=ebooks&id=46&file=2017/ebooks/Communication System-4thSem-CSE_ECE-Er Atul2018-02-04 18:13:57.pdf">Communication System By Haukins 4th Edition </a></td>
                 <td>Communication Systems</td>
                 <!--<td></td>-->
                 <td>CSE, ECE</td>
                 <td>56</td>
                 <!--<td></td>-->
                 <td>Er Atul</td>
                 <td>34.7MB</td>
               </tr>
                              <tr>
                 <td>9</td>
                 <td><a href="download.php?table=ebooks&id=45&file=2017/ebooks/Let Us C - Yashwant Kanetkar2018-01-16 23:37:27.pdf">Let Us C by Yashwant Kanetkar</a></td>
                 <td>Introduction to Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>128</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6.9MB</td>
               </tr>
                              <tr>
                 <td>10</td>
                 <td><a href="download.php?table=ebooks&id=44&file=2017/ebooks/BS Grewal eBook2017-12-24 10:41:04.pdf">B S Grewal eBook</a></td>
                 <td>Applied Mathematics II</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>160</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>173.3KB</td>
               </tr>
                              <tr>
                 <td>11</td>
                 <td><a href="download.php?table=ebooks&id=43&file=2017/ebooks/Optics by Ajoy Ghatak2017-12-10 18:26:37.pdf">Optics by Ajoy Ghatak</a></td>
                 <td>Applied Physics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>28</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>50.3MB</td>
               </tr>
                              <tr>
                 <td>12</td>
                 <td><a href="download.php?table=ebooks&id=42&file=2017/ebooks/Basic Electrical Engineering  By Chakrabarti2017-12-10 18:23:11.pdf">Basic Electrical Engineering by Chakrabarti</a></td>
                 <td>Electrical Technology</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>40</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>32.2MB</td>
               </tr>
                              <tr>
                 <td>13</td>
                 <td><a href="download.php?table=ebooks&id=41&file=2017/ebooks/Notes by PN Rao@Manufacturing Processes@notes2017-12-06 15:40:29.pdf">Notes by PN Rao</a></td>
                 <td>Manufacturing Processes</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>86</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>12.2MB</td>
               </tr>
                              <tr>
                 <td>14</td>
                 <td><a href="download.php?table=ebooks&id=40&file=2017/ebooks/Data Structures and algorithms made easy2017-12-05 01:33:03.pdf">Data Structures and Algorithms Made Easy in Java by Narasimha Karumanchi </a></td>
                 <td>Data Structure</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>67</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>174.3KB</td>
               </tr>
                              <tr>
                 <td>15</td>
                 <td><a href="download.php?table=ebooks&id=39&file=2017/ebooks/BS Grewal Maths eBook2017-12-02 20:20:53.pdf">BS Grewal eBook</a></td>
                 <td>Applied Mathematics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>113</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>173.3KB</td>
               </tr>
                              <tr>
                 <td>16</td>
                 <td><a href="download.php?table=ebooks&id=38&file=2017/ebooks/Introduction To Computers by Peter Norton - 6th Edition 2017-12-02 18:21:22.pdf">Introduction To Computers by Peter Norton 6th Edition </a></td>
                 <td>Fundamentals of Computing</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>81</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>18MB</td>
               </tr>
                              <tr>
                 <td>17</td>
                 <td><a href="download.php?table=ebooks&id=37&file=2017/ebooks/Strength_Of_Materials_parts_IandII-Timoshenko2017-11-26 16:12:50.pdf">SOM by S Timoshenko</a></td>
                 <td>Strength of Material</td>
                 <!--<td></td>-->
                 <td>MAE, CIVIL</td>
                 <td>56</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>32.6MB</td>
               </tr>
                              <tr>
                 <td>18</td>
                 <td><a href="download.php?table=ebooks&id=36&file=2017/ebooks/strength-of-material-by-r-k-bansal2017-11-26 16:05:49.pdf">SOM by RK Bansal</a></td>
                 <td>Strength of Material</td>
                 <!--<td></td>-->
                 <td>MAE, CIVIL</td>
                 <td>70</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>23.9MB</td>
               </tr>
                              <tr>
                 <td>19</td>
                 <td><a href="download.php?table=ebooks&id=35&file=2017/ebooks/Theory of Machines - R2017-11-26 10:46:03.pdf">Theory of Machines RS Khurmi</a></td>
                 <td>Theory of Machines</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>25</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>17MB</td>
               </tr>
                              <tr>
                 <td>20</td>
                 <td><a href="download.php?table=ebooks&id=33&file=2017/ebooks/Digital-Control-and-State-Variable-Methods-by-M-Gopal2017-11-11 16:11:03.pdf">Digital Control and State Variable Methods by M Gopal</a></td>
                 <td>Advanced Control Systems</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>25</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>25.8MB</td>
               </tr>
                              <tr>
                 <td>21</td>
                 <td><a href="download.php?table=ebooks&id=32&file=2017/ebooks/Cryptography and Network Security Forouzan2017-10-30 21:32:39.pdf">Cryptography and Network Security Forouzan</a></td>
                 <td>Cryptography and Network Security</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>48</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>49MB</td>
               </tr>
                              <tr>
                 <td>22</td>
                 <td><a href="download.php?table=ebooks&id=31&file=2017/ebooks/Mechanics of Solids by S2017-10-02 11:51:31.pdf">Mechanics of Solids S S Bhavikatti</a></td>
                 <td>Strength of Material</td>
                 <!--<td></td>-->
                 <td>MAE, CIVIL</td>
                 <td>60</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2.8MB</td>
               </tr>
                              <tr>
                 <td>23</td>
                 <td><a href="download.php?table=ebooks&id=30&file=2017/ebooks/Basics of Fluid Mechanics by Genick Bar-Meir2017-10-02 11:36:52.pdf">Basics of Fluid Mechanics by Genick Bar Meir</a></td>
                 <td>Fluid Mechanics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>41</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.9MB</td>
               </tr>
                              <tr>
                 <td>24</td>
                 <td><a href="download.php?table=ebooks&id=29&file=2017/ebooks/Fluid Mechanics With Engineering Applications - 10th Edition2017-10-02 11:31:11.pdf">Fluid Mechanics with Engineering Applications 10th edition</a></td>
                 <td>Fluid Mechanics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>41</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>27.2MB</td>
               </tr>
                              <tr>
                 <td>25</td>
                 <td><a href="download.php?table=ebooks&id=28&file=2017/ebooks/Book2017-09-27 00:11:03.pdf">Fox and McDonald Introduction to Fluid Mechanics </a></td>
                 <td>Fluid Mechanics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>44</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>40.3MB</td>
               </tr>
                              <tr>
                 <td>26</td>
                 <td><a href="download.php?table=ebooks&id=27&file=2017/ebooks/Control Systems by Anand Kumar2017-09-24 13:25:44.pdf">Control Systems by Anand Kumar</a></td>
                 <td>Control Systems</td>
                 <!--<td></td>-->
                 <td>MAE, ECE</td>
                 <td>52</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>21.8MB</td>
               </tr>
                              <tr>
                 <td>27</td>
                 <td><a href="download.php?table=ebooks&id=26&file=2017/ebooks/Cloud Computing Tutorial2017-09-23 18:50:13.pdf">Tutorials Point Cloud Computing Tutorial </a></td>
                 <td>Cloud Computing </td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>41</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>1.8MB</td>
               </tr>
                              <tr>
                 <td>28</td>
                 <td><a href="download.php?table=ebooks&id=25&file=2017/ebooks/Mastering Cloud Computing2017-09-22 19:38:55.pdf">Mastering Cloud Computing Foundations and Applications Programming</a></td>
                 <td>Cloud Computing </td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>48</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>26.8MB</td>
               </tr>
                              <tr>
                 <td>29</td>
                 <td><a href="download.php?table=ebooks&id=24&file=2017/ebooks/A Textbook of Machine Design by R2017-09-21 21:42:26.pdf">A Textbook of Machine Design by R S KHURMI AND J K GUPTA</a></td>
                 <td>Machine Design</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>40</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>22.2MB</td>
               </tr>
                              <tr>
                 <td>30</td>
                 <td><a href="download.php?table=ebooks&id=23&file=2017/ebooks/Expert Oracle Database 11g Administration by SR Alapati2017-09-21 07:47:10.pdf">Expert Oracle Database 11g Administration by SR Alapati</a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>45</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.3MB</td>
               </tr>
                              <tr>
                 <td>31</td>
                 <td><a href="download.php?table=ebooks&id=22&file=2017/ebooks/Oracle Database 10g Administration Workshop I Volume 22017-09-21 07:43:35.pdf">Oracle Database 10g Administration Workshop I Volume 2</a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>33</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.3MB</td>
               </tr>
                              <tr>
                 <td>32</td>
                 <td><a href="download.php?table=ebooks&id=21&file=2017/ebooks/Oracle Database 10g Administration Workshop I Volume 12017-09-21 07:41:26.pdf">Oracle Database 10g Administration Workshop I Volume 1</a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>36</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>5MB</td>
               </tr>
                              <tr>
                 <td>33</td>
                 <td><a href="download.php?table=ebooks&id=20&file=2017/ebooks/engineering-fluid-mechanics-12017-09-20 18:38:32.pdf">Fluid mechanics for engineering</a></td>
                 <td>Fluid Mechanics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>48</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6MB</td>
               </tr>
                              <tr>
                 <td>34</td>
                 <td><a href="download.php?table=ebooks&id=19&file=2017/ebooks/wireless_communication_tutorial2017-09-19 17:13:08.pdf">Wireless Communication from Tutorials Point</a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>72</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>1.2MB</td>
               </tr>
                              <tr>
                 <td>35</td>
                 <td><a href="download.php?table=ebooks&id=18&file=2017/ebooks/Daniel Collins, Clint Smith-3G Wireless Networks (2001)2017-09-19 17:11:27.pdf">Daniel Collins Clint Smith 3G Wireless Networks 2001 </a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>55</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2.7MB</td>
               </tr>
                              <tr>
                 <td>36</td>
                 <td><a href="download.php?table=ebooks&id=17&file=2017/ebooks/Stallings_Cryptography_and_Network_Security2017-09-18 20:49:11.pdf">Stallings Cryptography and Network Security</a></td>
                 <td>Cryptography and Network Security</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>42</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>14MB</td>
               </tr>
                              <tr>
                 <td>37</td>
                 <td><a href="download.php?table=ebooks&id=15&file=2017/ebooks/java-the-complete-reference-7th-edition2017-06-12 19:00:17.pdf">Java The Complete Reference 7th edition </a></td>
                 <td>Java Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>96</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6.4MB</td>
               </tr>
               
           </tbody>

         </table>

       </div>
       <br>
      <br>
<div class="container marketing">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script type="text/javascript">
//for dynamic subject list
$(document).ready(function(){
  $('#semester').on('change',function(){
    var semester = $(this).val();
    var branch = $('#branch').val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('#branch').on('change',function(){
    var semester = $('#semester').val();
    var branch = $(this).val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('.load_sub1').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects1').last().html(html);
        }
    });
  });
  $('.load_sub2').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects2').last().html(html);
        }
    });
  });
  $('.load_sub3').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects3').last().html(html);
        }
    });
  });
});
</script>

<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
    <img class="img-circle" src="images/6.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Experience</h2>
    <p>Its been an year since we started NotesHub, therefore we know what you need, when you need and how much you need.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/7.png" alt="Generic placeholder image" width="140" height="140">
    <h2>100K+ Visits</h2>
    <p>We have seen 100 Thousand plus visits on
NotesHub and we are proud that we could
deliver so much value.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/8.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Quality
</h2>
    <p>One of the most important thing to us is that the material
we provide you is of exquisite quality. We know its frustrating to spend time on useless material.</p>

  </div><!-- /.col-lg-4 -->
</div><!-- /.row -->



<!--CUSTOM ADVERTISEMENT True Value Smartphones-->
      <a href="https://goo.gl/WkPCzV" style="text-decoration:none;">
        <div class="container text-center">
        Sponsored
        <div class="row" style="background: #eee; font-size: 1.2em; padding: 15px;">

          <div class="col-lg-3 col-lg-3">
            <p><img style="width:100%;" src="images/ad.jpg"></p>
          </div>

          <div class="col-lg-6 col-lg-6">
            <p style="font-size: 2em; font-weight: bold; color:#225bc2;">True Value Smartphone</p>
            <p>We buy and sell used or preowned smartphone at <strong>Best Price</strong></p>

            <img src="https://www.apple.com/favicon.ico">
            <img src="https://statics.oneplus.net/v3/img/common/logo.png">
            <img src="https://www.skymartbw.com/wp-content/uploads/2010/04/lg-logo.png" width="96">
            <img src="https://www.senheng.com.my/media/catalog/category/xiaomi.png"> and more...
          </div>

          <div class="col-lg-3 col-md-3" style="text-align: center;">
            <p style="width: 100%;"><strong>Office address:</strong> 8/66, 3<sup>rd</sup> floor Vijay Nagar Double Storey, Delhi 110009<br/>Near North Campus DU</p>
            <p><a href="tel:8860828901"><span class="glyphicon glyphicon-earphone"></span> 8860828901</a></p>
          </div>
        </div>
        </div>
      </a>
      <br/>
      <hr>


<!-- START THE FEATURETTES -->
  <!--GOOGLE ADS-->
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- text_and_display -->
  <ins class="adsbygoogle ad-type-1"
       style="display:block"
       data-ad-client="ca-pub-6153632791841759"
       data-ad-slot="9543810896"
       data-ad-format="auto"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>

<hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">NOTES</h2>
      <p class="lead">NotesHub came into existence because we experienced the same problem that you all face during exams. Standing for hours at photocopy shops and gathering notes wastes alot of time..</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/1.jpg" alt="Find Notes and study material">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7 col-md-push-5">
      <h2 class="featurette-heading">BOOKS</h2>
      <p class="lead">Spending Rs. 5000+ every semester to buy books on rent and then receiving only 30% of the cost is wastage of money too. Using NotesHub, you can get the books at 50% price with all the supplementary material. We are also trying to arrange all the eBooks we can!
</p>
    </div>
    <div class="col-md-5 col-md-pull-7">
      <img class="featurette-image img-responsive center-block" src="images/2.jpg" alt="Engineering books">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">PRACTICAL FILES</h2>
      <p class="lead">We all HATE making practical files because they are nothing but making copies. Also, arranging the files and material is a task in itself. Here, we are trying to bridge the gap between the colleges so that everyone can make their files quick and easy and focus on whats more important i.e. learning to perform the practical</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/3.jpg" alt="Find practical files">
    </div>
  </div>

  <hr class="featurette-divider">


        <div class="row featurette">
          <div class="col-md-7 col-md-push-5">
            <h2 class="featurette-heading">QUESTION PAPERS</h2>
            <p class="lead">NotesHub is also the place to get all the previous year question papers  with solutions. We also try to arrange for different types of assignments.
  </p>
          </div>
          <div class="col-md-5 col-md-pull-7">
            <img class="featurette-image img-responsive center-block" src="images/4.jpg" alt="Previous year question papers">
          </div>
        </div>

        <!--<hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading">INTERNSHIPS</h2>
            <p class="lead">Most of us are not able to score an internship because we are looking at the wrong places. Also, due to lack of information, we miss opportunities. This is what we identified and hence NotesHub has a <b>Internship Feed</b>  that will keep you up to date with all the new opportunities in town.</p>

          </div>
          <div class="col-md-5">
            <img class="featurette-image img-responsive center-block" src="images/5.jpg" alt="Find Internships">
          </div>
        </div>!-->

        <hr class="featurette-divider ad-type-2">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    		<ins class="adsbygoogle"
    		     style="display:block"
    		     data-ad-format="fluid"
    		     data-ad-layout-key="-8i+1w-dq+e9+ft"
    		     data-ad-client="ca-pub-6153632791841759"
    		     data-ad-slot="7024802225"></ins>
    		<script>
    		     (adsbygoogle = window.adsbygoogle || []).push({});
    		</script>
</div>
  <!-- /.container -->
		<hr class="featurette-divider">

<!-- /END THE FEATURETTES -->


  <div class="container-fluid">

    <div class="row">

                  <div class="about-us-parallax">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofAboutUs">Your Last Minute Companion</span>
                      <br>
                      <br>
                      <p style="font-size:x-large; color: white;">Nothing makes a person more productive than the <b>"Last Minute"</b></p>
                    </div>
                  </div>
                  </div>

                  <div class="row" id="about">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">About Us</h3>
                    <p class="description-aboutus">Trying to make your lives easier. That&rsquo;s it. Nothing fancy.</p>
                  </div>
                  </div>

                  <div class="row">
                  <div class="contactus-parallax ">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofContactUs">Hello!<br>Let&rsquo;s Talk.</span>
                      <br>

                    </div>
                  </div>
                  </div>

                  <div class="row" id="contact">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">Suggestions, Feedback, Advice?</h3>

                    <p class="description-aboutus">We thrive to improve. Drop us a mail.</p>
                  </div>
                  </div>
      <br>
  </div>


      <!--############################# form ##########################################-->
        <div class="container-fluid">
            <div class="row">


                <div class="col-md-8">
                    <div class="well well-sm">
                        <form action="contact.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Enter name" required="required" name="name"/>
                                </div>
                                <div class="form-group">
                                    <label for="email">
                                        Email Address</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                        </span>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" name="email"/></div>
                                </div>
                                <div class="form-group">
                                    <label for="subject">
                                        Subject</label>
                                    <select class="form-control" required="required" name="subject">
                                        <option value="" selected disabled>Choose One:</option>
                                        <option value="Non-availability of material">Non-availability of material</option>
                                        <option value="Buy/Sell Book">Buy/Sell Book</option>
                                        <option value="Just to say Hello!">Just to say Hello!</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Message</label>
                                    <textarea id="message" class="form-control" rows="9" cols="25" required="required"
                                        placeholder="Message" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                                    Send Message</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>


                <div class="col-md-4" style="text-align: center;">
                    <legend>Our Motto</legend>
                    <img src="images/back.jpg" style="min-height: 250px; width: 100%; margin-top: -15px;">

                </div>


            </div>

          </div><!--container fluid ends -->


      <!-- ############################# form ########################################## -->

        <br>
        <br>

   <div class="container-fluid">
                  <div class="row">
                    <div class="followUs-parallax">
                    <div class="caption col-md-9 col-sm-12 col-xs-12">
                    <br>
                    <br>
                    <br>
                      <div style="float: right;" class="social">
                      <span style="font-size: 25px; color: white;">We don&rsquo;t mind Stalking!</span>


                      <br>
                      <a href="https://www.facebook.com/TeamNotesHub/" target="blank" style="color: white  !important;"><i  class="fa fa-facebook-square fa-5x social"></i></a>
                      &nbsp;&nbsp;
                      <a href="https://www.instagram.com/_noteshub_/" target="blank" style="color: white  !important;"><i class="fa fa-instagram fa-5x" aria-hidden="true"></i></a>
                      </div>

                    </div>
                  </div>
                  </div>

    <br>
    <br>


                    <div class="row">
                      <div style="text-align: center;" >
                        <h2>Thank You.</h2>
                      </div>
                    </div>
    <br>
    <br>

    </div>







    <!-- FOOTER -->

  <footer class="footer-basic-centered" style="padding-top: 0 !important; padding-bottom: 10px;">


    <p class = "footer-company-motto" style="color: white;padding: 8px; font-style: 20px;" >NotesHub</p>

    <p class="footer-company-name">NotesHub | SPI &copy; 2016-18</p>

    <p class="footer-company-name"><a href="privacy_policy.html" target="_blank">Privacy Policy</a> | <a href="terms_and_conditions.html" target="_blank">Terms and Conditions</a></p>

  </footer>
  <!--INCLUDING SIGNIN SIGNUP MODALS -->
  <!--Modals-->

<!-- user login -->
<div class="modal fade"  id="userLogin" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">User Login</h4>
			</div>
			<form action="loginScript.php" method="post">
			<div class="modal-body">

					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword2">Password</label>
						<input required type="password" class="form-control" id="exampleInputPassword2" placeholder="Password" name="password">
						<span><a href="#" data-toggle="modal" data-target="#forgotPassword">Forgot Password?</a></span>

					</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Login</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- forgot password -->
<div class="modal fade"  id="forgotPassword" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Forgot Password?</h4>
			</div>
			<form action="recovery.php" method="post">
			<div class="modal-body">
					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Your registered email id" name="email">
					</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- signup -->
<div class="modal fade" id="signUp" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Sign Up</h4>
			</div>
			<form action = "register.php" method="post">
				<div class="modal-body">
					<div class="form-group">
						<label for="">Name</label>
						<input required type="text" name="name" pattern="[a-zA-Z]+[a-zA-Z ]*" class="form-control"  placeholder="Name (only letters and spaces are alllowed)">
					</div>

					<div class="form-group">
						<label for="">Email ID</label>
						<input required type="email" name="email" class="form-control" placeholder="Email">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input required type="password" name="password" minlength="8" maxlength="32" class="form-control" id="exampleInputPassword1" placeholder="Password (must be of at least 8 characters)">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Mobile Number</label>
						<input required type="tel" name="phno" pattern="[7-9]{1}[0-9]{9}" class="form-control" id="phoneNumber" placeholder="Mobile Number (must start with7, 8, or 9 and be of 10 digits)">
					</div>

					<div class="form-group">
					<label for="college">College</label>
					<select required name="college" class="form-control">
							<option value="" selected disabled>Select College</option>
							<option value="Ambedkar Institute of Advanced Communication Technologies and Research">Ambedkar Institute of Advanced Communication Technologies and Research</option><option value="Amity School of Engineering and Technology">Amity School of Engineering and Technology</option><option value="B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat">B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat</option><option value="Bhagwan Parshuram Institute of Technology">Bhagwan Parshuram Institute of Technology</option><option value="Bharati Vidyapeeth's College of Engineering">Bharati Vidyapeeth's College of Engineering</option><option value="Ch. B.P. Government Engineering College, Delhi">Ch. B.P. Government Engineering College, Delhi</option><option value="Delhi Technical Campus">Delhi Technical Campus</option><option value="Guru Tegh Bahadur Institute of Technology">Guru Tegh Bahadur Institute of Technology</option><option value="HMR Institute of Technology & Management">HMR Institute of Technology & Management</option><option value="JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)">JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)</option><option value="Maharaja Agrasen Institute of Technology">Maharaja Agrasen Institute of Technology</option><option value="Maharaja Surajmal Institute of Technology">Maharaja Surajmal Institute of Technology</option><option value="Northern India Engineering College">Northern India Engineering College</option><option value="University School of Information and Communication Technology">University School of Information and Communication Technology</option>					</select>
					</div>

					<div class="form-group">
					<label for="college">Branch</label>
					<select required name = "branch" class="form-control">
							<option value="" selected disabled>Select Branch</option>
							<option value="cse">CSE</option>
							<option value="it">IT</option>
							<option value="mae">MAE</option>
							<option value="civil">CIVIL</option>
							<option value="eee">EEE</option>
							<option value="ece">ECE</option>
					</select>
					</div>

					<div class="form-group">
					<label for="college">Nearest Metro Station</label>
					<select required name = "nms" class="form-control">
							<option value="" selected disabled>Select Nearest Metro Station</option>
							<option value="ADARSH NAGAR">ADARSH NAGAR</option><option value="AIIMS">AIIMS</option><option value="AKSHARDHAM">AKSHARDHAM</option><option value="ANAND VIHAR">ANAND VIHAR</option><option value="ARJANGARH">ARJANGARH</option><option value="ASHOK PARK MAIN">ASHOK PARK MAIN</option><option value="AZADPUR">AZADPUR</option><option value="BADARPUR">BADARPUR</option><option value="BADKAL MOR">BADKAL MOR</option><option value="BARAKHAMBA">BARAKHAMBA</option><option value="BATA CHOWK">BATA CHOWK</option><option value="BOTANICAL GARDEN">BOTANICAL GARDEN</option><option value="CENTRAL SECRETARIAT">CENTRAL SECRETARIAT</option><option value="CHANDNI CHOWK">CHANDNI CHOWK</option><option value="CHAWRI BAZAR">CHAWRI BAZAR</option><option value="CHHATTARPUR">CHHATTARPUR</option><option value="CIVIL LINES">CIVIL LINES</option><option value="DELHI AERO CITY">DELHI AERO CITY</option><option value="DELHI GATE">DELHI GATE</option><option value="DHAULA KUAN">DHAULA KUAN</option><option value="DILSHAD GARDEN">DILSHAD GARDEN</option><option value="DWARKA">DWARKA</option><option value="DWARKA MOR">DWARKA MOR</option><option value="DWARKA SEC 10">DWARKA SEC 10</option><option value="DWARKA SEC 11">DWARKA SEC 11</option><option value="DWARKA SEC 12">DWARKA SEC 12</option><option value="DWARKA SEC 13">DWARKA SEC 13</option><option value="DWARKA SEC 14">DWARKA SEC 14</option><option value="DWARKA SEC 21">DWARKA SEC 21</option><option value="DWARKA SEC 8">DWARKA SEC 8</option><option value="DWARKA SEC 9">DWARKA SEC 9</option><option value="ESCORTS MUJESAR">ESCORTS MUJESAR</option><option value="G.T.B. NAGAR">G.T.B. NAGAR</option><option value="GHITORNI">GHITORNI</option><option value="GOLF COURSE">GOLF COURSE</option><option value="GOVIND PURI">GOVIND PURI</option><option value="GREEN PARK">GREEN PARK</option><option value="GURU DRONACHARYA">GURU DRONACHARYA</option><option value="HAIDERPUR BADLI MOR">HAIDERPUR BADLI MOR</option><option value="HAUZ KHAS">HAUZ KHAS</option><option value="HUDA CITY CENTRE">HUDA CITY CENTRE</option><option value="I.G.I. AIRPORT">I.G.I. AIRPORT</option><option value="IFFCO CHOWK">IFFCO CHOWK</option><option value="INA">INA</option><option value="INDER LOK">INDER LOK</option><option value="INDRAPRASTHA">INDRAPRASTHA</option><option value="ITO">ITO</option><option value="JAHANGIRPURI">JAHANGIRPURI</option><option value="JAMA MASJID">JAMA MASJID</option><option value="JAMIA MILIA ISLAMIYA">JAMIA MILIA ISLAMIYA</option><option value="JANAK PURI EAST">JANAK PURI EAST</option><option value="JANAK PURI WEST">JANAK PURI WEST</option><option value="JANGPURA">JANGPURA</option><option value="JANPATH">JANPATH</option><option value="JASOLA APOLLO">JASOLA APOLLO</option><option value="JASOLA VIHAR">JASOLA VIHAR</option><option value="JHANDEWALAN">JHANDEWALAN</option><option value="JHIL MIL">JHIL MIL</option><option value="JLN STADIUM">JLN STADIUM</option><option value="JORBAGH">JORBAGH</option><option value="KAILASH COLONY">KAILASH COLONY</option><option value="KALINDI KUNJ">KALINDI KUNJ</option><option value="KALKAJI MANDIR">KALKAJI MANDIR</option><option value="KANHAIYA NAGAR">KANHAIYA NAGAR</option><option value="KARKAR DUMA">KARKAR DUMA</option><option value="KAROL BAGH">KAROL BAGH</option><option value="KASHMERE GATE">KASHMERE GATE</option><option value="KAUSHAMBI">KAUSHAMBI</option><option value="KESHAV PURAM">KESHAV PURAM</option><option value="KHAN MARKET">KHAN MARKET</option><option value="KIRTI NAGAR">KIRTI NAGAR</option><option value="KOHAT ENCLAVE">KOHAT ENCLAVE</option><option value="LAJPAT NAGAR">LAJPAT NAGAR</option><option value="LAL QUILA">LAL QUILA</option><option value="LAXMI NAGAR">LAXMI NAGAR</option><option value="LOK KALYAN MARG">LOK KALYAN MARG</option><option value="M G ROAD">M G ROAD</option><option value="MADI PUR">MADI PUR</option><option value="MALVIYA NAGAR">MALVIYA NAGAR</option><option value="MANDI HOUSE">MANDI HOUSE</option><option value="MANSAROVAR PARK">MANSAROVAR PARK</option><option value="MAYUR VIHAR-I">MAYUR VIHAR-I</option><option value="MAYUR VIHAR-I EXT">MAYUR VIHAR-I EXT</option><option value="MEWALA MAHARAJPUR">MEWALA MAHARAJPUR</option><option value="MODEL TOWN">MODEL TOWN</option><option value="MOHAN ESTATE">MOHAN ESTATE</option><option value="MOOLCHAND">MOOLCHAND</option><option value="MOTI NAGAR">MOTI NAGAR</option><option value="MUNDKA">MUNDKA</option><option value="NANGLOI">NANGLOI</option><option value="NANGLOI RLY. STATION">NANGLOI RLY. STATION</option><option value="NAWADA">NAWADA</option><option value="NEELAM CHOWK AJRONDA">NEELAM CHOWK AJRONDA</option><option value="NEHRU PLACE">NEHRU PLACE</option><option value="NETAJI SUBHASH PLACE">NETAJI SUBHASH PLACE</option><option value="NEW ASHOK NAGAR">NEW ASHOK NAGAR</option><option value="NEW DELHI">NEW DELHI</option><option value="NHPC CHOWK">NHPC CHOWK</option><option value="NIRMAN VIHAR">NIRMAN VIHAR</option><option value="NOIDA CITY CENTRE">NOIDA CITY CENTRE</option><option value="NOIDA SEC 15">NOIDA SEC 15</option><option value="NOIDA SEC 16">NOIDA SEC 16</option><option value="NOIDA SEC 18">NOIDA SEC 18</option><option value="NSIC OKHLA">NSIC OKHLA</option><option value="OKHLA">OKHLA</option><option value="OKHLA BIRD SANCTUARY">OKHLA BIRD SANCTUARY</option><option value="OKHLA VIHAR">OKHLA VIHAR</option><option value="OLD FARIDABAD">OLD FARIDABAD</option><option value="PASCHIM VIHAR (EAST)">PASCHIM VIHAR (EAST)</option><option value="PASCHIM VIHAR (WEST)">PASCHIM VIHAR (WEST)</option><option value="PATEL CHOWK">PATEL CHOWK</option><option value="PATEL NAGAR">PATEL NAGAR</option><option value="PEERA GARHI">PEERA GARHI</option><option value="PITAM PURA">PITAM PURA</option><option value="PRAGATI MAIDAN">PRAGATI MAIDAN</option><option value="PRATAP NAGAR">PRATAP NAGAR</option><option value="PREET VIHAR">PREET VIHAR</option><option value="PUL BANGASH">PUL BANGASH</option><option value="PUNJABI BAGH">PUNJABI BAGH</option><option value="QUTAB MINAR">QUTAB MINAR</option><option value="RAJDHANI PARK">RAJDHANI PARK</option><option value="RAJENDRA PLACE">RAJENDRA PLACE</option><option value="RAJIV CHOWK">RAJIV CHOWK</option><option value="RAJOURI GARDEN">RAJOURI GARDEN</option><option value="RAMESH NAGAR">RAMESH NAGAR</option><option value="RITHALA">RITHALA</option><option value="RK ASHRAM MARG">RK ASHRAM MARG</option><option value="ROHINI EAST">ROHINI EAST</option><option value="ROHINI SECTOR 18,19">ROHINI SECTOR 18,19</option><option value="ROHINI WEST">ROHINI WEST</option><option value="SAKET">SAKET</option><option value="SAMAYPUR BADLI">SAMAYPUR BADLI</option><option value="SARAI">SARAI</option><option value="SARITA VIHAR">SARITA VIHAR</option><option value="SATGURU RAM SINGH MARG">SATGURU RAM SINGH MARG</option><option value="SECTOR-28">SECTOR-28</option><option value="SEELAMPUR">SEELAMPUR</option><option value="SHADIPUR">SHADIPUR</option><option value="SHAHDARA">SHAHDARA</option><option value="SHASTRI NAGAR">SHASTRI NAGAR</option><option value="SHASTRI PARK">SHASTRI PARK</option><option value="SHIVAJI PARK">SHIVAJI PARK</option><option value="SHIVAJI STADIUM">SHIVAJI STADIUM</option><option value="SIKANDARPUR">SIKANDARPUR</option><option value="SUBHASH NAGAR">SUBHASH NAGAR</option><option value="SUKHDEV VIHAR">SUKHDEV VIHAR</option><option value="SULTANPUR">SULTANPUR</option><option value="SURAJMAL STADIUM">SURAJMAL STADIUM</option><option value="TAGORE GARDEN">TAGORE GARDEN</option><option value="TILAK NAGAR">TILAK NAGAR</option><option value="TIS HAZARI">TIS HAZARI</option><option value="TUGHLAKABAD">TUGHLAKABAD</option><option value="UDYOG BHAWAN">UDYOG BHAWAN</option><option value="UDYOG NAGAR">UDYOG NAGAR</option><option value="UTTAM NAGAR EAST">UTTAM NAGAR EAST</option><option value="UTTAM NAGAR WEST">UTTAM NAGAR WEST</option><option value="VAISHALI">VAISHALI</option><option value="VIDHAN SABHA">VIDHAN SABHA</option><option value="VISHWAVIDYALAYA">VISHWAVIDYALAYA</option><option value="WELCOME">WELCOME</option><option value="YAMUNA BANK">YAMUNA BANK</option>					</select>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Sign Up" />
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- OPEN UPLOAD CSS FILE -->
<link rel="stylesheet" type="text/css" href="dist/css/openUpload.css">

<!-- OPEN UPLOAD BUTTON -->
<div href="#" id="open-upload-button" class="btn btn-circle btn-primary" data-toggle="modal" data-target="#openUpload">
	+ &nbsp;upload
</div>

<!-- OPEN UPLOAD MODAL -->
<div class="modal fade" id="openUpload" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<div class="container" style="padding:0;">
				<span class="close" type="button" data-dismiss="modal" aria-label="Close"><span style="vertical-align: text-top;" aria-hidden="true" class="glyphicon glyphicon-menu-left"></span></span>
				<h2 class="modal-title" style="display: inline-block;">&nbsp;&nbsp;Upload and Share</h2>
			</div>
		</div>
		
		<div class="modal-body container">
			<p>Upload your study material and be a helping hand to your buddies out there.</p>
			<br/>
			<div style="display:none;">
				<span id="uploadpercentage"></span>
				<div class="progress">
				    <div style="background:#000;" class="bar"></div >
				    <div class="percent">0%</div >
				</div>
				<div id="status"></div>
			</div>
			  <progress id="progressBar" value="0" max="100" style="width:100%; transition:.2s ease-in-out; display:none"></progress>
			  <h3 id="status"></h3>
			  <p id="loaded_n_total"></p>
			  
			  <!--<div id="bar_blank">
			   <div id="bar_color"></div>
			  </div>
			  <div id="status"></div>-->
			
			<form action="open_upload_request.php" enctype="multipart/form-data" method="post" class="form-horizontal" id="open-upload-form">
			           <!--<input type="hidden" value="open-upload-form"
    name="PHP_SESSION_UPLOAD_PROGRESS">-->

			        <div class="form-group container row">
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios1" value="notes" required>
			            <label class="form-check-label" for="exampleRadios1">
			              Notes
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios2" value="practicalfiles" required>
			            <label class="form-check-label" for="exampleRadios2">
			              Practical Files
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios3" value="questionpapers" required>
			            <label class="form-check-label" for="exampleRadios3">
			              Question Papers
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios4" value="ebooks" required>
			            <label class="form-check-label" for="exampleRadios4">
			              eBooks
			            </label>
			          </div>
			        </div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Attach file</label>
					<div class="col-sm-10">
						<input required type="file" class="form-control" placeholder="" name="file" accept=".pdf,.doc,.docx,.rtf,.ppt,.pptx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" >
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Topic</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Topic" name="topic">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Subject</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Subject" name="subject" id="subject" autocomplete="off">
						<div id="subjectList"></div>
					</div>
				</div>
			        <div class="form-group">
			          <label class="col-sm-2 control-label" for="">Credits</label>
			          <div class="col-sm-10">
			            <input required type="text" class="form-control" placeholder="Your Name" name="credit">
			          </div>
			        </div>
			
				<div class="col-sm-offset-2">
					<input type="submit" class="btn btn-primary" value="Upload :)" onSubmit="uploadFile();">
				</div>
			</form>
		</div>
		
	</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
 $(document).ready(function(){
	  $('#subject').keyup(function(e){
	  	var code= e.keycode | e.which;
	  	//alert(code);
	  	if(code!=38&&code!==40) { 
	  	//var e= $.Event('keyup'); e.which=code; $("#subject").trigger(e); 
		   var query = $(this).val();
		   if(query != '')
		   {
				$.ajax({
					 url:"subject_autocomplete.php",
					 method:"POST",
					 data:{query:query},
					 success:function(data)
					 {
						  $('#subjectList').fadeIn();
						  $('#subjectList').html(data);
					 }
				});
		   }else if(query == ''){
			$('#subjectList').fadeOut();
		   }
	  }
	  });
	  
	  $(document).on('click', '.list-group-item', function(){
		   $('#subject').val($(this).text());
		   $('#subjectList').fadeOut();
	  });
 });

</script>

<!--<script>

//Upload Progress bar
/*function toggleBarVisibility() {
    var e = document.getElementById("bar_blank");
   // e.style.display = (e.style.display == "block") ? "none" : "block";
}

function createRequestObject() {
    var http;
    if (navigator.appName == "Microsoft Internet Explorer") {
        http = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else {
        http = new XMLHttpRequest();
    }
    return http;
}

function sendRequest() {
    var http = createRequestObject();
    http.open("GET", "progress.php");
    http.onreadystatechange = function () { handleResponse(http); };
    http.send(null);
}

function handleResponse(http) {
    var response;
    if (http.readyState == 4) {
        response = http.responseText;
        alert("Response"+response);
        document.getElementById("bar_color").style.width = response + "%";
        document.getElementById("status").innerHTML = response + "%";

        if (response < 100) {
            setTimeout("sendRequest()", 1000);
        }
        else {
            toggleBarVisibility();
            document.getElementById("status").innerHTML = "Done.";
        }
    }
}

function startUpload() {
    toggleBarVisibility();
    setTimeout("sendRequest()", 1000);
}

(function () {
    document.getElementById("open-upload-form").onsubmit = startUpload;
})();*/
</script>-->

<script>

//FETCHING FILE UPLOAD PERCENTAGE 
function get(el) {
  return document.getElementById(el);
}

function uploadFile() {
  var file = $('input[name="file"]')[0].files[0];
  var title = $('input[name="title"]');
  var subject = $('input[name="subject"]');
  var credit = $('input[name="credit"]');
  var category = $('input[name="category"]');
  // alert(file.name+" | "+file.size+" | "+file.type);
  var formdata = new FormData();
  formdata.append("file", file);
  formdata.append("title", title);
  formdata.append("subject", subject);
  formdata.append("credit", credit);
  formdata.append("category", category);
  var ajax = new XMLHttpRequest();
  ajax.upload.addEventListener("progress", progressHandler, false);
  ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  ajax.open("POST", "open_upload_request.php");
  ajax.send(formdata);
}

function progressHandler(event) {
$('progress').show();
$('#open-upload-form').fadeOut();
  get("loaded_n_total").innerHTML = Number(event.loaded/event.total*100).toFixed(2) + " % Uploaded ";
  var percent = (event.loaded / event.total) * 100;
  get("progressBar").value = Math.round(percent);
  get("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
  get("status").innerHTML = event.target.responseText;
  get("progressBar").value = 0;
}

function errorHandler(event) {
  get("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
  get("status").innerHTML = "Upload Aborted";
}
</script>




     <!-- Bootstrap core JavaScript
     ================================================== -->
     <!-- Placed at the end of the document so the pages load faster -->
     <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="dist/js/bootstrap.min.js"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="assets/js/vendor/holder.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>


<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="tables/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>


<!--<script>
 $('#internTable').DataTable( {
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.modal( {
                    header: function ( row ) {
                        var data = row.data();
                        return 'Details for internship in '+data[1];
                    }
                } ),
                renderer: $.fn.dataTable.Responsive.renderer.tableAll( {
                    tableClass: 'table'
                } )
            }
        }
    } );
</script>-->

     <!--Banner type text effect , navbar out of focus close -->
     <script src="dist/js/typed.js"></script>
     <script src="dist/js/banner.js"></script>

     <script src="dist/js/sellBooks.js"></script>


     <script type="text/javascript">

               $('#resultsTable').DataTable( {
                "pagingType": "full",
               responsive: true,
               columnDefs: [
                   { responsivePriority: 1, targets: 0 },
                   { responsivePriority: 2, targets: 1 }
               ]
           } );
     </script>




     <script src="dist/js/select2.js"></script>

       <script type="text/javascript">

         $(document).ready(function() {
           $(".semester").select2({
             placeholder: "Select Semester",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".branch").select2({
             placeholder: "Select Branch",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".subject").select2({
             placeholder: "Select Subject",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

<!--<script>
      window.fbMessengerPlugins = window.fbMessengerPlugins || {
        init: function () {
          FB.init({
            appId            : '1678638095724206',
            autoLogAppEvents : true,
            xfbml            : true,
            version          : 'v2.10'
          });
        }, callable: []
      };
      window.fbAsyncInit = window.fbAsyncInit || function () {
        window.fbMessengerPlugins.callable.forEach(function (item) { item(); });
        window.fbMessengerPlugins.init();
      };
      setTimeout(function () {
        (function (d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) { return; }
          js = d.createElement(s);
          js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      }, 0);
      </script>

      <div
        class="fb-customerchat"
        page_id="910123809127452"
        ref="">
      </div>-->

     </body>
     </html>
