<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="googlebot" content="noodp">
    <meta name="description" content="One  stop solution for engineering students">
    <meta name="keywords" content="GGSIPU,IPU,NotesHub,Notes,B.Tech,engg,engineering,study,material,books,question,paper,papers,practical,files,download,pdf,buy,sell,college,btech,quality,last,year,supplementary,note,notes,indraprastha,university,NotesHub,Computer,science,information,technology,mechanical,civil,electrical,electronics,cs,it,mae,me,eee,ece,cse,download,search,find">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">
    <meta name="theme-color" content="#ca2c2c">
    <link rel="manifest" href="/manifest.json">

    <title>NotesHub</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--<script src="preloader.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/css/preloader.css">-->
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Dont actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="dist/css/select2.css" rel="stylesheet">
    <link href="dist/css/select2-bootstrap.css" rel="stylesheet">
    <link href="dist/css/modify.css" rel="stylesheet">
    <link href="dist/css/buyBooks.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="dist/css/sellBooks.css">


    <link href="dist/css/carousel.css" rel="stylesheet">
    <link href="dist/css/index.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="dist/css/footer-basic-centered.css">

    <link href="tables/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="dist/css/datatables customization.css">

    <!--Google ads customization -->
    <link rel="stylesheet" type="text/css" href="dist/css/google ads customization.css">
    <!-- Google Analytics -->
	<script>
  	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  	ga('create', 'UA-86458385-1', 'auto');
  	ga('send', 'pageview');

	</script>

     <!--Google adsense -->
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
     <script>

     (adsbygoogle = window.adsbygoogle || []).push({
     google_ad_client: "ca-pub-6153632791841759",
     enable_page_level_ads: true
     });

      //install service worker
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
          navigator.serviceWorker.register('/sw.js').then(function(registration) {
            // Registration was successful
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
          }, function(err) {
            // registration failed :(
            console.log('ServiceWorker registration failed: ', err);
          });
        });
      }

     </script>

  </head>
<!-- NAVBAR
================================================== -->
  <body>
  <!--PRELOADER -->
    <!--<div id="preloader-container"">
    <div id="preloader-screen">
      <div class="preloader-content">
        <div class="row1">
          <span class="logo">  <img src="images/72.png"/>  </span>
          <span class="text"> NotesHub <span class=" highlighted-text">hai na...</span>  </span>
        </div>
        <div class="bar-container">
          <div class="bar">

          </div>
        </div>
        <div class="loading">Loading . . . <span id="load-percentage" class="highlighted-text">100</span>%</div>
      </div>
    </div>
    </div>-->

<!--APP LINK-->
	<a style="text-decoration:none; color: #fff;" href='https://goo.gl/RmUPsG' target='_blank'>
          <div style="background-color:#ca2c2c; text-align:center; color:#ffffff; width:100%;  position: fixed; z-index:100000; padding: 3px 0;">
            <span style="vertical-align:middle; white-space: nowrap;">Application now available on Google Play. Download now!</span>
          </div>
          </a>
    <!--NAVBAR-->
    <div class="navbar-wrapper">


      <div class="container">
           <nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" style="margin-top:25px;">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="search.php">NotesHub</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">


              <ul class="nav navbar-nav">
                <li><a href="search.php">Search</a></li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Download <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="notes.php">Notes</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="practicalFiles.php">Practical Files</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="questionPapers.php">Question Papers</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="eBooks.php">eBooks</a></li>

                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Books <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="buyBooks.php">Buy Books</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="sellBooks.php">Sell Books</a></li>
                  </ul>
                </li>

                <li><a href="videos.php">Video Tutorials</a></li>
                <!--<li><a href="#contact">Contact Us</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="team.php">Team</a></li>-->

              </ul>

              <ul class="nav navbar-nav navbar-right">
                                  <li><a href="#" data-toggle="modal" data-target="#signUp">Sign Up</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#userLogin">User Login</a></li>
                                </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>

    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->


    <div class="jumbotron">
      <div class="container">
        <br>
        <br>
        <h1>Download Question Papers.</h1>
        <p>Are you confused with the syllabus? Check out previous year question papers!</p>

      </div>
    </div>



    <!--select starts here-->
    <div class="container-fluid center-content">

      <form class="form-horizontal" action="#" method="get">
                         <div class="row">
                         <div class="col-md-4 col-sm-4 col-xs-12 col-semester">
                            <div class="form-group">

                              <label for="id_label_single">
                              Select your Semester
                              </label>
                              <br>

                                <select required id="semester" class="form-control js-example-basic-single semester">
                                <option value=""></option>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                </select>
                            </div>
                          </div>

                          <div class="col-md-4 col-sm-4 col-xs-12 col-branch">
                            <div class="form-group">

                            <label for="id_label_single">
                              Select your Branch
                            </label>
                              <br>

                                <select required id="branch" class="form-control js-example-basic-single branch" >
                                      <option value=""></option>
                                      <option value="cse">CSE</option>
                                      <option value="it">IT</option>
                                      <option value="mae">MAE</option>
                                      <option value="civil">CIVIL</option>
                                      <option value="eee">EEE</option>
                                      <option value="ece">ECE</option>
                                </select>
                            </div>
                          </div>

                          <div class="col-md-4 col-sm-4 col-xs-12 col-subject">
                            <div class="form-group">

                              <label for="id_label_single">
                                    Select your Subject
                              </label>
                              <br>

                              <select required id="subjects" name="subjects" class="form-control js-example-basic-single subject" >
                                <option value=""></option>

                              </select>
                            </div>
                          </div>

                          </div>


                            <div class="row">

                            <div class="col-md-4 col-md-offset-4 col-recommend">
                            <div class="form-group">

                                <button name="recommend" type="submit" class="btn btn-primary btn-lg">Recommend Me</button>

                            </div>
                            </div>
                            </div>
                          </form>
      </div>
      <!--selection ends here-->

       <hr style="width: 50%;
                                 height: 10px;
                                 border: 0;
                                 box-shadow: 0 10px 10px -10px #8c8b8b inset;">


       <div class="container results-table center-content">

         <table class="table display responsive" cellspacing="0" width="100%" id="resultsTable">

           <thead>
             <th>S No.</th>
             <th>Topic</th>
             <th>Subject</th>
             <th>Branch</th>
             <th>Downloads</th>
             <th>Credits</th>
             <th>Filesize</th>
           </thead>

           <tbody>

                            <tr>
                 <td>1</td>
                 <td><a href="download.php?table=questionpapers&id=178&file=publicuploads/2018/questionpapers/EDC Akash 2nd Term2018-04-25 20:55:05.pdf">2nd Term Akash</a></td>
                 <td>Electronic Devices</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>6</td>
                 <!--<td></td>-->
                 <td>Sarthak Agarwal</td>
                 <td>8.9MB</td>
               </tr>
                              <tr>
                 <td>2</td>
                 <td><a href="download.php?table=questionpapers&id=177&file=publicuploads/2018/questionpapers/English Akash 2nd Term2018-04-25 20:54:12.pdf">2nd Term Akash</a></td>
                 <td>Communication Skills</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>4</td>
                 <!--<td></td>-->
                 <td>Sarthak Agarwal</td>
                 <td>3.9MB</td>
               </tr>
                              <tr>
                 <td>3</td>
                 <td><a href="download.php?table=questionpapers&id=176&file=publicuploads/2018/questionpapers/EVS Akash 2nd Term2018-04-25 20:52:39.pdf">2nd Term Akash</a></td>
                 <td>Environmental Studies</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>1</td>
                 <!--<td></td>-->
                 <td>Sarthak Agarwal</td>
                 <td>7.7MB</td>
               </tr>
                              <tr>
                 <td>4</td>
                 <td><a href="download.php?table=questionpapers&id=175&file=publicuploads/2018/questionpapers/ITP Akash 2nd Term2018-04-25 20:51:01.pdf">2nd Term Akash</a></td>
                 <td>Introduction to Programming</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>2</td>
                 <!--<td></td>-->
                 <td>Sarthak Agarwal</td>
                 <td>4.7MB</td>
               </tr>
                              <tr>
                 <td>5</td>
                 <td><a href="download.php?table=questionpapers&id=174&file=publicuploads/2018/questionpapers/Am2 sem 2 akash2018-04-24 11:54:30.pdf">2nd Semester End-Term Akash</a></td>
                 <td>Applied Mathematics II</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>4</td>
                 <!--<td></td>-->
                 <td>Keshav</td>
                 <td>8.7MB</td>
               </tr>
                              <tr>
                 <td>6</td>
                 <td><a href="download.php?table=questionpapers&id=173&file=publicuploads/2018/questionpapers/Em sem2 akash2018-04-24 11:56:15.pdf">2nd Semester End-Term Akash</a></td>
                 <td>Engineering Mechanics</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>3</td>
                 <!--<td></td>-->
                 <td>Keshav</td>
                 <td>6.8MB</td>
               </tr>
                              <tr>
                 <td>7</td>
                 <td><a href="download.php?table=questionpapers&id=172&file=publicuploads/2018/questionpapers/Physics Akash 2nd Term2018-04-25 20:45:00.pdf">2nd Term Akash</a></td>
                 <td>Applied Physics II</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>3</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6.1MB</td>
               </tr>
                              <tr>
                 <td>8</td>
                 <td><a href="download.php?table=questionpapers&id=171&file=publicuploads/2018/questionpapers/Mechanics Akash 2nd Term2018-04-25 20:47:50.pdf">2nd Term Akash</a></td>
                 <td>Engineering Mechanics</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>3</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.2MB</td>
               </tr>
                              <tr>
                 <td>9</td>
                 <td><a href="download.php?table=questionpapers&id=170&file=2018/questionpapers/Maths Akash 2nd Term2018-04-25 20:43:30.pdf">2nd Term Akash</a></td>
                 <td>Applied Mathematics II</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>3</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>5.5MB</td>
               </tr>
                              <tr>
                 <td>10</td>
                 <td><a href="download.php?table=questionpapers&id=169&file=2018/questionpapers/New Doc 2018-04-092018-04-09 23:04:09.pdf">Second Term Aakash 2016</a></td>
                 <td>Data Communication and Networks</td>
                 <!--<td></td>-->
                 <td>IT, ECE, MAE</td>
                 <td>12</td>
                 <!--<td></td>-->
                 <td>Saurabh</td>
                 <td>3.9MB</td>
               </tr>
                              <tr>
                 <td>11</td>
                 <td><a href="download.php?table=questionpapers&id=168&file=2018/questionpapers/New Doc 2018-02-262018-02-27 20:52:56.pdf">Akash 2018 1st Sessional</a></td>
                 <td>Utilization of Electrical Energy and Electric Traction</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>21</td>
                 <!--<td></td>-->
                 <td>Ayush Jain</td>
                 <td>4.1MB</td>
               </tr>
                              <tr>
                 <td>12</td>
                 <td><a href="download.php?table=questionpapers&id=167&file=2018/questionpapers/AI 20172018-02-27 20:40:52.pdf">Akash 2018 1st Sessionals</a></td>
                 <td>Artificial Intelligence</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>51</td>
                 <!--<td></td>-->
                 <td>Saurav</td>
                 <td>3.7MB</td>
               </tr>
                              <tr>
                 <td>13</td>
                 <td><a href="download.php?table=questionpapers&id=166&file=2018/questionpapers/PSP-20172018-02-27 20:29:42.pdf">Akash 2017 1st Sessionals</a></td>
                 <td>Power Station Practice</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>18</td>
                 <!--<td></td>-->
                 <td>Ayush Jain</td>
                 <td>2.5MB</td>
               </tr>
                              <tr>
                 <td>14</td>
                 <td><a href="download.php?table=questionpapers&id=165&file=2018/questionpapers/PSP-20162018-02-27 20:28:45.pdf">Akash 1st Sessional 2016 </a></td>
                 <td>Power Station Practice</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>19</td>
                 <!--<td></td>-->
                 <td>Ayush Jain</td>
                 <td>2.7MB</td>
               </tr>
                              <tr>
                 <td>15</td>
                 <td><a href="download.php?table=questionpapers&id=164&file=2018/questionpapers/analog electronics II akash sample paper2018-02-26 20:45:48.pdf">Akash sample papers</a></td>
                 <td>Analog Electronics II</td>
                 <!--<td></td>-->
                 <td>EEE, ECE</td>
                 <td>81</td>
                 <!--<td></td>-->
                 <td>AKSHIT (NIEC)</td>
                 <td>6.9MB</td>
               </tr>
                              <tr>
                 <td>16</td>
                 <td><a href="download.php?table=questionpapers&id=163&file=2018/questionpapers/New Doc 2018-02-25-12018-02-25 14:30:11.pdf">Akash 2018 1st Sessionals</a></td>
                 <td>Environmental Studies</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>321</td>
                 <!--<td></td>-->
                 <td>Shubham</td>
                 <td>15.3MB</td>
               </tr>
                              <tr>
                 <td>17</td>
                 <td><a href="download.php?table=questionpapers&id=162&file=publicuploads/2018/questionpapers/EVS AKASH_201802251404322018-02-25 14:08:16.pdf">AKASH FIRST TERM QUESTION PAPERS</a></td>
                 <td>Environmental Studies</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>167</td>
                 <!--<td></td>-->
                 <td>Piyush Sikka</td>
                 <td>12.2MB</td>
               </tr>
                              <tr>
                 <td>18</td>
                 <td><a href="download.php?table=questionpapers&id=161&file=publicuploads/2018/questionpapers/ITP AKASH END TERM PAPERS2018-02-25 13:18:14.pdf">Akash introduction to programming</a></td>
                 <td>Introduction to Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>390</td>
                 <!--<td></td>-->
                 <td>SAURAV JAIN</td>
                 <td>17.5MB</td>
               </tr>
                              <tr>
                 <td>19</td>
                 <td><a href="download.php?table=questionpapers&id=160&file=publicuploads/2018/questionpapers/EVS akash2018-02-25 11:58:49.pdf">Last Year Papers </a></td>
                 <td>Communication Skills</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>274</td>
                 <!--<td></td>-->
                 <td>Sarthak </td>
                 <td>8.6MB</td>
               </tr>
                              <tr>
                 <td>20</td>
                 <td><a href="download.php?table=questionpapers&id=159&file=2018/questionpapers/Document 22018-02-23 23:37:39.pdf">Akash 2018 1st Sessional</a></td>
                 <td>Mobile Computing</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>52</td>
                 <!--<td></td>-->
                 <td>Aditya</td>
                 <td>1.2MB</td>
               </tr>
                              <tr>
                 <td>21</td>
                 <td><a href="download.php?table=questionpapers&id=158&file=2018/questionpapers/VLSI Akash2018-02-23 23:26:26.pdf">Akash 2018 1st Sessionals</a></td>
                 <td>VLSI Design</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>21</td>
                 <!--<td></td>-->
                 <td>Ayush Jain</td>
                 <td>5.6MB</td>
               </tr>
                              <tr>
                 <td>22</td>
                 <td><a href="download.php?table=questionpapers&id=157&file=2018/questionpapers/OOPS Akash2018-02-23 22:54:50.pdf">Akash 2018 </a></td>
                 <td>Object Oriented Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>69</td>
                 <!--<td></td>-->
                 <td>Amit</td>
                 <td>21.6MB</td>
               </tr>
                              <tr>
                 <td>23</td>
                 <td><a href="download.php?table=questionpapers&id=156&file=2018/questionpapers/New Doc 2018-02-22 (1)-ilovepdf-compressed2018-02-22 23:51:06.pdf">Akash 2018 Complete</a></td>
                 <td>Manufacturing Machines</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>40</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>31.7MB</td>
               </tr>
                              <tr>
                 <td>24</td>
                 <td><a href="download.php?table=questionpapers&id=155&file=2018/questionpapers/Ad-Hoc and Sensor Networks Akash2018-02-22 23:05:37.pdf">Akash 2018 1st Sessional</a></td>
                 <td>Ad hoc and Sensor Networks</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>27</td>
                 <!--<td></td>-->
                 <td>Aditya</td>
                 <td>3.3MB</td>
               </tr>
                              <tr>
                 <td>25</td>
                 <td><a href="download.php?table=questionpapers&id=154&file=2018/questionpapers/NAS pdf2018-02-22 23:02:53.pdf">Photocopied Notes</a></td>
                 <td>Network Analysis and Synthesis</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>27</td>
                 <!--<td></td>-->
                 <td>Manasvi</td>
                 <td>18.9MB</td>
               </tr>
                              <tr>
                 <td>26</td>
                 <td><a href="download.php?table=questionpapers&id=153&file=2018/questionpapers/power system 2016-172018-02-22 22:56:01.pdf">Akash 2016 17 1st Sessional</a></td>
                 <td>Power System I</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>22</td>
                 <!--<td></td>-->
                 <td>Abhishek</td>
                 <td>9.1MB</td>
               </tr>
                              <tr>
                 <td>27</td>
                 <td><a href="download.php?table=questionpapers&id=152&file=2018/questionpapers/Power System-II-EEE2018-02-22 22:52:57.pdf">Akash 2018 1st Sessional</a></td>
                 <td>Power System II</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>15</td>
                 <!--<td></td>-->
                 <td>Jitender Kumar</td>
                 <td>3.6MB</td>
               </tr>
                              <tr>
                 <td>28</td>
                 <td><a href="download.php?table=questionpapers&id=151&file=2018/questionpapers/TOC AKASH2018-02-22 22:06:50.pdf">Akash 2018 1st Sessional</a></td>
                 <td>Theory of Computation</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>40</td>
                 <!--<td></td>-->
                 <td>Amit</td>
                 <td>8.3MB</td>
               </tr>
                              <tr>
                 <td>29</td>
                 <td><a href="download.php?table=questionpapers&id=150&file=publicuploads/2018/questionpapers/HVPE-2nd 1st Sessionals2018-02-22 11:05:56.pdf">HVPE 2 1st Sessional Aakash </a></td>
                 <td>Human Values and Professional Ethics II</td>
                 <!--<td></td>-->
                 <td></td>
                 <td>35</td>
                 <!--<td></td>-->
                 <td>Aditya </td>
                 <td>4.5MB</td>
               </tr>
                              <tr>
                 <td>30</td>
                 <td><a href="download.php?table=questionpapers&id=149&file=2018/questionpapers/ITC-akash2018-02-18 21:05:22.pdf">Previous Year Question Papers</a></td>
                 <td>Information Theory and Coding</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>37</td>
                 <!--<td></td>-->
                 <td>Divik Sharma</td>
                 <td>10.3MB</td>
               </tr>
                              <tr>
                 <td>31</td>
                 <td><a href="download.php?table=questionpapers&id=148&file=2018/questionpapers/microwave-akash2018-02-18 21:03:53.pdf">Previous Year Question Papers</a></td>
                 <td>Microwave Engineering</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE, MAE, CIVIL</td>
                 <td>31</td>
                 <!--<td></td>-->
                 <td>Divik Sharma</td>
                 <td>8.9MB</td>
               </tr>
                              <tr>
                 <td>32</td>
                 <td><a href="download.php?table=questionpapers&id=147&file=2018/questionpapers/vLSI Akash2018-02-18 21:00:27.pdf">Previous Year Question Papers</a></td>
                 <td>VLSI Design</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>47</td>
                 <!--<td></td>-->
                 <td>Divik Sharma</td>
                 <td>17.4MB</td>
               </tr>
                              <tr>
                 <td>33</td>
                 <td><a href="download.php?table=questionpapers&id=146&file=2018/questionpapers/DSP akash2018-02-18 20:53:58.pdf">Previous Year Question Papers</a></td>
                 <td>Digital Signal Processing</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>37</td>
                 <!--<td></td>-->
                 <td>Divik Sharma</td>
                 <td>13.1MB</td>
               </tr>
                              <tr>
                 <td>34</td>
                 <td><a href="download.php?table=questionpapers&id=145&file=2017/questionpapers/New Doc 2018-02-15 (4)2018-02-16 16:13:43.pdf">First Term Solved 2017</a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE, MAE, CIVIL</td>
                 <td>69</td>
                 <!--<td></td>-->
                 <td>Saurabh</td>
                 <td>3.5MB</td>
               </tr>
                              <tr>
                 <td>35</td>
                 <td><a href="download.php?table=questionpapers&id=144&file=2017/questionpapers/New Doc 2018-02-15 (3)2018-02-16 16:11:09.pdf">First Term Solved 2017</a></td>
                 <td>Compiler Design</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>68</td>
                 <!--<td></td>-->
                 <td>Saurabh (NIEC)</td>
                 <td>5.3MB</td>
               </tr>
                              <tr>
                 <td>36</td>
                 <td><a href="download.php?table=questionpapers&id=143&file=2017/questionpapers/New Doc 2018-02-15 (2)2018-02-16 16:10:18.pdf">First Term Solved 2017</a></td>
                 <td>Web Engineering</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>64</td>
                 <!--<td></td>-->
                 <td>Saurabh(NIEC)</td>
                 <td>2.4MB</td>
               </tr>
                              <tr>
                 <td>37</td>
                 <td><a href="download.php?table=questionpapers&id=142&file=2017/questionpapers/New Doc 2018-02-15 (5)2018-02-16 16:02:59.pdf">First Term Solved 2017</a></td>
                 <td>Data Communication and Networks</td>
                 <!--<td></td>-->
                 <td>MAE, IT, ECE</td>
                 <td>82</td>
                 <!--<td></td>-->
                 <td>Saurabh</td>
                 <td>3.1MB</td>
               </tr>
                              <tr>
                 <td>38</td>
                 <td><a href="download.php?table=questionpapers&id=141&file=2017/questionpapers/Introduction to programming (Akash)2018-02-14 15:06:48.pdf">Previous Year Question Papers</a></td>
                 <td>Introduction to Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>471</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>8.5MB</td>
               </tr>
                              <tr>
                 <td>39</td>
                 <td><a href="download.php?table=questionpapers&id=140&file=2017/questionpapers/Engineering mechanics (Akash)2018-02-14 15:05:25.pdf">Previous Year Question Papers</a></td>
                 <td>Engineering Mechanics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>398</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>6.5MB</td>
               </tr>
                              <tr>
                 <td>40</td>
                 <td><a href="download.php?table=questionpapers&id=139&file=2017/questionpapers/Electronic devices (Akash)2018-02-14 15:04:42.pdf">Previous Year Question Papers</a></td>
                 <td>Electronic Devices</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>369</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>10.8MB</td>
               </tr>
                              <tr>
                 <td>41</td>
                 <td><a href="download.php?table=questionpapers&id=138&file=2017/questionpapers/Communication skills (Akash)2018-02-14 15:01:56.pdf">Previous Year Question Papers</a></td>
                 <td>Communication Skills</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>341</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>5.6MB</td>
               </tr>
                              <tr>
                 <td>42</td>
                 <td><a href="download.php?table=questionpapers&id=137&file=2017/questionpapers/Applied physics-II (Akash)2018-02-14 15:01:16.pdf">Previous Year Question Papers</a></td>
                 <td>Applied Physics II</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>425</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>10.7MB</td>
               </tr>
                              <tr>
                 <td>43</td>
                 <td><a href="download.php?table=questionpapers&id=136&file=2017/questionpapers/Applied mathematics-II (Akash)2018-02-14 14:59:59.pdf">Previous Year Question Papers</a></td>
                 <td>Applied Mathematics II</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>380</td>
                 <!--<td></td>-->
                 <td>Pratham(MAIT)</td>
                 <td>6.4MB</td>
               </tr>
                              <tr>
                 <td>44</td>
                 <td><a href="download.php?table=questionpapers&id=135&file=2017/questionpapers/Network Analysis and Synthesis2018-02-13 22:31:09.pdf">AKASH solved papers</a></td>
                 <td>Network Analysis and Synthesis</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>159</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>11MB</td>
               </tr>
                              <tr>
                 <td>45</td>
                 <td><a href="download.php?table=questionpapers&id=134&file=2017/questionpapers/Electromagnatic Field Theory2018-02-13 22:28:25.pdf">AKASH solved papers</a></td>
                 <td>Electromagnetic Field Theory</td>
                 <!--<td></td>-->
                 <td>EEE, ECE</td>
                 <td>187</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>20.4MB</td>
               </tr>
                              <tr>
                 <td>46</td>
                 <td><a href="download.php?table=questionpapers&id=133&file=2017/questionpapers/Analog Electronic - II2018-02-13 22:24:00.pdf">AKASH sample papers</a></td>
                 <td>Analog Electronics–II</td>
                 <!--<td></td>-->
                 <td>EEE, ECE</td>
                 <td>38</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>20.2MB</td>
               </tr>
                              <tr>
                 <td>47</td>
                 <td><a href="download.php?table=questionpapers&id=132&file=2017/questionpapers/Communication System2018-02-13 22:20:46.pdf">AKASH sample papers</a></td>
                 <td>Communication Systems</td>
                 <!--<td></td>-->
                 <td>CSE, ECE</td>
                 <td>244</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>15.8MB</td>
               </tr>
                              <tr>
                 <td>48</td>
                 <td><a href="download.php?table=questionpapers&id=131&file=2017/questionpapers/COA2018-02-13 22:17:17.pdf">AKASH sample papers</a></td>
                 <td>Computer Organization and Architecture</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>285</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>21MB</td>
               </tr>
                              <tr>
                 <td>49</td>
                 <td><a href="download.php?table=questionpapers&id=130&file=2017/questionpapers/Applied mathematics IV2018-02-13 22:11:07.pdf">AKASH solved papers</a></td>
                 <td>Applied Mathematics IV</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>224</td>
                 <!--<td></td>-->
                 <td>AKSHIT</td>
                 <td>17.4MB</td>
               </tr>
                              <tr>
                 <td>50</td>
                 <td><a href="download.php?table=questionpapers&id=128&file=2017/questionpapers/EM Aakash2017-12-15 14:25:47.pdf">Solved Question Papers</a></td>
                 <td>Electrical Machines I</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>62</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>43.8MB</td>
               </tr>
                              <tr>
                 <td>51</td>
                 <td><a href="download.php?table=questionpapers&id=127&file=2017/questionpapers/AE AAKASH2017-12-12 20:44:33.pdf">Last Years Question Papers</a></td>
                 <td>Analog Electronics I</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>38</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>25.3MB</td>
               </tr>
                              <tr>
                 <td>52</td>
                 <td><a href="download.php?table=questionpapers&id=126&file=2017/questionpapers/cg akaash2017-12-12 19:48:05.pdf">Solved Question Papers</a></td>
                 <td>Computer Graphics and Multimedia</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>90</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.6MB</td>
               </tr>
                              <tr>
                 <td>53</td>
                 <td><a href="download.php?table=questionpapers&id=125&file=2017/questionpapers/focs akash2017-12-12 19:46:13.pdf">Solved Question Papers</a></td>
                 <td>Foundation of Computer Science</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>37</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.8MB</td>
               </tr>
                              <tr>
                 <td>54</td>
                 <td><a href="download.php?table=questionpapers&id=124&file=2017/questionpapers/stld akaash2017-12-12 19:45:35.pdf">Solved Question Papers</a></td>
                 <td>Switching Theory and Logic Design</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>35</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>24.2MB</td>
               </tr>
                              <tr>
                 <td>55</td>
                 <td><a href="download.php?table=questionpapers&id=123&file=2017/questionpapers/ds akaash2017-12-12 19:44:23.pdf">Solved Question Papers</a></td>
                 <td>Data Structure</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>60</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>18.7MB</td>
               </tr>
                              <tr>
                 <td>56</td>
                 <td><a href="download.php?table=questionpapers&id=122&file=2017/questionpapers/Stld akash2017-12-12 03:30:43.pdf">Question Papers Solved </a></td>
                 <td>Switching Theory and Logic Design</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>34</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>15.3MB</td>
               </tr>
                              <tr>
                 <td>57</td>
                 <td><a href="download.php?table=questionpapers&id=120&file=2017/questionpapers/PT Question Papers2017-12-10 19:04:59.pdf">Previous Year Question Papers Unsolved </a></td>
                 <td>Production Technology</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>42</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>742.6KB</td>
               </tr>
                              <tr>
                 <td>58</td>
                 <td><a href="download.php?table=questionpapers&id=119&file=2017/questionpapers/ET Solved Question Papers2017-12-10 18:29:42.pdf">Solved Question Papers Till Sept 2016 </a></td>
                 <td>Electrical Technology</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>74</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>36.1MB</td>
               </tr>
                              <tr>
                 <td>59</td>
                 <td><a href="download.php?table=questionpapers&id=118&file=2017/questionpapers/elecint2017-12-10 18:20:12.pdf">Internal 2017</a></td>
                 <td>Electrical Technology</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>30</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>418.8KB</td>
               </tr>
                              <tr>
                 <td>60</td>
                 <td><a href="download.php?table=questionpapers&id=117&file=2017/questionpapers/phyint2017-12-10 18:19:48.pdf">Internal Paper 2017</a></td>
                 <td>Applied Physics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>39</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>536.5KB</td>
               </tr>
                              <tr>
                 <td>61</td>
                 <td><a href="download.php?table=questionpapers&id=116&file=2017/questionpapers/chemint2017-12-10 18:19:22.pdf">Internal Paper 2017</a></td>
                 <td>Applied Chemistry</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>64</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>388.5KB</td>
               </tr>
                              <tr>
                 <td>62</td>
                 <td><a href="download.php?table=questionpapers&id=115&file=2017/questionpapers/ET Akash2017-12-08 18:57:14.pdf">ET Previous Year Papers</a></td>
                 <td>Electrical Technology</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>285</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>33.2MB</td>
               </tr>
                              <tr>
                 <td>63</td>
                 <td><a href="download.php?table=questionpapers&id=114&file=2017/questionpapers/Mes previous year - NotesHub2017-12-07 22:45:25.pdf">Solved Question Paper</a></td>
                 <td>Materials in Electrical Systems</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>61</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>15.5MB</td>
               </tr>
                              <tr>
                 <td>64</td>
                 <td><a href="download.php?table=questionpapers&id=113&file=2017/questionpapers/Dec 2015 End Sem (Solved)2017-12-07 00:01:10.pdf">Dec 2015 Solved</a></td>
                 <td>Foundation of Computer Science</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>35</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>12.7MB</td>
               </tr>
                              <tr>
                 <td>65</td>
                 <td><a href="download.php?table=questionpapers&id=112&file=2017/questionpapers/MP end term sem 12017-12-06 22:34:16.pdf">MP Last year Papers </a></td>
                 <td>Manufacturing Processes</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>244</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>33.9MB</td>
               </tr>
                              <tr>
                 <td>66</td>
                 <td><a href="download.php?table=questionpapers&id=108&file=2017/questionpapers/JAVA-5-IT2017-12-04 21:01:55.pdf">JAVA 2016 End Semester</a></td>
                 <td>Java Programming</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>52</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>571.7KB</td>
               </tr>
                              <tr>
                 <td>67</td>
                 <td><a href="download.php?table=questionpapers&id=106&file=2017/questionpapers/5-IT-CSP2017-12-04 20:59:47.pdf">CSP 2016 End Semester</a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>27</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>401.6KB</td>
               </tr>
                              <tr>
                 <td>68</td>
                 <td><a href="download.php?table=questionpapers&id=105&file=2017/questionpapers/IM-5-IT2017-12-04 20:58:13.pdf">IM 2016 End Semester</a></td>
                 <td>Industrial Management</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>66</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>482.6KB</td>
               </tr>
                              <tr>
                 <td>69</td>
                 <td><a href="download.php?table=questionpapers&id=104&file=2017/questionpapers/SOM Papers2017-12-03 19:07:08.pdf">QUESTION papers</a></td>
                 <td>Strength of Material</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>53</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>559.8KB</td>
               </tr>
                              <tr>
                 <td>70</td>
                 <td><a href="download.php?table=questionpapers&id=103&file=2017/questionpapers/New Doc 2017-11-23 (1)2017-12-03 19:01:57.pdf">Last Year Papers Questions Only </a></td>
                 <td>Thermal Science</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>42</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4MB</td>
               </tr>
                              <tr>
                 <td>71</td>
                 <td><a href="download.php?table=questionpapers&id=102&file=2017/questionpapers/Embedded systems ECE-7 EndTerm2017-12-02 23:17:26.pdf">End Term 2016 Paper Solved </a></td>
                 <td>Embedded Systems</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>34</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.2MB</td>
               </tr>
                              <tr>
                 <td>72</td>
                 <td><a href="download.php?table=questionpapers&id=101&file=2017/questionpapers/ECE-7-RADAR2017-12-02 23:15:55.pdf">End Term 2016 Paper Solved </a></td>
                 <td>Radar and Navigation</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>29</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.9MB</td>
               </tr>
                              <tr>
                 <td>73</td>
                 <td><a href="download.php?table=questionpapers&id=100&file=2017/questionpapers/ECE-7-OPTOELECTRIC2017-12-02 23:13:51.pdf">End Term 2016 Paper Solved </a></td>
                 <td>Optoelectronics and Optical Communication</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>34</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6.8MB</td>
               </tr>
                              <tr>
                 <td>74</td>
                 <td><a href="download.php?table=questionpapers&id=99&file=2017/questionpapers/RER - MAE 7th Sem (2016)2017-12-02 21:48:11.pdf">RER 2016 </a></td>
                 <td>Renewable Energy Resources</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>55</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>885.9KB</td>
               </tr>
                              <tr>
                 <td>75</td>
                 <td><a href="download.php?table=questionpapers&id=98&file=2017/questionpapers/Mechatronics (Old) - MAE 7th Sem (2016)2017-12-02 17:45:19.pdf">Mechatronics Old 2015 </a></td>
                 <td>Mechatronics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>34</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>898.1KB</td>
               </tr>
                              <tr>
                 <td>76</td>
                 <td><a href="download.php?table=questionpapers&id=97&file=2017/questionpapers/Mechatronics - MAE 7th Sem (2016)2017-12-02 17:44:49.pdf">Mechatronics 2016 </a></td>
                 <td>Mechatronics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>52</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>858.9KB</td>
               </tr>
                              <tr>
                 <td>77</td>
                 <td><a href="download.php?table=questionpapers&id=96&file=2017/questionpapers/Mechatronics - MAE 7th Sem (2015)2017-12-02 17:44:17.pdf">Mechatronics 2015 </a></td>
                 <td>Mechatronics</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>40</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>795.4KB</td>
               </tr>
                              <tr>
                 <td>78</td>
                 <td><a href="download.php?table=questionpapers&id=95&file=2017/questionpapers/CIM - MAE 7th Sem (2016)2017-12-02 17:43:22.pdf">CIM 2016 </a></td>
                 <td>Computer Integrated Manufacturing</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>57</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>1.1MB</td>
               </tr>
                              <tr>
                 <td>79</td>
                 <td><a href="download.php?table=questionpapers&id=94&file=2017/questionpapers/CAM - MAE 7th Sem (2016)2017-12-02 17:42:25.pdf">CAM 2016 </a></td>
                 <td>Computer Integrated Manufacturing</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>45</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>789.8KB</td>
               </tr>
                              <tr>
                 <td>80</td>
                 <td><a href="download.php?table=questionpapers&id=93&file=2017/questionpapers/CAM - MAE 7th Sem (2015)2017-12-02 17:42:01.pdf">CAM 2015 </a></td>
                 <td>Computer Integrated Manufacturing</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>37</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>709KB</td>
               </tr>
                              <tr>
                 <td>81</td>
                 <td><a href="download.php?table=questionpapers&id=92&file=2017/questionpapers/CAD 401 - MAE 7th Sem (2016)2017-12-02 17:41:03.pdf">CAD 401 2016 </a></td>
                 <td>Computer Aided Design</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>65</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>1.2MB</td>
               </tr>
                              <tr>
                 <td>82</td>
                 <td><a href="download.php?table=questionpapers&id=91&file=2017/questionpapers/CAD - MAE 7th Sem (2016)2017-12-02 17:40:20.pdf">CAD 2016</a></td>
                 <td>Computer Aided Design</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>59</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>901KB</td>
               </tr>
                              <tr>
                 <td>83</td>
                 <td><a href="download.php?table=questionpapers&id=90&file=2017/questionpapers/CAD - MAE 7th Sem (2015)2017-12-02 17:39:28.pdf">CAD 2015 </a></td>
                 <td>Computer Aided Design</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>60</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>747.5KB</td>
               </tr>
                              <tr>
                 <td>84</td>
                 <td><a href="download.php?table=questionpapers&id=89&file=2017/questionpapers/Physics End Sem2017-11-29 13:41:48.pdf">End Sem Question Paper</a></td>
                 <td>Applied Physics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>332</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.5MB</td>
               </tr>
                              <tr>
                 <td>85</td>
                 <td><a href="download.php?table=questionpapers&id=88&file=2017/questionpapers/Maths Previous year papers2017-11-28 16:43:18.pdf">Maths Previous Year Papers</a></td>
                 <td>Applied Mathematics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>503</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>48.7MB</td>
               </tr>
                              <tr>
                 <td>86</td>
                 <td><a href="download.php?table=questionpapers&id=87&file=2017/questionpapers/FOC Last Year pprs2017-11-28 14:36:30.pdf">FOC Last Year Question Papers</a></td>
                 <td>Fundamentals of Computing</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>548</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>50.8MB</td>
               </tr>
                              <tr>
                 <td>87</td>
                 <td><a href="download.php?table=questionpapers&id=86&file=2017/questionpapers/Chemistry Akash2017-11-27 19:32:40.pdf">Chemistry Akash</a></td>
                 <td>Applied Chemistry</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, ECE, EEE</td>
                 <td>642</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>61.6MB</td>
               </tr>
                              <tr>
                 <td>88</td>
                 <td><a href="download.php?table=questionpapers&id=84&file=2017/questionpapers/ds-akash2017-11-11 15:49:28.pdf">End Semester Question Papers Solved </a></td>
                 <td>Data Structure</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>185</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>23.5MB</td>
               </tr>
                              <tr>
                 <td>89</td>
                 <td><a href="download.php?table=questionpapers&id=83&file=2017/questionpapers/ADBA DEC-2016 End Sem2017-11-02 23:09:59.pdf">Dec 2016 End Sem </a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>133</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>17.1MB</td>
               </tr>
                              <tr>
                 <td>90</td>
                 <td><a href="download.php?table=questionpapers&id=82&file=2017/questionpapers/ADBA End Sem - Model Test Paper2017-11-02 23:07:43.pdf">End Sem Question Paper</a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>94</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>22.2MB</td>
               </tr>
                              <tr>
                 <td>91</td>
                 <td><a href="download.php?table=questionpapers&id=81&file=2017/questionpapers/ST 2nd Sessionals Paper2017-11-02 20:45:38.pdf">NIEC 2nd Sessional Paper</a></td>
                 <td>Software Testing</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>73</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>414KB</td>
               </tr>
                              <tr>
                 <td>92</td>
                 <td><a href="download.php?table=questionpapers&id=80&file=2017/questionpapers/ST Akash 7 Sem2017-11-02 09:15:20.pdf">Akash B Tech BCA Mixed </a></td>
                 <td>Software Testing</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>127</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>37.2MB</td>
               </tr>
                              <tr>
                 <td>93</td>
                 <td><a href="download.php?table=questionpapers&id=79&file=2017/questionpapers/DBMS 2nd Sessionals2017-11-01 23:13:54.pdf">2nd Sessionals</a></td>
                 <td>Database Management Systems</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>91</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>499.3KB</td>
               </tr>
                              <tr>
                 <td>94</td>
                 <td><a href="download.php?table=questionpapers&id=78&file=2017/questionpapers/DEC-2016 end sem2017-10-31 22:39:20.pdf">Dec 2016 End Sem</a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>117</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.9MB</td>
               </tr>
                              <tr>
                 <td>95</td>
                 <td><a href="download.php?table=questionpapers&id=77&file=2017/questionpapers/End Sem Model Test Papers2017-10-31 22:22:00.pdf">End Sem Model test papers</a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>74</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>11.3MB</td>
               </tr>
                              <tr>
                 <td>96</td>
                 <td><a href="download.php?table=questionpapers&id=76&file=2017/questionpapers/WC 2nd Sessionals2017-10-31 22:20:34.pdf">2nd Sessionals Model test papers</a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>92</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.2MB</td>
               </tr>
                              <tr>
                 <td>97</td>
                 <td><a href="download.php?table=questionpapers&id=75&file=2017/questionpapers/Cryptography Akash End Sem 20162017-10-30 20:52:36.pdf">End Sem 2016 Solved </a></td>
                 <td>Cryptography and Network Security</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>67</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.1MB</td>
               </tr>
                              <tr>
                 <td>98</td>
                 <td><a href="download.php?table=questionpapers&id=74&file=2017/questionpapers/CRYPTOGRAPHY 2nd Sessional2017-10-30 20:51:00.pdf">Model Test Papers 2nd Sessionals</a></td>
                 <td>Cryptography and Network Security</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>54</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.1MB</td>
               </tr>
                              <tr>
                 <td>99</td>
                 <td><a href="download.php?table=questionpapers&id=73&file=2017/questionpapers/ACN End Sem Dec 20162017-10-27 14:57:30.pdf">December 2016 End Sem </a></td>
                 <td>Advanced Computer Networks</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>80</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.7MB</td>
               </tr>
                              <tr>
                 <td>100</td>
                 <td><a href="download.php?table=questionpapers&id=72&file=2017/questionpapers/ACN-2nd Sessional2017-10-27 14:53:57.pdf">Model Test Papers 2nd Sessionals</a></td>
                 <td>Advanced Computer Networks</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>68</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.8MB</td>
               </tr>
                              <tr>
                 <td>101</td>
                 <td><a href="download.php?table=questionpapers&id=71&file=2017/questionpapers/mathsakash32017-09-27 00:05:47.pdf">Akash</a></td>
                 <td>Applied Mathematics III</td>
                 <!--<td></td>-->
                 <td>CSE, IT, EEE, ECE</td>
                 <td>289</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>19.4MB</td>
               </tr>
                              <tr>
                 <td>102</td>
                 <td><a href="download.php?table=questionpapers&id=70&file=2017/questionpapers/aeaksh32017-09-26 22:54:21.pdf">Akash</a></td>
                 <td>Analog Electronics I</td>
                 <!--<td></td>-->
                 <td>EEE, ECE</td>
                 <td>187</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>20.9MB</td>
               </tr>
                              <tr>
                 <td>103</td>
                 <td><a href="download.php?table=questionpapers&id=68&file=2017/questionpapers/stldakash32017-09-26 19:17:43.pdf">Akash</a></td>
                 <td>Switching Theory and Logic Design</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>289</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>21.6MB</td>
               </tr>
                              <tr>
                 <td>104</td>
                 <td><a href="download.php?table=questionpapers&id=67&file=2017/questionpapers/stldakash32017-09-26 19:14:55.pdf">Akash</a></td>
                 <td>Switching Theory and Logic Design</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>135</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>21.6MB</td>
               </tr>
                              <tr>
                 <td>105</td>
                 <td><a href="download.php?table=questionpapers&id=66&file=2017/questionpapers/sasakash32017-09-22 15:37:17.pdf">S S Aakash Full </a></td>
                 <td>Signals and Systems</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>173</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>21.1MB</td>
               </tr>
                              <tr>
                 <td>106</td>
                 <td><a href="download.php?table=questionpapers&id=65&file=2017/questionpapers/ADBMS 20162017-09-21 23:15:15.pdf">Akash Sessionals 1 </a></td>
                 <td>Advanced Database Administration</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>94</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>929.6KB</td>
               </tr>
                              <tr>
                 <td>107</td>
                 <td><a href="download.php?table=questionpapers&id=64&file=2017/questionpapers/ds,akash32017-09-21 16:05:51.pdf">Akash DS </a></td>
                 <td>Data Structure</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE, EEE</td>
                 <td>183</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>23.5MB</td>
               </tr>
                              <tr>
                 <td>108</td>
                 <td><a href="download.php?table=questionpapers&id=63&file=2017/questionpapers/DM  BI 20162017-09-21 09:36:13.pdf">Aakash Sessional 1 </a></td>
                 <td>Data Mining and Business Intelligence</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>109</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.1MB</td>
               </tr>
                              <tr>
                 <td>109</td>
                 <td><a href="download.php?table=questionpapers&id=62&file=2017/questionpapers/emiaksh32017-09-20 21:51:51.pdf">Akash EIM </a></td>
                 <td>Electronic Instruments and Measurements</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>191</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>31.1MB</td>
               </tr>
                              <tr>
                 <td>110</td>
                 <td><a href="download.php?table=questionpapers&id=61&file=2017/questionpapers/ST2017-09-20 20:51:16.pdf">Software Testing Akash 1st Sessionals </a></td>
                 <td>Software Testing</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>131</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>23.6MB</td>
               </tr>
                              <tr>
                 <td>111</td>
                 <td><a href="download.php?table=questionpapers&id=60&file=2017/questionpapers/New Doc 2017-09-192017-09-19 19:08:38.pdf">Akash First Term </a></td>
                 <td>Software Engineering</td>
                 <!--<td></td>-->
                 <td>CSE, IT</td>
                 <td>47</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.8MB</td>
               </tr>
                              <tr>
                 <td>112</td>
                 <td><a href="download.php?table=questionpapers&id=59&file=2017/questionpapers/WhatsApp Image 2017-09-19 at 52017-09-19 17:09:32.jpeg">1st Sessional Question Paper CSE 2016 September </a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>68</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>172.4KB</td>
               </tr>
                              <tr>
                 <td>113</td>
                 <td><a href="download.php?table=questionpapers&id=58&file=2017/questionpapers/Wireless Communication2017-09-19 16:56:06.pdf">Akash 1st Sessionals</a></td>
                 <td>Wireless Communication</td>
                 <!--<td></td>-->
                 <td>CSE, IT, ECE</td>
                 <td>85</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6.3MB</td>
               </tr>
                              <tr>
                 <td>114</td>
                 <td><a href="download.php?table=questionpapers&id=57&file=2017/questionpapers/OptoElec & Optical Communication ECE-72017-09-18 21:19:29.pdf">Aakash sessional 1</a></td>
                 <td>Optoelectronics and Optical Communication</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>0</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>6MB</td>
               </tr>
                              <tr>
                 <td>115</td>
                 <td><a href="download.php?table=questionpapers&id=56&file=2017/questionpapers/Cryptography Akash End Sem 20162017-09-18 20:29:57.pdf">Akash End Sem 2016</a></td>
                 <td>Advanced Computer Networks</td>
                 <!--<td></td>-->
                 <td>IT,CSE</td>
                 <td>54</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.1MB</td>
               </tr>
                              <tr>
                 <td>116</td>
                 <td><a href="download.php?table=questionpapers&id=55&file=2017/questionpapers/Cryptography Akash 1st Sessional2017-09-18 20:25:14.pdf">Akash 1st Sessionals Code ETIT 403</a></td>
                 <td>Cryptography and Network Security</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>72</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.1MB</td>
               </tr>
                              <tr>
                 <td>117</td>
                 <td><a href="download.php?table=questionpapers&id=54&file=2017/questionpapers/Embedded systems - First Term ECE-72017-09-17 15:12:09.pdf">Akash 1st Sessional </a></td>
                 <td>Embedded Systems</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>36</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>3.2MB</td>
               </tr>
                              <tr>
                 <td>118</td>
                 <td><a href="download.php?table=questionpapers&id=53&file=2017/questionpapers/ACN AKASH 1st Sessional2017-09-17 15:02:46.pdf">Akash for 1st Sessionals</a></td>
                 <td>Advanced Computer Networks</td>
                 <!--<td></td>-->
                 <td>IT,CSE</td>
                 <td>68</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7MB</td>
               </tr>
                              <tr>
                 <td>119</td>
                 <td><a href="download.php?table=questionpapers&id=46&file=MNM akash_2017052619441959287826289b65.96290738.pdf">Akash May 2016 </a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>CIVIL</td>
                 <td>321</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.5MB</td>
               </tr>
                              <tr>
                 <td>120</td>
                 <td><a href="download.php?table=questionpapers&id=45&file=MNM akash_2017052619441959287826289b65.96290738.pdf">Akash May 2016 </a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>161</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.5MB</td>
               </tr>
                              <tr>
                 <td>121</td>
                 <td><a href="download.php?table=questionpapers&id=44&file=MNM akash_2017052619441959287826289b65.96290738.pdf">Akash May 2016 </a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>EEE, ECE</td>
                 <td>267</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.5MB</td>
               </tr>
                              <tr>
                 <td>122</td>
                 <td><a href="download.php?table=questionpapers&id=43&file=MNM akash_2017052619441959287826289b65.96290738.pdf">Akash May 2016 </a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>301</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.5MB</td>
               </tr>
                              <tr>
                 <td>123</td>
                 <td><a href="download.php?table=questionpapers&id=42&file=MNM akash_2017052619441959287826289b65.96290738.pdf">Akash May 2016 </a></td>
                 <td>Microprocessor and Microcontroller</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>259</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.5MB</td>
               </tr>
                              <tr>
                 <td>124</td>
                 <td><a href="download.php?table=questionpapers&id=41&file=WE Akash_201705251650495926d3ff8971f3.47628930.pdf">Akash May 2016 </a></td>
                 <td>Web Engineering</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>255</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.4MB</td>
               </tr>
                              <tr>
                 <td>125</td>
                 <td><a href="download.php?table=questionpapers&id=40&file=WE Akash_201705251650495926d3ff8971f3.47628930.pdf">Akash May 2016 </a></td>
                 <td>Web Engineering</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>256</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.4MB</td>
               </tr>
                              <tr>
                 <td>126</td>
                 <td><a href="download.php?table=questionpapers&id=39&file=AI Akash_201705231320275923ed099fecd9.29549106.pdf">Akash May 2016 </a></td>
                 <td>Artificial Intelligence</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>247</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.4MB</td>
               </tr>
                              <tr>
                 <td>127</td>
                 <td><a href="download.php?table=questionpapers&id=38&file=AI Akash_201705231320275923ed099fecd9.29549106.pdf">Akash May 2016 </a></td>
                 <td>Artificial Intelligence</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>177</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7.4MB</td>
               </tr>
                              <tr>
                 <td>128</td>
                 <td><a href="download.php?table=questionpapers&id=37&file=new doc 2017-05-19 16591ef216adeb58.23396861.pdf">Akash May 2016 </a></td>
                 <td>Data Communication and Networks</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>273</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.1MB</td>
               </tr>
                              <tr>
                 <td>129</td>
                 <td><a href="download.php?table=questionpapers&id=36&file=new doc 2017-05-19 16591ef216adeb58.23396861.pdf">Akash May 2016 </a></td>
                 <td>Data Communication and Networks</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>222</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.1MB</td>
               </tr>
                              <tr>
                 <td>130</td>
                 <td><a href="download.php?table=questionpapers&id=35&file=new doc 2017-05-19 16591ef216adeb58.23396861.pdf">Akash May 2016 </a></td>
                 <td>Data Communication and Networks</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>180</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>10.1MB</td>
               </tr>
                              <tr>
                 <td>131</td>
                 <td><a href="download.php?table=questionpapers&id=34&file=OS 2016 Akash_20170517015559591c9c2fd7c424.16630305.pdf">Aakash Notes</a></td>
                 <td>Operating Systems</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>284</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>18.6MB</td>
               </tr>
                              <tr>
                 <td>132</td>
                 <td><a href="download.php?table=questionpapers&id=33&file=OS 2016 Akash_20170517015559591c9c2fd7c424.16630305.pdf">Aakash Notes</a></td>
                 <td>Operating Systems</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>194</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>18.6MB</td>
               </tr>
                              <tr>
                 <td>133</td>
                 <td><a href="download.php?table=questionpapers&id=32&file=new doc 2017-05-17 10591c5a61afa1e9.47925303.pdf">2016 May Solved Akash </a></td>
                 <td>Operating Systems</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>258</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.8MB</td>
               </tr>
                              <tr>
                 <td>134</td>
                 <td><a href="download.php?table=questionpapers&id=31&file=new doc 2017-05-17 10591c5a61afa1e9.47925303.pdf">2016 May Solved Akash </a></td>
                 <td>Operating Systems</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>161</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.8MB</td>
               </tr>
                              <tr>
                 <td>135</td>
                 <td><a href="download.php?table=questionpapers&id=30&file=new doc 2017-05-15 185919c60208c364.13585386.pdf">2015 May Solved </a></td>
                 <td>Compiler Design</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>259</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.7MB</td>
               </tr>
                              <tr>
                 <td>136</td>
                 <td><a href="download.php?table=questionpapers&id=29&file=new doc 2017-05-15 185919c60208c364.13585386.pdf">2015 May Solved </a></td>
                 <td>Compiler Design</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>138</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>4.7MB</td>
               </tr>
                              <tr>
                 <td>137</td>
                 <td><a href="download.php?table=questionpapers&id=28&file=cd Akash_20170512221620591778bb64b407.63471824.pdf">2016 May Solved </a></td>
                 <td>Compiler Design</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>227</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>11.9MB</td>
               </tr>
                              <tr>
                 <td>138</td>
                 <td><a href="download.php?table=questionpapers&id=27&file=cd Akash_20170512221620591778bb64b407.63471824.pdf">2016 May Solved </a></td>
                 <td>Compiler Design</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>297</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>11.9MB</td>
               </tr>
                              <tr>
                 <td>139</td>
                 <td><a href="download.php?table=questionpapers&id=26&file=6th sem591763c53c1576.42025389.pdf">all subjects 6th sem</a></td>
                 <td>General</td>
                 <!--<td></td>-->
                 <td>CIVIL</td>
                 <td>281</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>7MB</td>
               </tr>
                              <tr>
                 <td>140</td>
                 <td><a href="download.php?table=questionpapers&id=25&file=5th sem59176322d8da36.98236715.pdf">all subjects 5th sem</a></td>
                 <td>General</td>
                 <!--<td></td>-->
                 <td>CIVIL</td>
                 <td>145</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>5.2MB</td>
               </tr>
                              <tr>
                 <td>141</td>
                 <td><a href="download.php?table=questionpapers&id=24&file=-uploads-papers-odd-btech1sem5910a52e1dc939.46355744.pdf">Previous Year papers</a></td>
                 <td>Human Values and Professional Ethics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>315</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>142</td>
                 <td><a href="download.php?table=questionpapers&id=23&file=-uploads-papers-odd-btech1sem5910a48d4c94e4.61789027.pdf">Previous Year papers</a></td>
                 <td>Electrical Technology</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>374</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>143</td>
                 <td><a href="download.php?table=questionpapers&id=22&file=-uploads-papers-odd-btech1sem5910a4349ce2e0.51192874.pdf">Previous Year papers</a></td>
                 <td>Manufacturing Processes</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>341</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>144</td>
                 <td><a href="download.php?table=questionpapers&id=21&file=-uploads-papers-odd-btech1sem5910a3e73f94b9.84457828.pdf">Previous Year papers</a></td>
                 <td>Applied Physics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>491</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>145</td>
                 <td><a href="download.php?table=questionpapers&id=20&file=-uploads-papers-odd-btech1sem5910a35f2a0de9.20238781.pdf">Previous Year papers</a></td>
                 <td>Applied Mathematics</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>278</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>146</td>
                 <td><a href="download.php?table=questionpapers&id=19&file=-uploads-papers-odd-btech1sem5910a319523287.81925977.pdf">Previous Year papers</a></td>
                 <td>Applied Chemistry</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>317</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>2MB</td>
               </tr>
                              <tr>
                 <td>147</td>
                 <td><a href="download.php?table=questionpapers&id=18&file=Java Dec-2015 QP585cea9840f921.21141673.pdf">Dec 2015 End Sem Java QP</a></td>
                 <td>Java Programming</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>312</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>13MB</td>
               </tr>
                              <tr>
                 <td>148</td>
                 <td><a href="download.php?table=questionpapers&id=17&file=Java Dec-2015 QP585cea9840f921.21141673.pdf">Dec 2015 End Sem Java QP</a></td>
                 <td>Java Programming</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>286</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>13MB</td>
               </tr>
                              <tr>
                 <td>149</td>
                 <td><a href="download.php?table=questionpapers&id=16&file=IM Sem 55856769ba785f4.90118542.pdf">5th Sem Dec 2015 Question Paper</a></td>
                 <td>Industrial Management</td>
                 <!--<td></td>-->
                 <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                 <td>339</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.9MB</td>
               </tr>
                              <tr>
                 <td>150</td>
                 <td><a href="download.php?table=questionpapers&id=15&file=IM Sem 55856769ba785f4.90118542.pdf">5th Sem Dec 2015 Question Paper</a></td>
                 <td>Industrial Management</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>255</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.9MB</td>
               </tr>
                              <tr>
                 <td>151</td>
                 <td><a href="download.php?table=questionpapers&id=14&file=IM Sem 55856769ba785f4.90118542.pdf">5th Sem Dec 2015 Question Paper</a></td>
                 <td>Industrial Management</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>286</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.9MB</td>
               </tr>
                              <tr>
                 <td>152</td>
                 <td><a href="download.php?table=questionpapers&id=13&file=IM Sem 55856769ba785f4.90118542.pdf">5th Sem Dec 2015 Question Paper</a></td>
                 <td>Industrial Management</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>191</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>9.9MB</td>
               </tr>
                              <tr>
                 <td>153</td>
                 <td><a href="download.php?table=questionpapers&id=12&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>CIVIL</td>
                 <td>118</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>154</td>
                 <td><a href="download.php?table=questionpapers&id=11&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>MAE</td>
                 <td>252</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>155</td>
                 <td><a href="download.php?table=questionpapers&id=10&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>EEE</td>
                 <td>203</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>156</td>
                 <td><a href="download.php?table=questionpapers&id=9&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>ECE</td>
                 <td>148</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>157</td>
                 <td><a href="download.php?table=questionpapers&id=8&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>286</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>158</td>
                 <td><a href="download.php?table=questionpapers&id=7&file=New Doc 85846802b0e05f4.50799577.pdf">End Sem Paper 2015 </a></td>
                 <td>Communication Skills for Professionals</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>326</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>211.9KB</td>
               </tr>
                              <tr>
                 <td>159</td>
                 <td><a href="download.php?table=questionpapers&id=6&file=cs akash201612010128292305853a6295023b7.56999159.pdf">Com Sys Paper IPU</a></td>
                 <td>Communication Systems</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>384</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>5.7MB</td>
               </tr>
                              <tr>
                 <td>160</td>
                 <td><a href="download.php?table=questionpapers&id=5&file=SE-5th Sem QP5849184d4e9969.63875363.pdf">5th Sem Solved Question Paper</a></td>
                 <td>Software Engineering</td>
                 <!--<td></td>-->
                 <td>CSE</td>
                 <td>176</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.9MB</td>
               </tr>
                              <tr>
                 <td>161</td>
                 <td><a href="download.php?table=questionpapers&id=4&file=SE-5th Sem QP5849184d4e9969.63875363.pdf">5th Sem Solved Question Paper</a></td>
                 <td>Software Engineering</td>
                 <!--<td></td>-->
                 <td>IT</td>
                 <td>275</td>
                 <!--<td></td>-->
                 <td>NotesHub</td>
                 <td>8.9MB</td>
               </tr>
               
           </tbody>

         </table>

       </div>
       <br>
      <br>
<div class="container marketing">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script type="text/javascript">
//for dynamic subject list
$(document).ready(function(){
  $('#semester').on('change',function(){
    var semester = $(this).val();
    var branch = $('#branch').val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('#branch').on('change',function(){
    var semester = $('#semester').val();
    var branch = $(this).val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('.load_sub1').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects1').last().html(html);
        }
    });
  });
  $('.load_sub2').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects2').last().html(html);
        }
    });
  });
  $('.load_sub3').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects3').last().html(html);
        }
    });
  });
});
</script>

<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
    <img class="img-circle" src="images/6.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Experience</h2>
    <p>Its been an year since we started NotesHub, therefore we know what you need, when you need and how much you need.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/7.png" alt="Generic placeholder image" width="140" height="140">
    <h2>100K+ Visits</h2>
    <p>We have seen 100 Thousand plus visits on
NotesHub and we are proud that we could
deliver so much value.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/8.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Quality
</h2>
    <p>One of the most important thing to us is that the material
we provide you is of exquisite quality. We know its frustrating to spend time on useless material.</p>

  </div><!-- /.col-lg-4 -->
</div><!-- /.row -->



<!--CUSTOM ADVERTISEMENT True Value Smartphones-->
      <a href="https://goo.gl/WkPCzV" style="text-decoration:none;">
        <div class="container text-center">
        Sponsored
        <div class="row" style="background: #eee; font-size: 1.2em; padding: 15px;">

          <div class="col-lg-3 col-lg-3">
            <p><img style="width:100%;" src="images/ad.jpg"></p>
          </div>

          <div class="col-lg-6 col-lg-6">
            <p style="font-size: 2em; font-weight: bold; color:#225bc2;">True Value Smartphone</p>
            <p>We buy and sell used or preowned smartphone at <strong>Best Price</strong></p>

            <img src="https://www.apple.com/favicon.ico">
            <img src="https://statics.oneplus.net/v3/img/common/logo.png">
            <img src="https://www.skymartbw.com/wp-content/uploads/2010/04/lg-logo.png" width="96">
            <img src="https://www.senheng.com.my/media/catalog/category/xiaomi.png"> and more...
          </div>

          <div class="col-lg-3 col-md-3" style="text-align: center;">
            <p style="width: 100%;"><strong>Office address:</strong> 8/66, 3<sup>rd</sup> floor Vijay Nagar Double Storey, Delhi 110009<br/>Near North Campus DU</p>
            <p><a href="tel:8860828901"><span class="glyphicon glyphicon-earphone"></span> 8860828901</a></p>
          </div>
        </div>
        </div>
      </a>
      <br/>
      <hr>


<!-- START THE FEATURETTES -->
  <!--GOOGLE ADS-->
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- text_and_display -->
  <ins class="adsbygoogle ad-type-1"
       style="display:block"
       data-ad-client="ca-pub-6153632791841759"
       data-ad-slot="9543810896"
       data-ad-format="auto"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>

<hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">NOTES</h2>
      <p class="lead">NotesHub came into existence because we experienced the same problem that you all face during exams. Standing for hours at photocopy shops and gathering notes wastes alot of time..</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/1.jpg" alt="Find Notes and study material">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7 col-md-push-5">
      <h2 class="featurette-heading">BOOKS</h2>
      <p class="lead">Spending Rs. 5000+ every semester to buy books on rent and then receiving only 30% of the cost is wastage of money too. Using NotesHub, you can get the books at 50% price with all the supplementary material. We are also trying to arrange all the eBooks we can!
</p>
    </div>
    <div class="col-md-5 col-md-pull-7">
      <img class="featurette-image img-responsive center-block" src="images/2.jpg" alt="Engineering books">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">PRACTICAL FILES</h2>
      <p class="lead">We all HATE making practical files because they are nothing but making copies. Also, arranging the files and material is a task in itself. Here, we are trying to bridge the gap between the colleges so that everyone can make their files quick and easy and focus on whats more important i.e. learning to perform the practical</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/3.jpg" alt="Find practical files">
    </div>
  </div>

  <hr class="featurette-divider">


        <div class="row featurette">
          <div class="col-md-7 col-md-push-5">
            <h2 class="featurette-heading">QUESTION PAPERS</h2>
            <p class="lead">NotesHub is also the place to get all the previous year question papers  with solutions. We also try to arrange for different types of assignments.
  </p>
          </div>
          <div class="col-md-5 col-md-pull-7">
            <img class="featurette-image img-responsive center-block" src="images/4.jpg" alt="Previous year question papers">
          </div>
        </div>

        <!--<hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading">INTERNSHIPS</h2>
            <p class="lead">Most of us are not able to score an internship because we are looking at the wrong places. Also, due to lack of information, we miss opportunities. This is what we identified and hence NotesHub has a <b>Internship Feed</b>  that will keep you up to date with all the new opportunities in town.</p>

          </div>
          <div class="col-md-5">
            <img class="featurette-image img-responsive center-block" src="images/5.jpg" alt="Find Internships">
          </div>
        </div>!-->

        <hr class="featurette-divider ad-type-2">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    		<ins class="adsbygoogle"
    		     style="display:block"
    		     data-ad-format="fluid"
    		     data-ad-layout-key="-8i+1w-dq+e9+ft"
    		     data-ad-client="ca-pub-6153632791841759"
    		     data-ad-slot="7024802225"></ins>
    		<script>
    		     (adsbygoogle = window.adsbygoogle || []).push({});
    		</script>
</div>
  <!-- /.container -->
		<hr class="featurette-divider">

<!-- /END THE FEATURETTES -->


  <div class="container-fluid">

    <div class="row">

                  <div class="about-us-parallax">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofAboutUs">Your Last Minute Companion</span>
                      <br>
                      <br>
                      <p style="font-size:x-large; color: white;">Nothing makes a person more productive than the <b>"Last Minute"</b></p>
                    </div>
                  </div>
                  </div>

                  <div class="row" id="about">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">About Us</h3>
                    <p class="description-aboutus">Trying to make your lives easier. That&rsquo;s it. Nothing fancy.</p>
                  </div>
                  </div>

                  <div class="row">
                  <div class="contactus-parallax ">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofContactUs">Hello!<br>Let&rsquo;s Talk.</span>
                      <br>

                    </div>
                  </div>
                  </div>

                  <div class="row" id="contact">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">Suggestions, Feedback, Advice?</h3>

                    <p class="description-aboutus">We thrive to improve. Drop us a mail.</p>
                  </div>
                  </div>
      <br>
  </div>


      <!--############################# form ##########################################-->
        <div class="container-fluid">
            <div class="row">


                <div class="col-md-8">
                    <div class="well well-sm">
                        <form action="contact.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Enter name" required="required" name="name"/>
                                </div>
                                <div class="form-group">
                                    <label for="email">
                                        Email Address</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                        </span>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" name="email"/></div>
                                </div>
                                <div class="form-group">
                                    <label for="subject">
                                        Subject</label>
                                    <select class="form-control" required="required" name="subject">
                                        <option value="" selected disabled>Choose One:</option>
                                        <option value="Non-availability of material">Non-availability of material</option>
                                        <option value="Buy/Sell Book">Buy/Sell Book</option>
                                        <option value="Just to say Hello!">Just to say Hello!</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Message</label>
                                    <textarea id="message" class="form-control" rows="9" cols="25" required="required"
                                        placeholder="Message" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                                    Send Message</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>


                <div class="col-md-4" style="text-align: center;">
                    <legend>Our Motto</legend>
                    <img src="images/back.jpg" style="min-height: 250px; width: 100%; margin-top: -15px;">

                </div>


            </div>

          </div><!--container fluid ends -->


      <!-- ############################# form ########################################## -->

        <br>
        <br>

   <div class="container-fluid">
                  <div class="row">
                    <div class="followUs-parallax">
                    <div class="caption col-md-9 col-sm-12 col-xs-12">
                    <br>
                    <br>
                    <br>
                      <div style="float: right;" class="social">
                      <span style="font-size: 25px; color: white;">We don&rsquo;t mind Stalking!</span>


                      <br>
                      <a href="https://www.facebook.com/TeamNotesHub/" target="blank" style="color: white  !important;"><i  class="fa fa-facebook-square fa-5x social"></i></a>
                      &nbsp;&nbsp;
                      <a href="https://www.instagram.com/_noteshub_/" target="blank" style="color: white  !important;"><i class="fa fa-instagram fa-5x" aria-hidden="true"></i></a>
                      </div>

                    </div>
                  </div>
                  </div>

    <br>
    <br>


                    <div class="row">
                      <div style="text-align: center;" >
                        <h2>Thank You.</h2>
                      </div>
                    </div>
    <br>
    <br>

    </div>







    <!-- FOOTER -->

  <footer class="footer-basic-centered" style="padding-top: 0 !important; padding-bottom: 10px;">


    <p class = "footer-company-motto" style="color: white;padding: 8px; font-style: 20px;" >NotesHub</p>

    <p class="footer-company-name">NotesHub | SPI &copy; 2016-18</p>

    <p class="footer-company-name"><a href="privacy_policy.html" target="_blank">Privacy Policy</a> | <a href="terms_and_conditions.html" target="_blank">Terms and Conditions</a></p>

  </footer>
  <!--INCLUDING SIGNIN SIGNUP MODALS -->
  <!--Modals-->

<!-- user login -->
<div class="modal fade"  id="userLogin" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">User Login</h4>
			</div>
			<form action="loginScript.php" method="post">
			<div class="modal-body">

					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword2">Password</label>
						<input required type="password" class="form-control" id="exampleInputPassword2" placeholder="Password" name="password">
						<span><a href="#" data-toggle="modal" data-target="#forgotPassword">Forgot Password?</a></span>

					</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Login</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- forgot password -->
<div class="modal fade"  id="forgotPassword" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Forgot Password?</h4>
			</div>
			<form action="recovery.php" method="post">
			<div class="modal-body">
					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Your registered email id" name="email">
					</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- signup -->
<div class="modal fade" id="signUp" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Sign Up</h4>
			</div>
			<form action = "register.php" method="post">
				<div class="modal-body">
					<div class="form-group">
						<label for="">Name</label>
						<input required type="text" name="name" pattern="[a-zA-Z]+[a-zA-Z ]*" class="form-control"  placeholder="Name (only letters and spaces are alllowed)">
					</div>

					<div class="form-group">
						<label for="">Email ID</label>
						<input required type="email" name="email" class="form-control" placeholder="Email">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input required type="password" name="password" minlength="8" maxlength="32" class="form-control" id="exampleInputPassword1" placeholder="Password (must be of at least 8 characters)">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Mobile Number</label>
						<input required type="tel" name="phno" pattern="[7-9]{1}[0-9]{9}" class="form-control" id="phoneNumber" placeholder="Mobile Number (must start with7, 8, or 9 and be of 10 digits)">
					</div>

					<div class="form-group">
					<label for="college">College</label>
					<select required name="college" class="form-control">
							<option value="" selected disabled>Select College</option>
							<option value="Ambedkar Institute of Advanced Communication Technologies and Research">Ambedkar Institute of Advanced Communication Technologies and Research</option><option value="Amity School of Engineering and Technology">Amity School of Engineering and Technology</option><option value="B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat">B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat</option><option value="Bhagwan Parshuram Institute of Technology">Bhagwan Parshuram Institute of Technology</option><option value="Bharati Vidyapeeth's College of Engineering">Bharati Vidyapeeth's College of Engineering</option><option value="Ch. B.P. Government Engineering College, Delhi">Ch. B.P. Government Engineering College, Delhi</option><option value="Delhi Technical Campus">Delhi Technical Campus</option><option value="Guru Tegh Bahadur Institute of Technology">Guru Tegh Bahadur Institute of Technology</option><option value="HMR Institute of Technology & Management">HMR Institute of Technology & Management</option><option value="JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)">JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)</option><option value="Maharaja Agrasen Institute of Technology">Maharaja Agrasen Institute of Technology</option><option value="Maharaja Surajmal Institute of Technology">Maharaja Surajmal Institute of Technology</option><option value="Northern India Engineering College">Northern India Engineering College</option><option value="University School of Information and Communication Technology">University School of Information and Communication Technology</option>					</select>
					</div>

					<div class="form-group">
					<label for="college">Branch</label>
					<select required name = "branch" class="form-control">
							<option value="" selected disabled>Select Branch</option>
							<option value="cse">CSE</option>
							<option value="it">IT</option>
							<option value="mae">MAE</option>
							<option value="civil">CIVIL</option>
							<option value="eee">EEE</option>
							<option value="ece">ECE</option>
					</select>
					</div>

					<div class="form-group">
					<label for="college">Nearest Metro Station</label>
					<select required name = "nms" class="form-control">
							<option value="" selected disabled>Select Nearest Metro Station</option>
							<option value="ADARSH NAGAR">ADARSH NAGAR</option><option value="AIIMS">AIIMS</option><option value="AKSHARDHAM">AKSHARDHAM</option><option value="ANAND VIHAR">ANAND VIHAR</option><option value="ARJANGARH">ARJANGARH</option><option value="ASHOK PARK MAIN">ASHOK PARK MAIN</option><option value="AZADPUR">AZADPUR</option><option value="BADARPUR">BADARPUR</option><option value="BADKAL MOR">BADKAL MOR</option><option value="BARAKHAMBA">BARAKHAMBA</option><option value="BATA CHOWK">BATA CHOWK</option><option value="BOTANICAL GARDEN">BOTANICAL GARDEN</option><option value="CENTRAL SECRETARIAT">CENTRAL SECRETARIAT</option><option value="CHANDNI CHOWK">CHANDNI CHOWK</option><option value="CHAWRI BAZAR">CHAWRI BAZAR</option><option value="CHHATTARPUR">CHHATTARPUR</option><option value="CIVIL LINES">CIVIL LINES</option><option value="DELHI AERO CITY">DELHI AERO CITY</option><option value="DELHI GATE">DELHI GATE</option><option value="DHAULA KUAN">DHAULA KUAN</option><option value="DILSHAD GARDEN">DILSHAD GARDEN</option><option value="DWARKA">DWARKA</option><option value="DWARKA MOR">DWARKA MOR</option><option value="DWARKA SEC 10">DWARKA SEC 10</option><option value="DWARKA SEC 11">DWARKA SEC 11</option><option value="DWARKA SEC 12">DWARKA SEC 12</option><option value="DWARKA SEC 13">DWARKA SEC 13</option><option value="DWARKA SEC 14">DWARKA SEC 14</option><option value="DWARKA SEC 21">DWARKA SEC 21</option><option value="DWARKA SEC 8">DWARKA SEC 8</option><option value="DWARKA SEC 9">DWARKA SEC 9</option><option value="ESCORTS MUJESAR">ESCORTS MUJESAR</option><option value="G.T.B. NAGAR">G.T.B. NAGAR</option><option value="GHITORNI">GHITORNI</option><option value="GOLF COURSE">GOLF COURSE</option><option value="GOVIND PURI">GOVIND PURI</option><option value="GREEN PARK">GREEN PARK</option><option value="GURU DRONACHARYA">GURU DRONACHARYA</option><option value="HAIDERPUR BADLI MOR">HAIDERPUR BADLI MOR</option><option value="HAUZ KHAS">HAUZ KHAS</option><option value="HUDA CITY CENTRE">HUDA CITY CENTRE</option><option value="I.G.I. AIRPORT">I.G.I. AIRPORT</option><option value="IFFCO CHOWK">IFFCO CHOWK</option><option value="INA">INA</option><option value="INDER LOK">INDER LOK</option><option value="INDRAPRASTHA">INDRAPRASTHA</option><option value="ITO">ITO</option><option value="JAHANGIRPURI">JAHANGIRPURI</option><option value="JAMA MASJID">JAMA MASJID</option><option value="JAMIA MILIA ISLAMIYA">JAMIA MILIA ISLAMIYA</option><option value="JANAK PURI EAST">JANAK PURI EAST</option><option value="JANAK PURI WEST">JANAK PURI WEST</option><option value="JANGPURA">JANGPURA</option><option value="JANPATH">JANPATH</option><option value="JASOLA APOLLO">JASOLA APOLLO</option><option value="JASOLA VIHAR">JASOLA VIHAR</option><option value="JHANDEWALAN">JHANDEWALAN</option><option value="JHIL MIL">JHIL MIL</option><option value="JLN STADIUM">JLN STADIUM</option><option value="JORBAGH">JORBAGH</option><option value="KAILASH COLONY">KAILASH COLONY</option><option value="KALINDI KUNJ">KALINDI KUNJ</option><option value="KALKAJI MANDIR">KALKAJI MANDIR</option><option value="KANHAIYA NAGAR">KANHAIYA NAGAR</option><option value="KARKAR DUMA">KARKAR DUMA</option><option value="KAROL BAGH">KAROL BAGH</option><option value="KASHMERE GATE">KASHMERE GATE</option><option value="KAUSHAMBI">KAUSHAMBI</option><option value="KESHAV PURAM">KESHAV PURAM</option><option value="KHAN MARKET">KHAN MARKET</option><option value="KIRTI NAGAR">KIRTI NAGAR</option><option value="KOHAT ENCLAVE">KOHAT ENCLAVE</option><option value="LAJPAT NAGAR">LAJPAT NAGAR</option><option value="LAL QUILA">LAL QUILA</option><option value="LAXMI NAGAR">LAXMI NAGAR</option><option value="LOK KALYAN MARG">LOK KALYAN MARG</option><option value="M G ROAD">M G ROAD</option><option value="MADI PUR">MADI PUR</option><option value="MALVIYA NAGAR">MALVIYA NAGAR</option><option value="MANDI HOUSE">MANDI HOUSE</option><option value="MANSAROVAR PARK">MANSAROVAR PARK</option><option value="MAYUR VIHAR-I">MAYUR VIHAR-I</option><option value="MAYUR VIHAR-I EXT">MAYUR VIHAR-I EXT</option><option value="MEWALA MAHARAJPUR">MEWALA MAHARAJPUR</option><option value="MODEL TOWN">MODEL TOWN</option><option value="MOHAN ESTATE">MOHAN ESTATE</option><option value="MOOLCHAND">MOOLCHAND</option><option value="MOTI NAGAR">MOTI NAGAR</option><option value="MUNDKA">MUNDKA</option><option value="NANGLOI">NANGLOI</option><option value="NANGLOI RLY. STATION">NANGLOI RLY. STATION</option><option value="NAWADA">NAWADA</option><option value="NEELAM CHOWK AJRONDA">NEELAM CHOWK AJRONDA</option><option value="NEHRU PLACE">NEHRU PLACE</option><option value="NETAJI SUBHASH PLACE">NETAJI SUBHASH PLACE</option><option value="NEW ASHOK NAGAR">NEW ASHOK NAGAR</option><option value="NEW DELHI">NEW DELHI</option><option value="NHPC CHOWK">NHPC CHOWK</option><option value="NIRMAN VIHAR">NIRMAN VIHAR</option><option value="NOIDA CITY CENTRE">NOIDA CITY CENTRE</option><option value="NOIDA SEC 15">NOIDA SEC 15</option><option value="NOIDA SEC 16">NOIDA SEC 16</option><option value="NOIDA SEC 18">NOIDA SEC 18</option><option value="NSIC OKHLA">NSIC OKHLA</option><option value="OKHLA">OKHLA</option><option value="OKHLA BIRD SANCTUARY">OKHLA BIRD SANCTUARY</option><option value="OKHLA VIHAR">OKHLA VIHAR</option><option value="OLD FARIDABAD">OLD FARIDABAD</option><option value="PASCHIM VIHAR (EAST)">PASCHIM VIHAR (EAST)</option><option value="PASCHIM VIHAR (WEST)">PASCHIM VIHAR (WEST)</option><option value="PATEL CHOWK">PATEL CHOWK</option><option value="PATEL NAGAR">PATEL NAGAR</option><option value="PEERA GARHI">PEERA GARHI</option><option value="PITAM PURA">PITAM PURA</option><option value="PRAGATI MAIDAN">PRAGATI MAIDAN</option><option value="PRATAP NAGAR">PRATAP NAGAR</option><option value="PREET VIHAR">PREET VIHAR</option><option value="PUL BANGASH">PUL BANGASH</option><option value="PUNJABI BAGH">PUNJABI BAGH</option><option value="QUTAB MINAR">QUTAB MINAR</option><option value="RAJDHANI PARK">RAJDHANI PARK</option><option value="RAJENDRA PLACE">RAJENDRA PLACE</option><option value="RAJIV CHOWK">RAJIV CHOWK</option><option value="RAJOURI GARDEN">RAJOURI GARDEN</option><option value="RAMESH NAGAR">RAMESH NAGAR</option><option value="RITHALA">RITHALA</option><option value="RK ASHRAM MARG">RK ASHRAM MARG</option><option value="ROHINI EAST">ROHINI EAST</option><option value="ROHINI SECTOR 18,19">ROHINI SECTOR 18,19</option><option value="ROHINI WEST">ROHINI WEST</option><option value="SAKET">SAKET</option><option value="SAMAYPUR BADLI">SAMAYPUR BADLI</option><option value="SARAI">SARAI</option><option value="SARITA VIHAR">SARITA VIHAR</option><option value="SATGURU RAM SINGH MARG">SATGURU RAM SINGH MARG</option><option value="SECTOR-28">SECTOR-28</option><option value="SEELAMPUR">SEELAMPUR</option><option value="SHADIPUR">SHADIPUR</option><option value="SHAHDARA">SHAHDARA</option><option value="SHASTRI NAGAR">SHASTRI NAGAR</option><option value="SHASTRI PARK">SHASTRI PARK</option><option value="SHIVAJI PARK">SHIVAJI PARK</option><option value="SHIVAJI STADIUM">SHIVAJI STADIUM</option><option value="SIKANDARPUR">SIKANDARPUR</option><option value="SUBHASH NAGAR">SUBHASH NAGAR</option><option value="SUKHDEV VIHAR">SUKHDEV VIHAR</option><option value="SULTANPUR">SULTANPUR</option><option value="SURAJMAL STADIUM">SURAJMAL STADIUM</option><option value="TAGORE GARDEN">TAGORE GARDEN</option><option value="TILAK NAGAR">TILAK NAGAR</option><option value="TIS HAZARI">TIS HAZARI</option><option value="TUGHLAKABAD">TUGHLAKABAD</option><option value="UDYOG BHAWAN">UDYOG BHAWAN</option><option value="UDYOG NAGAR">UDYOG NAGAR</option><option value="UTTAM NAGAR EAST">UTTAM NAGAR EAST</option><option value="UTTAM NAGAR WEST">UTTAM NAGAR WEST</option><option value="VAISHALI">VAISHALI</option><option value="VIDHAN SABHA">VIDHAN SABHA</option><option value="VISHWAVIDYALAYA">VISHWAVIDYALAYA</option><option value="WELCOME">WELCOME</option><option value="YAMUNA BANK">YAMUNA BANK</option>					</select>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Sign Up" />
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- OPEN UPLOAD CSS FILE -->
<link rel="stylesheet" type="text/css" href="dist/css/openUpload.css">

<!-- OPEN UPLOAD BUTTON -->
<div href="#" id="open-upload-button" class="btn btn-circle btn-primary" data-toggle="modal" data-target="#openUpload">
	+ &nbsp;upload
</div>

<!-- OPEN UPLOAD MODAL -->
<div class="modal fade" id="openUpload" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<div class="container" style="padding:0;">
				<span class="close" type="button" data-dismiss="modal" aria-label="Close"><span style="vertical-align: text-top;" aria-hidden="true" class="glyphicon glyphicon-menu-left"></span></span>
				<h2 class="modal-title" style="display: inline-block;">&nbsp;&nbsp;Upload and Share</h2>
			</div>
		</div>
		
		<div class="modal-body container">
			<p>Upload your study material and be a helping hand to your buddies out there.</p>
			<br/>
			<div style="display:none;">
				<span id="uploadpercentage"></span>
				<div class="progress">
				    <div style="background:#000;" class="bar"></div >
				    <div class="percent">0%</div >
				</div>
				<div id="status"></div>
			</div>
			  <progress id="progressBar" value="0" max="100" style="width:100%; transition:.2s ease-in-out; display:none"></progress>
			  <h3 id="status"></h3>
			  <p id="loaded_n_total"></p>
			  
			  <!--<div id="bar_blank">
			   <div id="bar_color"></div>
			  </div>
			  <div id="status"></div>-->
			
			<form action="open_upload_request.php" enctype="multipart/form-data" method="post" class="form-horizontal" id="open-upload-form">
			           <!--<input type="hidden" value="open-upload-form"
    name="PHP_SESSION_UPLOAD_PROGRESS">-->

			        <div class="form-group container row">
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios1" value="notes" required>
			            <label class="form-check-label" for="exampleRadios1">
			              Notes
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios2" value="practicalfiles" required>
			            <label class="form-check-label" for="exampleRadios2">
			              Practical Files
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios3" value="questionpapers" required>
			            <label class="form-check-label" for="exampleRadios3">
			              Question Papers
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios4" value="ebooks" required>
			            <label class="form-check-label" for="exampleRadios4">
			              eBooks
			            </label>
			          </div>
			        </div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Attach file</label>
					<div class="col-sm-10">
						<input required type="file" class="form-control" placeholder="" name="file" accept=".pdf,.doc,.docx,.rtf,.ppt,.pptx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" >
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Topic</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Topic" name="topic">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Subject</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Subject" name="subject" id="subject" autocomplete="off">
						<div id="subjectList"></div>
					</div>
				</div>
			        <div class="form-group">
			          <label class="col-sm-2 control-label" for="">Credits</label>
			          <div class="col-sm-10">
			            <input required type="text" class="form-control" placeholder="Your Name" name="credit">
			          </div>
			        </div>
			
				<div class="col-sm-offset-2">
					<input type="submit" class="btn btn-primary" value="Upload :)" onSubmit="uploadFile();">
				</div>
			</form>
		</div>
		
	</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
 $(document).ready(function(){
	  $('#subject').keyup(function(e){
	  	var code= e.keycode | e.which;
	  	//alert(code);
	  	if(code!=38&&code!==40) { 
	  	//var e= $.Event('keyup'); e.which=code; $("#subject").trigger(e); 
		   var query = $(this).val();
		   if(query != '')
		   {
				$.ajax({
					 url:"subject_autocomplete.php",
					 method:"POST",
					 data:{query:query},
					 success:function(data)
					 {
						  $('#subjectList').fadeIn();
						  $('#subjectList').html(data);
					 }
				});
		   }else if(query == ''){
			$('#subjectList').fadeOut();
		   }
	  }
	  });
	  
	  $(document).on('click', '.list-group-item', function(){
		   $('#subject').val($(this).text());
		   $('#subjectList').fadeOut();
	  });
 });

</script>

<!--<script>

//Upload Progress bar
/*function toggleBarVisibility() {
    var e = document.getElementById("bar_blank");
   // e.style.display = (e.style.display == "block") ? "none" : "block";
}

function createRequestObject() {
    var http;
    if (navigator.appName == "Microsoft Internet Explorer") {
        http = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else {
        http = new XMLHttpRequest();
    }
    return http;
}

function sendRequest() {
    var http = createRequestObject();
    http.open("GET", "progress.php");
    http.onreadystatechange = function () { handleResponse(http); };
    http.send(null);
}

function handleResponse(http) {
    var response;
    if (http.readyState == 4) {
        response = http.responseText;
        alert("Response"+response);
        document.getElementById("bar_color").style.width = response + "%";
        document.getElementById("status").innerHTML = response + "%";

        if (response < 100) {
            setTimeout("sendRequest()", 1000);
        }
        else {
            toggleBarVisibility();
            document.getElementById("status").innerHTML = "Done.";
        }
    }
}

function startUpload() {
    toggleBarVisibility();
    setTimeout("sendRequest()", 1000);
}

(function () {
    document.getElementById("open-upload-form").onsubmit = startUpload;
})();*/
</script>-->

<script>

//FETCHING FILE UPLOAD PERCENTAGE 
function get(el) {
  return document.getElementById(el);
}

function uploadFile() {
  var file = $('input[name="file"]')[0].files[0];
  var title = $('input[name="title"]');
  var subject = $('input[name="subject"]');
  var credit = $('input[name="credit"]');
  var category = $('input[name="category"]');
  // alert(file.name+" | "+file.size+" | "+file.type);
  var formdata = new FormData();
  formdata.append("file", file);
  formdata.append("title", title);
  formdata.append("subject", subject);
  formdata.append("credit", credit);
  formdata.append("category", category);
  var ajax = new XMLHttpRequest();
  ajax.upload.addEventListener("progress", progressHandler, false);
  ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  ajax.open("POST", "open_upload_request.php");
  ajax.send(formdata);
}

function progressHandler(event) {
$('progress').show();
$('#open-upload-form').fadeOut();
  get("loaded_n_total").innerHTML = Number(event.loaded/event.total*100).toFixed(2) + " % Uploaded ";
  var percent = (event.loaded / event.total) * 100;
  get("progressBar").value = Math.round(percent);
  get("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
  get("status").innerHTML = event.target.responseText;
  get("progressBar").value = 0;
}

function errorHandler(event) {
  get("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
  get("status").innerHTML = "Upload Aborted";
}
</script>




     <!-- Bootstrap core JavaScript
     ================================================== -->
     <!-- Placed at the end of the document so the pages load faster -->
     <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="dist/js/bootstrap.min.js"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="assets/js/vendor/holder.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>


<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="tables/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>


<!--<script>
 $('#internTable').DataTable( {
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.modal( {
                    header: function ( row ) {
                        var data = row.data();
                        return 'Details for internship in '+data[1];
                    }
                } ),
                renderer: $.fn.dataTable.Responsive.renderer.tableAll( {
                    tableClass: 'table'
                } )
            }
        }
    } );
</script>-->

     <!--Banner type text effect , navbar out of focus close -->
     <script src="dist/js/typed.js"></script>
     <script src="dist/js/banner.js"></script>

     <script src="dist/js/sellBooks.js"></script>


     <script type="text/javascript">

               $('#resultsTable').DataTable( {
                "pagingType": "full",
               responsive: true,
               columnDefs: [
                   { responsivePriority: 1, targets: 0 },
                   { responsivePriority: 2, targets: 1 }
               ]
           } );
     </script>




     <script src="dist/js/select2.js"></script>

       <script type="text/javascript">

         $(document).ready(function() {
           $(".semester").select2({
             placeholder: "Select Semester",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".branch").select2({
             placeholder: "Select Branch",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".subject").select2({
             placeholder: "Select Subject",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

<!--<script>
      window.fbMessengerPlugins = window.fbMessengerPlugins || {
        init: function () {
          FB.init({
            appId            : '1678638095724206',
            autoLogAppEvents : true,
            xfbml            : true,
            version          : 'v2.10'
          });
        }, callable: []
      };
      window.fbAsyncInit = window.fbAsyncInit || function () {
        window.fbMessengerPlugins.callable.forEach(function (item) { item(); });
        window.fbMessengerPlugins.init();
      };
      setTimeout(function () {
        (function (d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) { return; }
          js = d.createElement(s);
          js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      }, 0);
      </script>

      <div
        class="fb-customerchat"
        page_id="910123809127452"
        ref="">
      </div>-->

     </body>
     </html>
