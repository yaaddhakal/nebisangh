<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="googlebot" content="noodp">
    <meta name="description" content="One  stop solution for engineering students">
    <meta name="keywords" content="GGSIPU,IPU,NotesHub,Notes,B.Tech,engg,engineering,study,material,books,question,paper,papers,practical,files,download,pdf,buy,sell,college,btech,quality,last,year,supplementary,note,notes,indraprastha,university,NotesHub,Computer,science,information,technology,mechanical,civil,electrical,electronics,cs,it,mae,me,eee,ece,cse,download,search,find">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png">
    <meta name="theme-color" content="#ca2c2c">
    <link rel="manifest" href="/manifest.json">

    <title>NotesHub</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--<script src="preloader.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/css/preloader.css">-->
    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Dont actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Custom styles for this template -->
    <link href="dist/css/select2.css" rel="stylesheet">
    <link href="dist/css/select2-bootstrap.css" rel="stylesheet">
    <link href="dist/css/modify.css" rel="stylesheet">
    <link href="dist/css/buyBooks.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="dist/css/sellBooks.css">


    <link href="dist/css/carousel.css" rel="stylesheet">
    <link href="dist/css/index.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="dist/css/footer-basic-centered.css">

    <link href="tables/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="dist/css/datatables customization.css">

    <!--Google ads customization -->
    <link rel="stylesheet" type="text/css" href="dist/css/google ads customization.css">
    <!-- Google Analytics -->
	<script>
  	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  	})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  	ga('create', 'UA-86458385-1', 'auto');
  	ga('send', 'pageview');

	</script>

     <!--Google adsense -->
     <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
     <script>

     (adsbygoogle = window.adsbygoogle || []).push({
     google_ad_client: "ca-pub-6153632791841759",
     enable_page_level_ads: true
     });

      //install service worker
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
          navigator.serviceWorker.register('/sw.js').then(function(registration) {
            // Registration was successful
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
          }, function(err) {
            // registration failed :(
            console.log('ServiceWorker registration failed: ', err);
          });
        });
      }

     </script>

  </head>
<!-- NAVBAR
================================================== -->
  <body>
  <!--PRELOADER -->
    <!--<div id="preloader-container"">
    <div id="preloader-screen">
      <div class="preloader-content">
        <div class="row1">
          <span class="logo">  <img src="images/72.png"/>  </span>
          <span class="text"> NotesHub <span class=" highlighted-text">hai na...</span>  </span>
        </div>
        <div class="bar-container">
          <div class="bar">

          </div>
        </div>
        <div class="loading">Loading . . . <span id="load-percentage" class="highlighted-text">100</span>%</div>
      </div>
    </div>
    </div>-->

<!--APP LINK-->
	<a style="text-decoration:none; color: #fff;" href='https://goo.gl/RmUPsG' target='_blank'>
          <div style="background-color:#ca2c2c; text-align:center; color:#ffffff; width:100%;  position: fixed; z-index:100000; padding: 3px 0;">
            <span style="vertical-align:middle; white-space: nowrap;">Application now available on Google Play. Download now!</span>
          </div>
          </a>
    <!--NAVBAR-->
    <div class="navbar-wrapper">


      <div class="container">
           <nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" style="margin-top:25px;">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="search.php">NotesHub</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">


              <ul class="nav navbar-nav">
                <li><a href="search.php">Search</a></li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Download <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="notes.php">Notes</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="practicalFiles.php">Practical Files</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="questionPapers.php">Question Papers</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="eBooks.php">eBooks</a></li>

                  </ul>
                </li>

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Books <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="buyBooks.php">Buy Books</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="sellBooks.php">Sell Books</a></li>
                  </ul>
                </li>

                <li><a href="videos.php">Video Tutorials</a></li>
                <!--<li><a href="#contact">Contact Us</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="team.php">Team</a></li>-->

              </ul>

              <ul class="nav navbar-nav navbar-right">
                                  <li><a href="#" data-toggle="modal" data-target="#signUp">Sign Up</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#userLogin">User Login</a></li>
                                </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>

    <!-- Marketing messaging and featurettes
    ================================================== -->
    <!-- Wrap the rest of the page in another container to center all the content. -->


    <div class="jumbotron">
      <div class="container">
        <br>
        <br>
        <h1>Download Notes.</h1>
        <p>We are committed to bring you the best of the best notes of each and every subject. Go explore!</p>

      </div>
    </div>




    <!--select starts here-->
    <div class="container center-content">

    <form class="form-horizontal" action="notes.php" method="get">
                       <div class="row">
                       <div class="col-md-4 col-sm-4 col-xs-12 col-semester">
                          <div class="form-group">

                            <label for="id_label_single">
                            Select your Semester
                            </label>
                            <br>

                              <select required id="semester" class="form-control js-example-basic-single semester">
                              <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                              </select>
                          </div>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12 col-branch">
                          <div class="form-group">

                          <label for="id_label_single">
                            Select your Branch
                          </label>
                            <br>

                              <select required id="branch" class="form-control js-example-basic-single branch" >
                                    <option value=""></option>
                                    <option value="cse">CSE</option>
                                    <option value="it">IT</option>
                                    <option value="mae">MAE</option>
                                    <option value="civil">CIVIL</option>
                                    <option value="eee">EEE</option>
                                    <option value="ece">ECE</option>
                              </select>
                          </div>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12 col-subject">
                          <div class="form-group">

                            <label for="id_label_single">
                                  Select your Subject
                            </label>
                            <br>

                            <select required id="subjects" name="subjects" class="form-control js-example-basic-single subject" >
                              <option value=""></option>

                            </select>
                          </div>
                        </div>

                        </div>


                          <div class="row">

                          <div class="col-md-4 col-md-offset-4 col-recommend">
                          <div class="form-group">

                              <button type="submit" name="recommend" class="btn btn-primary btn-lg">Recommend Me</button>

                          </div>
                          </div>
                          </div>
                        </form>
      </div>
      <!--selection ends here-->

       <hr style="width: 50%;
                                 height: 10px;
                                 border: 0;
                                 box-shadow: 0 10px 10px -10px #8c8b8b inset;">


      <div class="container results-table center-content">

        <table class="table display responsive" cellspacing="0" width="100%" id="resultsTable">

          <thead>
            <th>S No.</th>
            <th>Topic</th>
            <th>Subject</th>
            <th>Branch</th>
            <th>Downloads</th>
            <th>Credits</th>
            <th>Filesize</th>
          </thead>

          <tbody>

                          <tr>
                <td>1</td>
                <td><a href="download.php?table=notes&id=891&file=publicuploads/2018/notes/New Doc 2017-04-24_12018-04-25 21:03:59.pdf">Viva Questions</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td></td>
                <td>10</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>479.5KB</td>

              </tr>
                            <tr>
                <td>2</td>
                <td><a href="download.php?table=notes&id=890&file=publicuploads/2018/notes/complex variable notes2018-04-25 21:19:38.pdf">Complex Variables</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>3</td>
                <td><a href="download.php?table=notes&id=889&file=publicuploads/2018/notes/ODE2018-04-25 21:03:15.pdf">Ordinary Differential Equations</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td></td>
                <td>3</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>12.3MB</td>

              </tr>
                            <tr>
                <td>4</td>
                <td><a href="download.php?table=notes&id=888&file=publicuploads/2018/notes/prob2018-04-25 21:01:26.pdf">Probability</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td></td>
                <td>3</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>2.6MB</td>

              </tr>
                            <tr>
                <td>5</td>
                <td><a href="download.php?table=notes&id=887&file=publicuploads/2018/notes/unit 3 BJT2018-04-25 20:58:18.pdf">Bipolar junction transistor</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>10</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>8MB</td>

              </tr>
                            <tr>
                <td>6</td>
                <td><a href="download.php?table=notes&id=886&file=publicuploads/2018/notes/UNIT 2  part-1 numericals2018-04-25 20:59:13.pdf">Special purpose diode numericals</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>3</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>7</td>
                <td><a href="download.php?table=notes&id=885&file=publicuploads/2018/notes/UNIT 2 part-22018-04-25 20:56:43.pdf">Special purpose diode</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>4</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>7MB</td>

              </tr>
                            <tr>
                <td>8</td>
                <td><a href="download.php?table=notes&id=884&file=publicuploads/2018/notes/UNIT 2 part-32018-04-25 20:57:27.pdf">Application of diodes</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>3</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>5.8MB</td>

              </tr>
                            <tr>
                <td>9</td>
                <td><a href="download.php?table=notes&id=883&file=publicuploads/2018/notes/UNIT 1 EVALUATION OF ELECTRONICS2018-04-25 20:52:06.pdf">2nd Semester End-Term</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>11</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>10</td>
                <td><a href="download.php?table=notes&id=882&file=publicuploads/2018/notes/UNIT 2 part-12018-04-25 20:55:22.pdf">Special purpose diode</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>7MB</td>

              </tr>
                            <tr>
                <td>11</td>
                <td><a href="download.php?table=notes&id=881&file=publicuploads/2018/notes/UNIT 1 EVALUATION OF ELECTRONICS2018-04-25 20:53:13.pdf">Unit 1 : Evalaution of Electronics</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>16</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>12</td>
                <td><a href="download.php?table=notes&id=880&file=publicuploads/2018/notes/232018-04-23 13:49:38.docx">Unit 3 and 4</a></td>
                <td>EEMI</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Aman Sawarn </td>
                <td>4.6MB</td>

              </tr>
                            <tr>
                <td>13</td>
                <td><a href="download.php?table=notes&id=879&file=publicuploads/2018/notes/DFS2018-04-24 19:42:36.pdf">Graph-DFT</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>413.1KB</td>

              </tr>
                            <tr>
                <td>14</td>
                <td><a href="download.php?table=notes&id=878&file=publicuploads/2018/notes/sa2018-04-24 19:43:39.pdf">Graph-BFT</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>178.4KB</td>

              </tr>
                            <tr>
                <td>15</td>
                <td><a href="download.php?table=notes&id=877&file=publicuploads/2018/notes/03 color_theorem2018-04-24 19:44:55.pdf">Color Theorem</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>16</td>
                <td><a href="download.php?table=notes&id=876&file=publicuploads/2018/notes/04 Minimum Spanning Trees and Prims Algorithm2018-04-24 19:49:23.pdf">Minimum Spanning Trees Prims Algo</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>243.9KB</td>

              </tr>
                            <tr>
                <td>17</td>
                <td><a href="download.php?table=notes&id=875&file=publicuploads/2018/notes/05 warshall-algorithm-for-transitive-closure2018-04-24 19:51:03.pdf">Warshall Algorithm</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>0</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>554KB</td>

              </tr>
                            <tr>
                <td>18</td>
                <td><a href="download.php?table=notes&id=874&file=publicuploads/2018/notes/06 Fermats little theorem _ Euler’s theorem2018-04-24 19:51:46.pdf">Fermats Little Theorem</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>167.3KB</td>

              </tr>
                            <tr>
                <td>19</td>
                <td><a href="download.php?table=notes&id=873&file=publicuploads/2018/notes/07 euler-phi function2018-04-24 19:53:01.pdf">Euler Phi Function</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>0</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>254.1KB</td>

              </tr>
                            <tr>
                <td>20</td>
                <td><a href="download.php?table=notes&id=872&file=publicuploads/2018/notes/08 A Computational Introduction to Number Theory and Algebra2018-04-24 19:55:36.pdf">Computational Intro To Number Theory</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>3.5MB</td>

              </tr>
                            <tr>
                <td>21</td>
                <td><a href="download.php?table=notes&id=871&file=publicuploads/2018/notes/09 quadratic-congruences2018-04-24 19:56:28.pdf">Quadratic Congruences</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>275.8KB</td>

              </tr>
                            <tr>
                <td>22</td>
                <td><a href="download.php?table=notes&id=870&file=publicuploads/2018/notes/1 Introduction2018-04-24 19:58:05.pdf">Introduction </a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>677.4KB</td>

              </tr>
                            <tr>
                <td>23</td>
                <td><a href="download.php?table=notes&id=869&file=publicuploads/2018/notes/2 Software Development Life Cycle Models2018-04-24 19:58:49.pdf">Software Life Cycle</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>559.9KB</td>

              </tr>
                            <tr>
                <td>24</td>
                <td><a href="download.php?table=notes&id=868&file=publicuploads/2018/notes/3 Software Requirements2018-04-24 19:59:32.pdf">Software Requirements</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>605.4KB</td>

              </tr>
                            <tr>
                <td>25</td>
                <td><a href="download.php?table=notes&id=867&file=publicuploads/2018/notes/4 Software Project Planning2018-04-24 20:00:16.pdf">Project Planning</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>26</td>
                <td><a href="download.php?table=notes&id=866&file=publicuploads/2018/notes/5 Software Design2018-04-24 20:01:03.pdf">Software Design</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>995.1KB</td>

              </tr>
                            <tr>
                <td>27</td>
                <td><a href="download.php?table=notes&id=865&file=publicuploads/2018/notes/6 Software Metrics2018-04-24 20:01:42.pdf">Software Metrics</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>840.5KB</td>

              </tr>
                            <tr>
                <td>28</td>
                <td><a href="download.php?table=notes&id=864&file=publicuploads/2018/notes/7 Software Reliability2018-04-24 20:02:21.pdf">Software Reliability</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>29</td>
                <td><a href="download.php?table=notes&id=863&file=publicuploads/2018/notes/8 Software Testing2018-04-24 20:02:59.pdf">Software Testing</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>30</td>
                <td><a href="download.php?table=notes&id=862&file=publicuploads/2018/notes/Overview Combined2018-04-24 20:21:18.pdf">Overview</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>3.1MB</td>

              </tr>
                            <tr>
                <td>31</td>
                <td><a href="download.php?table=notes&id=861&file=publicuploads/2018/notes/Combined 2018-04-24 20:22:29.pdf">Classes And Objects</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>1.9MB</td>

              </tr>
                            <tr>
                <td>32</td>
                <td><a href="download.php?table=notes&id=860&file=publicuploads/2018/notes/Combined2018-04-24 20:24:13.pdf">Inheritance-Packages-Exception Handling</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>3.6MB</td>

              </tr>
                            <tr>
                <td>33</td>
                <td><a href="download.php?table=notes&id=859&file=publicuploads/2018/notes/Combined2018-04-24 20:26:31.pdf">Multithreading Programming and I/O</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td></td>
                <td>2</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>3.7MB</td>

              </tr>
                            <tr>
                <td>34</td>
                <td><a href="download.php?table=notes&id=858&file=publicuploads/2018/notes/Applet, Event, Handling And Swings2018-04-24 20:27:49.pdf">Applet,Event,Handling and Swings</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td></td>
                <td>1</td>
                <!--<td></td>-->
                <td>Vineet Jha</td>
                <td>2.6MB</td>

              </tr>
                            <tr>
                <td>35</td>
                <td><a href="download.php?table=notes&id=857&file=publicuploads/2018/notes/mechanics+handwritten+notes2018-04-22 12:43:53.pdf">Unit -3 &amp; 4 (Handwritten Notes)</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td></td>
                <td>0</td>
                <!--<td></td>-->
                <td>Siddhant Jain (BMIET)</td>
                <td>23.3MB</td>

              </tr>
                            <tr>
                <td>36</td>
                <td><a href="download.php?table=notes&id=856&file=publicuploads/2018/notes/COA_CHEAT SHEET2018-04-10 23:24:23.pdf">COA cheat sheet 4th semester | CSE | IT | ECE</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td></td>
                <td>55</td>
                <!--<td></td>-->
                <td>NOTESHUB</td>
                <td>974.8KB</td>

              </tr>
                            <tr>
                <td>37</td>
                <td><a href="download.php?table=notes&id=855&file=publicuploads/2018/notes/1 EDC2018-04-18 10:50:52.pdf">unit 3 and unit 4</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td></td>
                <td>93</td>
                <!--<td></td>-->
                <td>hemant sharma</td>
                <td>26.6MB</td>

              </tr>
                            <tr>
                <td>38</td>
                <td><a href="download.php?table=notes&id=854&file=publicuploads/2018/notes/truss2018-04-18 10:53:24.pdf">trusses ak tayal</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td></td>
                <td>12</td>
                <!--<td></td>-->
                <td>hemant sharma</td>
                <td>7.1MB</td>

              </tr>
                            <tr>
                <td>39</td>
                <td><a href="download.php?table=notes&id=853&file=publicuploads/2018/notes/DBMS2018-03-01 14:03:36.pdf">5th semester DBMS Notes</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td></td>
                <td>110</td>
                <!--<td></td>-->
                <td>Vineet</td>
                <td>18MB</td>

              </tr>
                            <tr>
                <td>40</td>
                <td><a href="download.php?table=notes&id=852&file=publicuploads/2018/notes/EVS unit -I2018-03-01 10:09:50.pdf">Unit 1</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>139</td>
                <!--<td></td>-->
                <td>Archit Gupta</td>
                <td>6.3MB</td>

              </tr>
                            <tr>
                <td>41</td>
                <td><a href="download.php?table=notes&id=851&file=publicuploads/2018/notes/EVS Unit-II2018-03-01 10:10:52.pdf">Unit II</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>122</td>
                <!--<td></td>-->
                <td>Archit Gupta</td>
                <td>11.2MB</td>

              </tr>
                            <tr>
                <td>42</td>
                <td><a href="download.php?table=notes&id=850&file=publicuploads/2018/notes/Unit 1 Ecosystem & Biodiversity2018-03-01 10:15:21.pdf">Unit 1</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>0</td>
                <!--<td></td>-->
                <td>Archit Gupta</td>
                <td>10.6MB</td>

              </tr>
                            <tr>
                <td>43</td>
                <td><a href="download.php?table=notes&id=849&file=publicuploads/2018/notes/DBMS Class Notes2018-03-01 13:56:24.pdf">5th semester DBMS Class Notes</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td></td>
                <td>59</td>
                <!--<td></td>-->
                <td>Vineet</td>
                <td>8.6MB</td>

              </tr>
                            <tr>
                <td>44</td>
                <td><a href="download.php?table=notes&id=848&file=2018/notes/AE-II Notes OP-Amp2018-02-27 20:57:55.pdf"> OP Amp</a></td>
                <td>Analog Electronics II</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>112</td>
                <!--<td></td>-->
                <td>Aditya Jha</td>
                <td>6.1MB</td>

              </tr>
                            <tr>
                <td>45</td>
                <td><a href="download.php?table=notes&id=847&file=2018/notes/AE-II notes unit 12018-02-27 20:51:16.pdf">Unit 1</a></td>
                <td>Analog Electronics II</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>78</td>
                <!--<td></td>-->
                <td>Aditya Jha</td>
                <td>5.9MB</td>

              </tr>
                            <tr>
                <td>46</td>
                <td><a href="download.php?table=notes&id=846&file=2018/notes/AE UNIT-1,2 NOTES2018-02-27 20:45:38.pdf">Unit 1 and 2 Photocopied Notes </a></td>
                <td>Analog Electronics II</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>128</td>
                <!--<td></td>-->
                <td>Ashish</td>
                <td>20.4MB</td>

              </tr>
                            <tr>
                <td>47</td>
                <td><a href="download.php?table=notes&id=845&file=2018/notes/EM2018-02-27 20:37:40.pdf">1st Sessionals Photocopied Notes </a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>333</td>
                <!--<td></td>-->
                <td>Prem Gupta</td>
                <td>29.3MB</td>

              </tr>
                            <tr>
                <td>48</td>
                <td><a href="download.php?table=notes&id=844&file=2018/notes/COA 1st Sessionals2018-02-27 20:31:34.pdf">1st Sessionals Handwritten Notes </a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>281</td>
                <!--<td></td>-->
                <td>Bhanu</td>
                <td>4.2MB</td>

              </tr>
                            <tr>
                <td>49</td>
                <td><a href="download.php?table=notes&id=843&file=publicuploads/2018/notes/Unit 22018-02-27 15:06:05.pdf">Unit 2 Handwritten Notes</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>410</td>
                <!--<td></td>-->
                <td>Saurav</td>
                <td>14.3MB</td>

              </tr>
                            <tr>
                <td>50</td>
                <td><a href="download.php?table=notes&id=842&file=2018/notes/ITC imp notes2018-02-27 01:01:28.pdf">I and II Unit Photocopy Notes </a></td>
                <td>Information Theory and Coding</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>66</td>
                <!--<td></td>-->
                <td>Rubain Chauhan</td>
                <td>13.4MB</td>

              </tr>
                            <tr>
                <td>51</td>
                <td><a href="download.php?table=notes&id=841&file=publicuploads/2018/notes/COMM Class Notes2018-02-26 22:53:58.pdf">Communication system unit 1 and 2 </a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td></td>
                <td>93</td>
                <!--<td></td>-->
                <td>Vishal sharma</td>
                <td>10.3MB</td>

              </tr>
                            <tr>
                <td>52</td>
                <td><a href="download.php?table=notes&id=840&file=2018/notes/analog electronics II akash sample paper2018-02-26 20:41:12.pdf">Akash solved papers</a></td>
                <td>Analog Electronics II</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>118</td>
                <!--<td></td>-->
                <td>AKSHIT (NIEC)</td>
                <td>6.9MB</td>

              </tr>
                            <tr>
                <td>53</td>
                <td><a href="download.php?table=notes&id=839&file=2018/notes/WE unit 1 and 2 marked 2018-02-26 20:09:57.pdf">Unit 1 and Unit 2</a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>135</td>
                <!--<td></td>-->
                <td>Deepali(NIEC)</td>
                <td>43.7MB</td>

              </tr>
                            <tr>
                <td>54</td>
                <td><a href="download.php?table=notes&id=838&file=publicuploads/2018/notes/New Doc 2018-02-262018-02-26 17:10:21.pdf">Unit 1 and 2</a></td>
                <td>Introduction to Programming</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>965</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>15.9MB</td>

              </tr>
                            <tr>
                <td>55</td>
                <td><a href="download.php?table=notes&id=837&file=2018/notes/antenna unit-12018-02-25 19:36:06.pdf">Unit 1 Photocopy Notes </a></td>
                <td>Antenna and Wave Propagation</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>101</td>
                <!--<td></td>-->
                <td>Divik Sharma</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>56</td>
                <td><a href="download.php?table=notes&id=836&file=2018/notes/MPMC2018-02-25 19:31:40.pdf">Unit 1 2 Detailed Handwritten Notes </a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>242</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>32.7MB</td>

              </tr>
                            <tr>
                <td>57</td>
                <td><a href="download.php?table=notes&id=835&file=2018/notes/antenna unit-22018-02-25 19:15:42.pdf">Unit 2 Photocopy Notes </a></td>
                <td>Antenna and Wave Propagation</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>93</td>
                <!--<td></td>-->
                <td>Divik Sharma</td>
                <td>30MB</td>

              </tr>
                            <tr>
                <td>58</td>
                <td><a href="download.php?table=notes&id=834&file=2018/notes/New Doc 2018-02-252018-02-25 14:38:10.pdf">Sessional 1 Notes</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1138</td>
                <!--<td></td>-->
                <td>Dev</td>
                <td>9.8MB</td>

              </tr>
                            <tr>
                <td>59</td>
                <td><a href="download.php?table=notes&id=833&file=2018/notes/emft notes-12018-02-23 23:28:57.pdf">Unit 1 and Unit 2 Handwritten Notes</a></td>
                <td>Electromagnetic Field Theory</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>128</td>
                <!--<td></td>-->
                <td>Abhishek</td>
                <td>23.4MB</td>

              </tr>
                            <tr>
                <td>60</td>
                <td><a href="download.php?table=notes&id=832&file=2018/notes/UNIT 2 part-32018-02-23 23:09:01.pdf">Unit 2 Part 3 </a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>552</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>5.9MB</td>

              </tr>
                            <tr>
                <td>61</td>
                <td><a href="download.php?table=notes&id=831&file=2018/notes/UNIT 2 part-22018-02-23 23:06:18.pdf">Unit 2 Part 2 </a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>420</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>7.1MB</td>

              </tr>
                            <tr>
                <td>62</td>
                <td><a href="download.php?table=notes&id=830&file=2018/notes/UNIT 2  part-1 numericals2018-02-23 23:05:22.pdf">Unit 2 Part 1 Numericals </a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>194</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>63</td>
                <td><a href="download.php?table=notes&id=829&file=2018/notes/UNIT 2 part-12018-02-23 23:04:23.pdf">Unit 2 Part 1 </a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>438</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>6.7MB</td>

              </tr>
                            <tr>
                <td>64</td>
                <td><a href="download.php?table=notes&id=828&file=2018/notes/UNIT 1 EVALUATION OF ELECTRONICS2018-02-23 23:03:03.pdf">UNIT 1 EVALUATION OF ELECTRONICS</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>199</td>
                <!--<td></td>-->
                <td>Keshav</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>65</td>
                <td><a href="download.php?table=notes&id=827&file=2018/notes/Mobile Computing PDF2018-02-23 22:47:52.pdf">Unit 1 and Unit 2 handwritten Notes </a></td>
                <td>Mobile Computing</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>234</td>
                <!--<td></td>-->
                <td>Anil</td>
                <td>15.7MB</td>

              </tr>
                            <tr>
                <td>66</td>
                <td><a href="download.php?table=notes&id=826&file=2018/notes/OS 32018-02-23 19:29:14.pdf">MMU and Other Topics</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>76</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.2MB</td>

              </tr>
                            <tr>
                <td>67</td>
                <td><a href="download.php?table=notes&id=825&file=2018/notes/OS Threads2018-02-23 19:28:07.pdf">Threads and Process Synchronization </a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>76</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.8MB</td>

              </tr>
                            <tr>
                <td>68</td>
                <td><a href="download.php?table=notes&id=824&file=2018/notes/OS upto Threads2018-02-23 19:25:13.pdf">Detailed Notes</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>130</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.2MB</td>

              </tr>
                            <tr>
                <td>69</td>
                <td><a href="download.php?table=notes&id=823&file=2018/notes/NAS pdf2018-02-22 23:39:55.pdf">Handwritten Notes 1st Sessionals </a></td>
                <td>Network Analysis and Synthesis</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>137</td>
                <!--<td></td>-->
                <td>Manasvi</td>
                <td>18.9MB</td>

              </tr>
                            <tr>
                <td>70</td>
                <td><a href="download.php?table=notes&id=822&file=2018/notes/TOC Notes2018-02-22 23:10:22.pdf">Handwritten Notes 1st Sessional </a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>126</td>
                <!--<td></td>-->
                <td>Rishabh</td>
                <td>34.3MB</td>

              </tr>
                            <tr>
                <td>71</td>
                <td><a href="download.php?table=notes&id=821&file=2018/notes/TOC notes of 4sem2018-02-22 23:00:44.pdf">Class Notes 1st Sessionals </a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>95</td>
                <!--<td></td>-->
                <td>Udit</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>72</td>
                <td><a href="download.php?table=notes&id=820&file=2018/notes/PS-1 class notes2018-02-22 22:58:12.pdf">Class Notes 1st Sessionals </a></td>
                <td>Power System I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>77</td>
                <!--<td></td>-->
                <td>Deepak</td>
                <td>17MB</td>

              </tr>
                            <tr>
                <td>73</td>
                <td><a href="download.php?table=notes&id=819&file=2018/notes/microwave unit 22018-02-21 12:52:46.pdf">Unit 2 Handwritten </a></td>
                <td>Microwave Engineering</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>111</td>
                <!--<td></td>-->
                <td>Divik</td>
                <td>15.3MB</td>

              </tr>
                            <tr>
                <td>74</td>
                <td><a href="download.php?table=notes&id=818&file=2018/notes/microwave unit 12018-02-21 12:48:18.pdf">Unit 1 Handwritten </a></td>
                <td>Microwave Engineering</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>141</td>
                <!--<td></td>-->
                <td>Divik</td>
                <td>18.4MB</td>

              </tr>
                            <tr>
                <td>75</td>
                <td><a href="download.php?table=notes&id=817&file=2018/notes/nas2018-02-21 12:44:23.pdf">Handwritten Notes with Solved Numerical</a></td>
                <td>Network Analysis and Synthesis</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>304</td>
                <!--<td></td>-->
                <td>Nupur</td>
                <td>18.9MB</td>

              </tr>
                            <tr>
                <td>76</td>
                <td><a href="download.php?table=notes&id=813&file=2018/notes/Transportation Problem-Manan2018-02-17 11:39:56.pdf">Transportation Problem</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>129</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>1.6MB</td>

              </tr>
                            <tr>
                <td>77</td>
                <td><a href="download.php?table=notes&id=812&file=2018/notes/Linear Programming-Unit4-Manan2018-02-17 11:39:16.pdf">Linear Programming</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>180</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>78</td>
                <td><a href="download.php?table=notes&id=811&file=2018/notes/Theory Of Probability-Manan2018-02-17 11:38:28.pdf">Theory Of Probability</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>260</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>1.6MB</td>

              </tr>
                            <tr>
                <td>79</td>
                <td><a href="download.php?table=notes&id=810&file=2018/notes/Probability Distrubution-Manan2018-02-17 11:37:29.pdf">Probability Distribution</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>236</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>2.5MB</td>

              </tr>
                            <tr>
                <td>80</td>
                <td><a href="download.php?table=notes&id=809&file=2018/notes/Partial Differential Eq-Manan2018-02-17 11:36:12.pdf">Partial Differential Equations</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>329</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>81</td>
                <td><a href="download.php?table=notes&id=808&file=2018/notes/DSBSC-Manan2018-02-17 11:32:13.pdf">DSBSC</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT, EEE</td>
                <td>99</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>10.7MB</td>

              </tr>
                            <tr>
                <td>82</td>
                <td><a href="download.php?table=notes&id=807&file=2018/notes/DSBSC-Manan2018-02-17 11:29:59.pdf">DSBSC</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>299</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>10.7MB</td>

              </tr>
                            <tr>
                <td>83</td>
                <td><a href="download.php?table=notes&id=806&file=2018/notes/CSUnit2--Manan2018-02-17 11:27:44.pdf">Amplitude Modulation</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>452</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>84</td>
                <td><a href="download.php?table=notes&id=805&file=2018/notes/CSUnit2--Manan2018-02-17 11:25:57.pdf">Amplitude Modulation</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT, EEE</td>
                <td>92</td>
                <!--<td></td>-->
                <td>Manan</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>85</td>
                <td><a href="download.php?table=notes&id=804&file=2018/notes/IntroToProgramming2018-02-17 11:10:40.pdf">Handwritten Notes</a></td>
                <td>Introduction to Programming</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1522</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.1MB</td>

              </tr>
                            <tr>
                <td>86</td>
                <td><a href="download.php?table=notes&id=803&file=2018/notes/max minima - Abhilasha2018-02-17 11:09:24.pdf">Maxima And Minima</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>313</td>
                <!--<td></td>-->
                <td>Abhilasha</td>
                <td>5MB</td>

              </tr>
                            <tr>
                <td>87</td>
                <td><a href="download.php?table=notes&id=802&file=2018/notes/laplace of special functions - Abhilasha2018-02-17 11:06:41.pdf">Laplace of Special Functions</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>359</td>
                <!--<td></td>-->
                <td>Abhilasha</td>
                <td>11MB</td>

              </tr>
                            <tr>
                <td>88</td>
                <td><a href="download.php?table=notes&id=801&file=2018/notes/formation of pde - Abhilasha2018-02-17 11:02:57.pdf">Formation Of Partial Differential Equation </a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>355</td>
                <!--<td></td>-->
                <td>Abhilasha</td>
                <td>3.5MB</td>

              </tr>
                            <tr>
                <td>89</td>
                <td><a href="download.php?table=notes&id=800&file=2018/notes/EDC Unit 2 - Sahdev2018-02-17 11:00:11.pdf">Unit 2 Printed</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1509</td>
                <!--<td></td>-->
                <td>Sahdev</td>
                <td>44.2MB</td>

              </tr>
                            <tr>
                <td>90</td>
                <td><a href="download.php?table=notes&id=799&file=2018/notes/EDC unit 1 - Printed - Somya2018-02-17 10:56:23.pdf">Unit 1 Printed</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1318</td>
                <!--<td></td>-->
                <td>Somya</td>
                <td>14MB</td>

              </tr>
                            <tr>
                <td>91</td>
                <td><a href="download.php?table=notes&id=798&file=2018/notes/charpits standard form - Abhilasha2018-02-17 10:54:44.pdf">Charpits Standard Form</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>296</td>
                <!--<td></td>-->
                <td>Abhilasha</td>
                <td>3.2MB</td>

              </tr>
                            <tr>
                <td>92</td>
                <td><a href="download.php?table=notes&id=797&file=2017/notes/Applied Physics 2 - Unit 22018-02-06 18:33:02.pdf">Unit 2</a></td>
                <td>Applied Physics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1982</td>
                <!--<td></td>-->
                <td>Sarthak (NIEC)</td>
                <td>17.2MB</td>

              </tr>
                            <tr>
                <td>93</td>
                <td><a href="download.php?table=notes&id=796&file=2017/notes/Applied Physics 2 - Unit 12018-02-06 18:31:35.pdf">Unit 1</a></td>
                <td>Applied Physics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1868</td>
                <!--<td></td>-->
                <td>Sarthak (NIEC)</td>
                <td>13.8MB</td>

              </tr>
                            <tr>
                <td>94</td>
                <td><a href="download.php?table=notes&id=795&file=2017/notes/Dc motor anant2018-02-04 10:09:36.pdf">DC Motors</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>195</td>
                <!--<td></td>-->
                <td>Anant (BPIT)</td>
                <td>13.9MB</td>

              </tr>
                            <tr>
                <td>95</td>
                <td><a href="download.php?table=notes&id=794&file=2017/notes/COA-Unit1and2-Sem4-CSE_IT-BhanuThapliya2018-02-04 09:46:27.pdf">COA unit 1 2 </a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>757</td>
                <!--<td></td>-->
                <td>Bhanu Thapliya</td>
                <td>5.2MB</td>

              </tr>
                            <tr>
                <td>96</td>
                <td><a href="download.php?table=notes&id=793&file=2017/notes/Em-2ndSem-Unit1-Saurav-NIEC2018-02-02 20:52:40.pdf">Unit 1 Photocopy Notes </a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1764</td>
                <!--<td></td>-->
                <td>Saurav (NIEC)</td>
                <td>13MB</td>

              </tr>
                            <tr>
                <td>97</td>
                <td><a href="download.php?table=notes&id=792&file=2017/notes/Intro to programing-Sem2-Gagan2018-02-02 20:50:20.pdf">C The Complete Reference 4th Edition Ebook </a></td>
                <td>Introduction to Programming</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>494</td>
                <!--<td></td>-->
                <td>Gagan Bhardwaj</td>
                <td>6.9MB</td>

              </tr>
                            <tr>
                <td>98</td>
                <td><a href="download.php?table=notes&id=791&file=2017/notes/Programming with C (2nd ed2018-01-31 20:00:03.pdf">Programming With C Ebook </a></td>
                <td>Introduction to Programming</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>481</td>
                <!--<td></td>-->
                <td>Lakshy</td>
                <td>11.6MB</td>

              </tr>
                            <tr>
                <td>99</td>
                <td><a href="download.php?table=notes&id=790&file=2017/notes/physics unit 12018-01-30 10:01:45.pdf">gauss theorem gauss divergence theorem integral form of maxwell equations and Poynting theorem</a></td>
                <td>Applied Physics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>973</td>
                <!--<td></td>-->
                <td>Aparna (BMIET)</td>
                <td>3.8MB</td>

              </tr>
                            <tr>
                <td>100</td>
                <td><a href="download.php?table=notes&id=789&file=2017/notes/TAYLORS THEOREM AND ERROR2018-01-28 23:49:53.pdf">Taylors Theorem</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>428</td>
                <!--<td></td>-->
                <td>Saurav Jain (BMIET)</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>101</td>
                <td><a href="download.php?table=notes&id=788&file=2017/notes/Eulers theorem (Homogeneous function)2018-01-28 23:48:12.pdf">Eulers theorem Homogeneous function </a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>413</td>
                <!--<td></td>-->
                <td>Pratham (MAIT)</td>
                <td>2.7MB</td>

              </tr>
                            <tr>
                <td>102</td>
                <td><a href="download.php?table=notes&id=787&file=2017/notes/MAXIMA AND MINIMA2018-01-28 23:44:00.pdf">Maxima and Minima</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>311</td>
                <!--<td></td>-->
                <td>Saurav Jain (BMIET)</td>
                <td>2.1MB</td>

              </tr>
                            <tr>
                <td>103</td>
                <td><a href="download.php?table=notes&id=786&file=2017/notes/Jacobians2018-01-28 23:40:44.pdf">Jacobians</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>360</td>
                <!--<td></td>-->
                <td>Pratham (MAIT)</td>
                <td>2.8MB</td>

              </tr>
                            <tr>
                <td>104</td>
                <td><a href="download.php?table=notes&id=785&file=2017/notes/Total derivative2018-01-28 23:39:50.pdf">Total Derivatives Handwritten </a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>359</td>
                <!--<td></td>-->
                <td>Pratham (MAIT)</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>105</td>
                <td><a href="download.php?table=notes&id=784&file=2017/notes/Inverse Laplace transformation (Convolution theorem)2018-01-28 23:38:03.pdf">Inverse Laplace transformation Convolution theorem </a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>462</td>
                <!--<td></td>-->
                <td>Pratham (MAIT)</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>106</td>
                <td><a href="download.php?table=notes&id=780&file=2017/notes/EDC UNIT-12018-01-22 06:03:32.pdf">Unit 1 Handwritten Notes</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>2088</td>
                <!--<td></td>-->
                <td>Aparna (BMIET)</td>
                <td>10MB</td>

              </tr>
                            <tr>
                <td>107</td>
                <td><a href="download.php?table=notes&id=779&file=2017/notes/jacobian2018-01-22 06:01:36.pdf">Jacobian Handwritten Notes</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>295</td>
                <!--<td></td>-->
                <td>Saurav Jain (BMIET)</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>108</td>
                <td><a href="download.php?table=notes&id=778&file=2017/notes/phy unit 12018-01-22 06:00:57.pdf">Unit 1 Gradient curl divergence continuity equation and differential form of Maxwell equations</a></td>
                <td>Applied Physics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1236</td>
                <!--<td></td>-->
                <td>Aparna (BMIET)</td>
                <td>4.4MB</td>

              </tr>
                            <tr>
                <td>109</td>
                <td><a href="download.php?table=notes&id=777&file=2017/notes/Laplace transformation2018-01-22 06:00:02.pdf">Laplace Transformation</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>602</td>
                <!--<td></td>-->
                <td>Pratham (MAIT)</td>
                <td>6.1MB</td>

              </tr>
                            <tr>
                <td>110</td>
                <td><a href="download.php?table=notes&id=775&file=2017/notes/PARTIAL DERIVATIVE2018-01-21 13:26:16.pdf">Partial Derivatives and Eulers Theorem</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>538</td>
                <!--<td></td>-->
                <td>Saurav Jain (BMIET)</td>
                <td>6.8MB</td>

              </tr>
                            <tr>
                <td>111</td>
                <td><a href="download.php?table=notes&id=774&file=2017/notes/MATHS TOTAL DERIVATIVE2018-01-16 23:29:57.pdf">Total Derivatives</a></td>
                <td>Applied Mathematics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>427</td>
                <!--<td></td>-->
                <td>Saurav Jain (BMIET)</td>
                <td>2.5MB</td>

              </tr>
                            <tr>
                <td>112</td>
                <td><a href="download.php?table=notes&id=773&file=2017/notes/IM UNIT 4 COMPLETE5857af3a8b53612017-12-17 15:12:45.pdf">Part4</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>IT, EEE, ECE</td>
                <td>120</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11MB</td>

              </tr>
                            <tr>
                <td>113</td>
                <td><a href="download.php?table=notes&id=772&file=2017/notes/IM 7-105813a8da7208282017-12-17 15:10:32.pdf">Part3</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>150</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>50.7MB</td>

              </tr>
                            <tr>
                <td>114</td>
                <td><a href="download.php?table=notes&id=771&file=2017/notes/IM 4,5,65813a4b93c22f42017-12-17 15:03:16.pdf">Part 2</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>123</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>43.7MB</td>

              </tr>
                            <tr>
                <td>115</td>
                <td><a href="download.php?table=notes&id=770&file=2017/notes/IM 1,2,358139a866b47222017-12-17 15:00:00.pdf">Part 1</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>161</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>41.6MB</td>

              </tr>
                            <tr>
                <td>116</td>
                <td><a href="download.php?table=notes&id=769&file=2017/notes/Unit 2 Phaserule (Handwritten)2017-12-16 12:18:17.pdf">Unit 2 Handwritten </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>530</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.1MB</td>

              </tr>
                            <tr>
                <td>117</td>
                <td><a href="download.php?table=notes&id=768&file=2017/notes/Unit 1 Fules (Handwritten)2017-12-16 12:12:18.pdf">Unit 1 Fuels Handwritten </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>757</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>15.7MB</td>

              </tr>
                            <tr>
                <td>118</td>
                <td><a href="download.php?table=notes&id=767&file=2017/notes/EM unit 32017-12-15 22:28:22.pdf">Unit 3</a></td>
                <td>Electrical Machines</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>53</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.1MB</td>

              </tr>
                            <tr>
                <td>119</td>
                <td><a href="download.php?table=notes&id=765&file=2017/notes/Unit 22017-12-15 22:26:06.pdf">Unit 2</a></td>
                <td>Electrical Machines</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>58</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>120</td>
                <td><a href="download.php?table=notes&id=764&file=2017/notes/Unit 12017-12-15 22:25:59.pdf">Unit 1</a></td>
                <td>Electrical Machines</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>62</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.2MB</td>

              </tr>
                            <tr>
                <td>121</td>
                <td><a href="download.php?table=notes&id=763&file=2017/notes/Applied Chem Unit 42017-12-15 21:06:06.pdf">Unit 4 Corrosion Notes </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1022</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.7MB</td>

              </tr>
                            <tr>
                <td>122</td>
                <td><a href="download.php?table=notes&id=762&file=2017/notes/Machine notes2017-12-15 14:31:27.pdf">Handwritten Notes</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>78</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26.8MB</td>

              </tr>
                            <tr>
                <td>123</td>
                <td><a href="download.php?table=notes&id=761&file=2017/notes/Synchronous Machine2017-12-15 14:31:22.pdf">Synchronous Machine</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>46</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.5MB</td>

              </tr>
                            <tr>
                <td>124</td>
                <td><a href="download.php?table=notes&id=760&file=2017/notes/3 Phase Induction Motor2017-12-15 14:28:44.pdf">Induction Motor</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>47</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.4MB</td>

              </tr>
                            <tr>
                <td>125</td>
                <td><a href="download.php?table=notes&id=759&file=2017/notes/Machine unit 32017-12-15 14:27:37.pdf">Unit 3 Photocopied Notes </a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>54</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.6MB</td>

              </tr>
                            <tr>
                <td>126</td>
                <td><a href="download.php?table=notes&id=758&file=2017/notes/EM Unit 42017-12-15 14:24:55.pdf">Unit 4 Photocopied Notes </a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>53</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.5MB</td>

              </tr>
                            <tr>
                <td>127</td>
                <td><a href="download.php?table=notes&id=757&file=2017/notes/Elements of machines2017-12-15 14:22:05.pdf">Elements of Machine</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>36</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.3MB</td>

              </tr>
                            <tr>
                <td>128</td>
                <td><a href="download.php?table=notes&id=756&file=2017/notes/Dc motor2017-12-15 14:20:13.pdf">DC Motor</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>51</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.6MB</td>

              </tr>
                            <tr>
                <td>129</td>
                <td><a href="download.php?table=notes&id=755&file=2017/notes/Dc generator2017-12-15 14:14:26.pdf">DC Generator</a></td>
                <td>Electrical Machines I</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>60</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.2MB</td>

              </tr>
                            <tr>
                <td>130</td>
                <td><a href="download.php?table=notes&id=754&file=2017/notes/data-warehousing-fundamentals-by-paulraj-ponniah2017-12-15 01:32:04.pdf">Complete Notes Data Warehousing Fundamentals by Paulraj Ponniah </a></td>
                <td>Data Mining and Business Intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>50</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4MB</td>

              </tr>
                            <tr>
                <td>131</td>
                <td><a href="download.php?table=notes&id=753&file=2017/notes/ADBMS NOTES FULL2017-12-15 01:25:37.pdf">Complete Notes</a></td>
                <td>Advanced Database Management System</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>118</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.9MB</td>

              </tr>
                            <tr>
                <td>132</td>
                <td><a href="download.php?table=notes&id=752&file=2017/notes/radar unit 42017-12-15 01:09:15.pdf">Unit 4 Book Notes </a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>55</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.2MB</td>

              </tr>
                            <tr>
                <td>133</td>
                <td><a href="download.php?table=notes&id=751&file=2017/notes/radar unit 32017-12-15 01:08:20.pdf">Unit 3 Book Notes </a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>51</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.7MB</td>

              </tr>
                            <tr>
                <td>134</td>
                <td><a href="download.php?table=notes&id=750&file=2017/notes/Radar Unit 22017-12-15 01:07:29.pdf">Unit 2 Book Notes </a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>55</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.4MB</td>

              </tr>
                            <tr>
                <td>135</td>
                <td><a href="download.php?table=notes&id=749&file=2017/notes/FOCS 2nd Sessional2017-12-12 21:42:52.pdf">2nd Sessional Notes</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>66</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7MB</td>

              </tr>
                            <tr>
                <td>136</td>
                <td><a href="download.php?table=notes&id=748&file=2017/notes/Maths Class Notes2017-12-12 21:38:35.pdf">Complete Notes Handwritten </a></td>
                <td>Applied Mathematics III</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>78</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29MB</td>

              </tr>
                            <tr>
                <td>137</td>
                <td><a href="download.php?table=notes&id=747&file=2017/notes/FOCS Class Notes2017-12-12 21:33:28.pdf">Class Notes Complete </a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>58</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.9MB</td>

              </tr>
                            <tr>
                <td>138</td>
                <td><a href="download.php?table=notes&id=746&file=2017/notes/DS Class Notes-22017-12-12 21:24:37.pdf">Complete Handwritten Notes Part II</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>325</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4MB</td>

              </tr>
                            <tr>
                <td>139</td>
                <td><a href="download.php?table=notes&id=745&file=2017/notes/DS Class Notes2017-12-12 21:22:45.pdf">Complete Handwritten Notes Part I</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>315</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4MB</td>

              </tr>
                            <tr>
                <td>140</td>
                <td><a href="download.php?table=notes&id=744&file=2017/notes/CS Class Notes2017-12-12 21:19:39.pdf">Complete Notes Handwritten </a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE</td>
                <td>59</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>22.8MB</td>

              </tr>
                            <tr>
                <td>141</td>
                <td><a href="download.php?table=notes&id=743&file=2017/notes/computer graphics2017-12-12 21:16:13.pdf">Photocopied Notes Shading Model Onward </a></td>
                <td>Computer Graphics and Multimedia</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>177</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>25.7MB</td>

              </tr>
                            <tr>
                <td>142</td>
                <td><a href="download.php?table=notes&id=742&file=2017/notes/Circuit and Systems 3rd sem unit 32017-12-12 21:09:44.pdf">Unit 3 Detailed Notes Handwritten </a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.1MB</td>

              </tr>
                            <tr>
                <td>143</td>
                <td><a href="download.php?table=notes&id=741&file=2017/notes/CGM Class Notes2017-12-12 21:06:25.pdf">Handwritten Class Notes</a></td>
                <td>Computer Graphics and Multimedia</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>230</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.6MB</td>

              </tr>
                            <tr>
                <td>144</td>
                <td><a href="download.php?table=notes&id=740&file=2017/notes/AE UNIT 42017-12-12 21:03:37.pdf">Unit 4 Book </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>47</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.1MB</td>

              </tr>
                            <tr>
                <td>145</td>
                <td><a href="download.php?table=notes&id=739&file=2017/notes/EIM Unit 22017-12-12 19:22:03.pdf">Unit 2 Handwritten Notes </a></td>
                <td>Electronic Instruments and Measurements</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>61</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12MB</td>

              </tr>
                            <tr>
                <td>146</td>
                <td><a href="download.php?table=notes&id=738&file=2017/notes/EIM Unit 12017-12-12 19:20:31.pdf">Unit 1 Handwritten Notes </a></td>
                <td>Electronic Instruments and Measurements</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>59</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.6MB</td>

              </tr>
                            <tr>
                <td>147</td>
                <td><a href="download.php?table=notes&id=737&file=2017/notes/DS sem 32017-12-12 03:28:12.pdf">Photocopied Notes</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>176</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.3MB</td>

              </tr>
                            <tr>
                <td>148</td>
                <td><a href="download.php?table=notes&id=736&file=2017/notes/DS_unit_2_notes2017-12-12 03:27:41.pdf">Unit 2 Photocopied Notes </a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>137</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.5MB</td>

              </tr>
                            <tr>
                <td>149</td>
                <td><a href="download.php?table=notes&id=735&file=2017/notes/Crypto unit 3 Notes2017-12-12 03:22:10.pdf">Unit 3</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>43</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.3MB</td>

              </tr>
                            <tr>
                <td>150</td>
                <td><a href="download.php?table=notes&id=734&file=2017/notes/Crypto unit 1- 22017-12-12 03:21:21.pdf">Unit 1 and 2</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>63</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.5MB</td>

              </tr>
                            <tr>
                <td>151</td>
                <td><a href="download.php?table=notes&id=733&file=2017/notes/crypto unit 42017-12-12 03:21:02.pdf">Unit 4</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>38</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.5MB</td>

              </tr>
                            <tr>
                <td>152</td>
                <td><a href="download.php?table=notes&id=732&file=2017/notes/Single Phase Transformers AH2017-12-12 03:16:45.pdf">Single Phase Transformers</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>74</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>33.4MB</td>

              </tr>
                            <tr>
                <td>153</td>
                <td><a href="download.php?table=notes&id=731&file=2017/notes/Single Phase Series A2017-12-12 03:14:56.pdf">Single Phase Series A C Circuits</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>52</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.1MB</td>

              </tr>
                            <tr>
                <td>154</td>
                <td><a href="download.php?table=notes&id=730&file=2017/notes/Self and Mutual Inductances AH2017-12-12 03:13:38.pdf">Self and Mutual Inductances</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>45</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.3MB</td>

              </tr>
                            <tr>
                <td>155</td>
                <td><a href="download.php?table=notes&id=729&file=2017/notes/Resonance AH2017-12-12 03:13:21.pdf">Resonance</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>35</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.3MB</td>

              </tr>
                            <tr>
                <td>156</td>
                <td><a href="download.php?table=notes&id=728&file=2017/notes/Magnetic Circuits AH2017-12-12 03:12:21.pdf">Magnetic Circuits AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>39</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>157</td>
                <td><a href="download.php?table=notes&id=727&file=2017/notes/Electromagnetism AH2017-12-12 03:12:04.pdf">Electromagnetism AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>36</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7MB</td>

              </tr>
                            <tr>
                <td>158</td>
                <td><a href="download.php?table=notes&id=726&file=2017/notes/Electrical Measurements AH2017-12-12 03:10:41.pdf">Electrical Measurements AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>39</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>19.2MB</td>

              </tr>
                            <tr>
                <td>159</td>
                <td><a href="download.php?table=notes&id=725&file=2017/notes/Direct Current Motors AH2017-12-12 03:09:42.pdf">Direct Current Motors AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>39</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.7MB</td>

              </tr>
                            <tr>
                <td>160</td>
                <td><a href="download.php?table=notes&id=724&file=2017/notes/Direct Current Generator AH2017-12-12 03:08:45.pdf">Direct Current Generator AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>40</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.2MB</td>

              </tr>
                            <tr>
                <td>161</td>
                <td><a href="download.php?table=notes&id=723&file=2017/notes/ST Unit 12017-12-12 03:07:18.pdf">Unit 1 Book Notes </a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>131</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.8MB</td>

              </tr>
                            <tr>
                <td>162</td>
                <td><a href="download.php?table=notes&id=722&file=2017/notes/BMC2017-12-12 03:05:14.pdf"> Printed Notes </a></td>
                <td>Building Materials and Construction</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>50</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.5MB</td>

              </tr>
                            <tr>
                <td>163</td>
                <td><a href="download.php?table=notes&id=721&file=2017/notes/Alternating Voltage and Current AH2017-12-12 02:55:43.pdf">Alternating Voltage and Current AH</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>46</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.4MB</td>

              </tr>
                            <tr>
                <td>164</td>
                <td><a href="download.php?table=notes&id=720&file=2017/notes/pmdc motor2017-12-12 02:45:55.pdf">PMDC Motor</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>37</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>165</td>
                <td><a href="download.php?table=notes&id=719&file=2017/notes/MP(powder metallurgy)2017-12-12 02:43:31.pdf">Powder Metallurgy Handwritten Notes </a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.6MB</td>

              </tr>
                            <tr>
                <td>166</td>
                <td><a href="download.php?table=notes&id=718&file=2017/notes/ada 3-4 unit2017-12-12 02:38:42.pdf">Unit 3 and 4 Class Notes </a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>113</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.6MB</td>

              </tr>
                            <tr>
                <td>167</td>
                <td><a href="download.php?table=notes&id=717&file=2017/notes/unit 42017-12-12 02:35:18.pdf">Unit 4 Photocopied Notes </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>39</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.1MB</td>

              </tr>
                            <tr>
                <td>168</td>
                <td><a href="download.php?table=notes&id=716&file=2017/notes/stepper motor2017-12-12 02:34:02.pdf">Stepper Motor</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>40</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.8MB</td>

              </tr>
                            <tr>
                <td>169</td>
                <td><a href="download.php?table=notes&id=715&file=2017/notes/Managing Undo Data2017-12-11 18:59:09.pdf">Managing Undo Data</a></td>
                <td>Advanced Database Administration</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>140</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>373.3KB</td>

              </tr>
                            <tr>
                <td>170</td>
                <td><a href="download.php?table=notes&id=714&file=2017/notes/ADBA 3,42017-12-11 18:57:31.pdf">Unit 3 and 4</a></td>
                <td>Advanced Database Administration</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>209</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>171</td>
                <td><a href="download.php?table=notes&id=713&file=2017/notes/ADBA 1,22017-12-11 18:57:03.pdf">Unit 1 and 2</a></td>
                <td>Advanced Database Administration</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>219</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>855.5KB</td>

              </tr>
                            <tr>
                <td>172</td>
                <td><a href="download.php?table=notes&id=712&file=2017/notes/Cns 1st term2017-12-11 15:52:44.pdf">Unit 1 Handwritten Notes</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>46</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>56.9MB</td>

              </tr>
                            <tr>
                <td>173</td>
                <td><a href="download.php?table=notes&id=711&file=2017/notes/WC2017-12-11 15:39:33.pdf">Unit 2 Handwritten Notes </a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>85</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.1MB</td>

              </tr>
                            <tr>
                <td>174</td>
                <td><a href="download.php?table=notes&id=710&file=2017/notes/FCS Complete Handwritten Notes2017-12-11 15:33:27.pdf">Complete Handwritten Notes</a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>61</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.6MB</td>

              </tr>
                            <tr>
                <td>175</td>
                <td><a href="download.php?table=notes&id=709&file=2017/notes/Unit 3 and 4 Communication Systems2017-12-11 12:36:05.pdf">Unit 3 and 4 Handwritten Notes </a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT, EEE</td>
                <td>512</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.1MB</td>

              </tr>
                            <tr>
                <td>176</td>
                <td><a href="download.php?table=notes&id=708&file=2017/notes/Unit 42017-12-10 19:37:25.pdf">Unit 4 Printed Notes </a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>79</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.6MB</td>

              </tr>
                            <tr>
                <td>177</td>
                <td><a href="download.php?table=notes&id=707&file=2017/notes/DC UNIT 32017-12-10 19:35:31.pdf">Unit 3 Photocopied Notes</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>48</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.7MB</td>

              </tr>
                            <tr>
                <td>178</td>
                <td><a href="download.php?table=notes&id=706&file=2017/notes/SOM Notes2017-12-10 19:33:43.pdf">Unit 1 3 Handwritten </a></td>
                <td>Strength of Material</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>54</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>302.5KB</td>

              </tr>
                            <tr>
                <td>179</td>
                <td><a href="download.php?table=notes&id=705&file=2017/notes/Stld notes unit 3 and 42017-12-10 19:31:19.pdf">Unit 3 and 4 Photocopied Notes </a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>75</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.5MB</td>

              </tr>
                            <tr>
                <td>180</td>
                <td><a href="download.php?table=notes&id=704&file=2017/notes/Jacobians2017-12-10 19:19:27.pdf">Jacobian Photocopied Notes </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>83</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20MB</td>

              </tr>
                            <tr>
                <td>181</td>
                <td><a href="download.php?table=notes&id=703&file=2017/notes/Vectors2017-12-10 19:16:31.pdf">Vectors Photocopied Notes </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>66</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.7MB</td>

              </tr>
                            <tr>
                <td>182</td>
                <td><a href="download.php?table=notes&id=702&file=2017/notes/DC UNIT 32017-12-10 19:15:32.pdf">Unit 3</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>45</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.7MB</td>

              </tr>
                            <tr>
                <td>183</td>
                <td><a href="download.php?table=notes&id=701&file=2017/notes/Maths notes2017-12-10 19:14:42.pdf">Handwritten Notes Multiple Topics </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>62</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.2MB</td>

              </tr>
                            <tr>
                <td>184</td>
                <td><a href="download.php?table=notes&id=700&file=2017/notes/PRODUCTION TECHNOLOGY (Unit 1-4)2017-12-10 19:01:34.pdf">Unit 1 4 Short Notes </a></td>
                <td>Production Technology</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>55</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.1MB</td>

              </tr>
                            <tr>
                <td>185</td>
                <td><a href="download.php?table=notes&id=699&file=2017/notes/EMI Unit 32017-12-10 18:59:03.pdf">Unit 3</a></td>
                <td>Electronic Instruments and Measurements</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>92</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.5MB</td>

              </tr>
                            <tr>
                <td>186</td>
                <td><a href="download.php?table=notes&id=698&file=2017/notes/mp-handwritten2017-12-10 18:55:33.pdf">Handwritten Class Notes </a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>52</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>19.3MB</td>

              </tr>
                            <tr>
                <td>187</td>
                <td><a href="download.php?table=notes&id=697&file=2017/notes/STLD unit 42017-12-10 18:51:59.pdf">Unit 4 Book Notes </a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>61</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.7MB</td>

              </tr>
                            <tr>
                <td>188</td>
                <td><a href="download.php?table=notes&id=696&file=2017/notes/EMI Photocopy  Notes2017-12-10 18:47:20.pdf">Photocopied Notes</a></td>
                <td>Electronic Instruments and Measurements</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>121</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.7MB</td>

              </tr>
                            <tr>
                <td>189</td>
                <td><a href="download.php?table=notes&id=695&file=2017/notes/Measuring Instruments2017-12-10 18:16:30.pdf">Measuring Instruments Revision Notes </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>259</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>190</td>
                <td><a href="download.php?table=notes&id=694&file=2017/notes/AC circuit 3-phase2017-12-10 18:15:38.pdf">AC Circuit 3 Phase Revision Notes </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>174</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>852.8KB</td>

              </tr>
                            <tr>
                <td>191</td>
                <td><a href="download.php?table=notes&id=693&file=2017/notes/AC Circuits Unit-II2017-12-10 18:14:34.pdf">Unit II AC Circuits Revision Notes</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>189</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.9MB</td>

              </tr>
                            <tr>
                <td>192</td>
                <td><a href="download.php?table=notes&id=692&file=2017/notes/GPRS and GSM Architecture2017-12-08 21:45:59.pdf">GSM and GPRS architecture</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>118</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.8MB</td>

              </tr>
                            <tr>
                <td>193</td>
                <td><a href="download.php?table=notes&id=691&file=2017/notes/MP Handwritten Full2017-12-07 23:58:54.pdf">Complete Handwritten Notes</a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>234</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.4MB</td>

              </tr>
                            <tr>
                <td>194</td>
                <td><a href="download.php?table=notes&id=690&file=2017/notes/Mes unit 4 - NotesHub2017-12-07 22:44:15.pdf">Unit 4 Photocopied Notes </a></td>
                <td>Materials in Electrical Systems</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>67</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>19.4MB</td>

              </tr>
                            <tr>
                <td>195</td>
                <td><a href="download.php?table=notes&id=689&file=2017/notes/MES notes 3 - NotesHub2017-12-07 22:42:51.pdf">Unit 3 Photocopied Notes </a></td>
                <td>Materials in Electrical Systems</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>62</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.2MB</td>

              </tr>
                            <tr>
                <td>196</td>
                <td><a href="download.php?table=notes&id=688&file=2017/notes/MES notes 2 - NotesHub2017-12-07 22:42:12.pdf">Unit 2 Photocopied Notes </a></td>
                <td>Materials in Electrical Systems</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>59</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5MB</td>

              </tr>
                            <tr>
                <td>197</td>
                <td><a href="download.php?table=notes&id=687&file=2017/notes/MES notes 1 - NotesHub2017-12-07 22:40:49.pdf">Unit 1 Photocopied Notes </a></td>
                <td>Materials in Electrical Systems</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>74</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.5MB</td>

              </tr>
                            <tr>
                <td>198</td>
                <td><a href="download.php?table=notes&id=686&file=2017/notes/Communication Skills2017-12-05 21:21:08.pdf">Unit 1 and Unit 2 Complete Handwritten </a></td>
                <td>Communication Skills for Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>65</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.7MB</td>

              </tr>
                            <tr>
                <td>199</td>
                <td><a href="download.php?table=notes&id=685&file=2017/notes/microprocessor full hand made notes_14788007250422017-12-05 21:10:36.pdf">Handwritten Notes from LectureNotes </a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>559</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>200</td>
                <td><a href="download.php?table=notes&id=684&file=2017/notes/Approximates@Applied Mathematics@notes2017-12-03 14:29:50.pdf">Beta Gamma</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>146</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6MB</td>

              </tr>
                            <tr>
                <td>201</td>
                <td><a href="download.php?table=notes&id=683&file=2017/notes/unit-1-2 NotesHub2017-12-03 13:56:45.pdf">Unit 1 and 2 Faculty Notes </a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>294</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9MB</td>

              </tr>
                            <tr>
                <td>202</td>
                <td><a href="download.php?table=notes&id=682&file=2017/notes/TTL and CMOS2017-12-03 13:55:26.pdf">TTL and CMOS</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>227</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.5MB</td>

              </tr>
                            <tr>
                <td>203</td>
                <td><a href="download.php?table=notes&id=681&file=2017/notes/STLD Class Notes Noteshub2017-12-03 13:54:00.pdf">Class Notes</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>214</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.3MB</td>

              </tr>
                            <tr>
                <td>204</td>
                <td><a href="download.php?table=notes&id=680&file=2017/notes/IT - 3RD SEM -MATHS - UNIT 12017-12-03 13:51:27.pdf">Unit 1 Handwritten Notes </a></td>
                <td>Applied Mathematics III</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>151</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.9MB</td>

              </tr>
                            <tr>
                <td>205</td>
                <td><a href="download.php?table=notes&id=679&file=2017/notes/CATALYSIS APPLIED CHEMISTRY SEM I2017-12-03 13:39:05.pdf">Catalysis from Techbits </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>720</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.9MB</td>

              </tr>
                            <tr>
                <td>206</td>
                <td><a href="download.php?table=notes&id=678&file=2017/notes/PHASE RULE APPLIED CHEMISTRY SEM 12017-12-03 13:37:49.pdf">Phase Rule from Techbits </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>554</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.3MB</td>

              </tr>
                            <tr>
                <td>207</td>
                <td><a href="download.php?table=notes&id=677&file=2017/notes/Welding Manufacturing Process Semester 1 ECE2017-12-03 13:35:41.pdf">Welding</a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>801</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>520.5KB</td>

              </tr>
                            <tr>
                <td>208</td>
                <td><a href="download.php?table=notes&id=676&file=2017/notes/Cupola Furnace Manufacturing Process Semester 1 ECE2017-12-03 13:35:19.pdf">Cupola Furnace</a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>556</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>513.5KB</td>

              </tr>
                            <tr>
                <td>209</td>
                <td><a href="download.php?table=notes&id=673&file=2017/notes/DBMS Notes2017-12-02 20:19:56.pdf">DBMS Handwritten Notes</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>629</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.8MB</td>

              </tr>
                            <tr>
                <td>210</td>
                <td><a href="download.php?table=notes&id=672&file=2017/notes/Differential Equations Questions2017-12-02 20:17:37.pdf">Differential Equations Solved Questions Detailed </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>196</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>211</td>
                <td><a href="download.php?table=notes&id=671&file=2017/notes/DC Motors ET 1st Sem2017-12-02 19:48:03.pdf">DC Motors Book </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>406</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.8MB</td>

              </tr>
                            <tr>
                <td>212</td>
                <td><a href="download.php?table=notes&id=670&file=2017/notes/Differential Equations2017-12-02 19:33:26.pdf">Differential Equations</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>179</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.9MB</td>

              </tr>
                            <tr>
                <td>213</td>
                <td><a href="download.php?table=notes&id=669&file=2017/notes/Linux Commands, Flowcharts and Networking2017-12-02 18:08:15.pdf">Linux Commands Flowcharts and Networking</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>912</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>885KB</td>

              </tr>
                            <tr>
                <td>214</td>
                <td><a href="download.php?table=notes&id=668&file=2017/notes/AE-1 (Unit 4) - Noteshub2017-12-02 15:38:33.pdf">Unit 4 Photocopied Notes </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>236</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.7MB</td>

              </tr>
                            <tr>
                <td>215</td>
                <td><a href="download.php?table=notes&id=667&file=2017/notes/AE-1 (Unit 3) - Noteshub2017-12-02 15:36:47.pdf">Unit 3 Photocopied Notes </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>158</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.3MB</td>

              </tr>
                            <tr>
                <td>216</td>
                <td><a href="download.php?table=notes&id=666&file=2017/notes/AE-1 (Unit 2) - Noteshub2017-12-02 15:35:56.pdf">Unit 2 Photocopied Notes </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>189</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>217</td>
                <td><a href="download.php?table=notes&id=665&file=2017/notes/AE-1 (Unit 1) - Noteshub2017-12-02 15:35:18.pdf">Unit 1 Photocopied Notes </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>214</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.5MB</td>

              </tr>
                            <tr>
                <td>218</td>
                <td><a href="download.php?table=notes&id=664&file=2017/notes/FOCS unit 42017-12-01 18:33:53.pdf">Unit 4 Photocopied Notes </a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>145</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>219</td>
                <td><a href="download.php?table=notes&id=663&file=2017/notes/FOCS unit 32017-12-01 18:33:20.pdf">Unit 3 Photocopied Notes </a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>130</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>220</td>
                <td><a href="download.php?table=notes&id=662&file=2017/notes/FOCS unit 22017-12-01 18:32:04.pdf">Unit 2 Photocopied Notes </a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>114</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.9MB</td>

              </tr>
                            <tr>
                <td>221</td>
                <td><a href="download.php?table=notes&id=661&file=2017/notes/FOCS unit 12017-12-01 18:31:18.pdf">Unit 1 Photocopied Notes </a></td>
                <td>Foundation of Computer Science</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>120</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.3MB</td>

              </tr>
                            <tr>
                <td>222</td>
                <td><a href="download.php?table=notes&id=660&file=2017/notes/physics viva questions2017-12-01 18:28:42.pdf">Viva Questions</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>75</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.6MB</td>

              </tr>
                            <tr>
                <td>223</td>
                <td><a href="download.php?table=notes&id=659&file=2017/notes/dc motor2017-12-01 18:26:42.pdf">DC Motor</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>803</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.9MB</td>

              </tr>
                            <tr>
                <td>224</td>
                <td><a href="download.php?table=notes&id=658&file=2017/notes/asymptode2017-12-01 18:25:14.pdf">Asymptopes</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>184</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.3MB</td>

              </tr>
                            <tr>
                <td>225</td>
                <td><a href="download.php?table=notes&id=657&file=2017/notes/Curve tracing2017-12-01 18:24:20.pdf">Curve Tracing</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>231</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.6MB</td>

              </tr>
                            <tr>
                <td>226</td>
                <td><a href="download.php?table=notes&id=656&file=2017/notes/Unit 2 Realtion between params2017-12-01 18:22:13.pdf">Relation between all parameters 2nd unit </a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>218</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>227</td>
                <td><a href="download.php?table=notes&id=655&file=2017/notes/laplas NotesHub2017-12-01 18:08:50.pdf">Laplace Transform Unit 2 </a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>220</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.6MB</td>

              </tr>
                            <tr>
                <td>228</td>
                <td><a href="download.php?table=notes&id=654&file=2017/notes/CNS- Unit 32017-12-01 18:06:38.pdf">Graph Theory Unit 3 </a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>244</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.2MB</td>

              </tr>
                            <tr>
                <td>229</td>
                <td><a href="download.php?table=notes&id=653&file=2017/notes/Unit 4 (Photocopy Notes)2017-12-01 18:02:43.pdf">Unit 4 Positive Real Numbers</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>222</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.3MB</td>

              </tr>
                            <tr>
                <td>230</td>
                <td><a href="download.php?table=notes&id=651&file=2017/notes/Matrices notes NotesHub2017-12-01 17:53:43.pdf">Matrices Unit 3 </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>362</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>50.6MB</td>

              </tr>
                            <tr>
                <td>231</td>
                <td><a href="download.php?table=notes&id=650&file=2017/notes/Diffraction2017-12-01 17:45:30.pdf">Photocopied Notes</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>502</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>232</td>
                <td><a href="download.php?table=notes&id=649&file=2017/notes/Magnetic Circuits Notes Noteshub2017-12-01 17:41:07.pdf">Magnetic Circuits Handwritten </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>517</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>233</td>
                <td><a href="download.php?table=notes&id=645&file=2017/notes/Signal and Systems - Noteshub2017-12-01 17:26:15.pdf">Unit 2</a></td>
                <td>Signals and Systems</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>161</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.9MB</td>

              </tr>
                            <tr>
                <td>234</td>
                <td><a href="download.php?table=notes&id=642&file=2017/notes/FOC complete2017-12-01 17:09:20.pdf">FOC Complete Notes</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1389</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>55.2MB</td>

              </tr>
                            <tr>
                <td>235</td>
                <td><a href="download.php?table=notes&id=641&file=2017/notes/app of integration2017-12-01 16:57:07.pdf">Application of Integration</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>245</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>236</td>
                <td><a href="download.php?table=notes&id=640&file=2017/notes/Water - Unit 32017-12-01 11:40:44.pdf">Water Technology Unit 3</a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>920</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.7MB</td>

              </tr>
                            <tr>
                <td>237</td>
                <td><a href="download.php?table=notes&id=639&file=2017/notes/Phase Rule - Unit 22017-12-01 11:38:30.pdf">Phase Rule Printed Notes </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>489</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.6MB</td>

              </tr>
                            <tr>
                <td>238</td>
                <td><a href="download.php?table=notes&id=638&file=2017/notes/AC Fundamentals - Unit 22017-12-01 11:34:04.pdf">AC Fundamentals Unit 2</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>593</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.7MB</td>

              </tr>
                            <tr>
                <td>239</td>
                <td><a href="download.php?table=notes&id=637&file=2017/notes/Fibre Optics - Unit 22017-12-01 11:31:56.pdf">Fibre Optics Unit 2</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>485</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.7MB</td>

              </tr>
                            <tr>
                <td>240</td>
                <td><a href="download.php?table=notes&id=636&file=2017/notes/Intereference Unit 12017-12-01 11:30:35.pdf">Intereference Unit 1</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>577</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.5MB</td>

              </tr>
                            <tr>
                <td>241</td>
                <td><a href="download.php?table=notes&id=635&file=2017/notes/Bessels And legendres Functions - Unit 42017-12-01 11:27:20.pdf">Bessels And legendres Functions Unit 4</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>367</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7MB</td>

              </tr>
                            <tr>
                <td>242</td>
                <td><a href="download.php?table=notes&id=634&file=2017/notes/Homogenous Linear Differential Equations - Unit 42017-12-01 11:26:22.pdf">Homogenous Linear Differential Equations Unit 4</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>172</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.7MB</td>

              </tr>
                            <tr>
                <td>243</td>
                <td><a href="download.php?table=notes&id=633&file=2017/notes/Curve Tracing2017-12-01 11:25:12.pdf">Curve Tracing Printed Notes </a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>184</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.6MB</td>

              </tr>
                            <tr>
                <td>244</td>
                <td><a href="download.php?table=notes&id=632&file=2017/notes/142017-12-01 10:29:18.pdf">Spread Spectrum in Detail</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>162</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>940.4KB</td>

              </tr>
                            <tr>
                <td>245</td>
                <td><a href="download.php?table=notes&id=631&file=2017/notes/132017-12-01 10:28:06.pdf">IS 95 CDMA and Spread Spectrum</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>150</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>874.6KB</td>

              </tr>
                            <tr>
                <td>246</td>
                <td><a href="download.php?table=notes&id=630&file=2017/notes/122017-12-01 10:26:45.pdf">GSM 4 Lectures </a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>178</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>247</td>
                <td><a href="download.php?table=notes&id=629&file=2017/notes/112017-12-01 10:25:46.pdf">Introduction to Diversity</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>109</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>248</td>
                <td><a href="download.php?table=notes&id=628&file=2017/notes/102017-12-01 10:25:06.pdf">Introduction to wireless channels and diversity</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>120</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>249</td>
                <td><a href="download.php?table=notes&id=627&file=2017/notes/92017-12-01 10:24:07.pdf">Network Signaling</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>126</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>250</td>
                <td><a href="download.php?table=notes&id=626&file=2017/notes/82017-12-01 10:22:56.pdf">Mobility Management</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>140</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>251</td>
                <td><a href="download.php?table=notes&id=625&file=2017/notes/72017-12-01 10:22:06.pdf">Personal Communication Systems</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>146</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>908.1KB</td>

              </tr>
                            <tr>
                <td>252</td>
                <td><a href="download.php?table=notes&id=624&file=2017/notes/62017-12-01 10:20:53.pdf">Generations of wireless cellular systems</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>130</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.3MB</td>

              </tr>
                            <tr>
                <td>253</td>
                <td><a href="download.php?table=notes&id=623&file=2017/notes/52017-12-01 10:19:34.pdf">A Basic Cellular System</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>119</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>780.2KB</td>

              </tr>
                            <tr>
                <td>254</td>
                <td><a href="download.php?table=notes&id=622&file=2017/notes/42017-12-01 10:18:15.pdf">Paging and cordless systems</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>84</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>863.1KB</td>

              </tr>
                            <tr>
                <td>255</td>
                <td><a href="download.php?table=notes&id=621&file=2017/notes/32017-12-01 10:16:42.pdf">General Architecture of Cellular Systems</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>78</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.9MB</td>

              </tr>
                            <tr>
                <td>256</td>
                <td><a href="download.php?table=notes&id=620&file=2017/notes/22017-12-01 10:14:15.pdf">Introduction about Spectrum Allocation in Wireless communication</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>73</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>257</td>
                <td><a href="download.php?table=notes&id=619&file=2017/notes/12017-12-01 10:12:46.pdf">Introduction to wireless communications</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>93</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>258</td>
                <td><a href="download.php?table=notes&id=617&file=2017/notes/CSP2017-11-30 14:51:45.pdf">Photocopied Notes</a></td>
                <td>Communication Skills for Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>320</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12MB</td>

              </tr>
                            <tr>
                <td>259</td>
                <td><a href="download.php?table=notes&id=616&file=2017/notes/DCN-12017-11-30 14:44:18.pdf">Handwritten notes</a></td>
                <td>Data Communication and Networks</td>
                <!--<td></td>-->
                <td>IT, ECE, MAE</td>
                <td>434</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.9MB</td>

              </tr>
                            <tr>
                <td>260</td>
                <td><a href="download.php?table=notes&id=615&file=2017/notes/Lasers With assignment2017-11-29 21:18:55.pdf">Laser Notes With Assignment </a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>562</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.6MB</td>

              </tr>
                            <tr>
                <td>261</td>
                <td><a href="download.php?table=notes&id=614&file=2017/notes/Switching Theory and Logic Design2017-11-29 18:55:14.pdf">Lecture Notes</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>361</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10MB</td>

              </tr>
                            <tr>
                <td>262</td>
                <td><a href="download.php?table=notes&id=613&file=2017/notes/UltraSonic2017-11-29 09:59:44.pdf">Unit 3 Ultrasonic</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>782</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.6MB</td>

              </tr>
                            <tr>
                <td>263</td>
                <td><a href="download.php?table=notes&id=612&file=2017/notes/MP notes unit 12017-11-28 16:06:52.pdf">MP Unit 1 </a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1031</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.2MB</td>

              </tr>
                            <tr>
                <td>264</td>
                <td><a href="download.php?table=notes&id=611&file=2017/notes/viden-K66-IS-22017-11-27 23:06:38.pdf">Unit 3 and 4</a></td>
                <td>Information Security</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>201</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.4MB</td>

              </tr>
                            <tr>
                <td>265</td>
                <td><a href="download.php?table=notes&id=610&file=2017/notes/Water Cooler2017-11-26 13:10:47.pdf">Water Cooler</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>38</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>42.3KB</td>

              </tr>
                            <tr>
                <td>266</td>
                <td><a href="download.php?table=notes&id=609&file=2017/notes/Ice Plant2017-11-26 13:09:52.pdf">Ice Plant</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>66.2KB</td>

              </tr>
                            <tr>
                <td>267</td>
                <td><a href="download.php?table=notes&id=608&file=2017/notes/Food Preservation2017-11-26 13:09:17.pdf">Food Preservation</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>38</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>294.2KB</td>

              </tr>
                            <tr>
                <td>268</td>
                <td><a href="download.php?table=notes&id=607&file=2017/notes/Expansion Device2017-11-26 13:07:44.pdf">Expansion Device </a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>44</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>335.1KB</td>

              </tr>
                            <tr>
                <td>269</td>
                <td><a href="download.php?table=notes&id=606&file=2017/notes/Evaporator2017-11-26 13:07:04.pdf">Evaporator</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>270</td>
                <td><a href="download.php?table=notes&id=605&file=2017/notes/Duct Design2017-11-26 13:05:23.pdf">Duct Design</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>42</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>203.6KB</td>

              </tr>
                            <tr>
                <td>271</td>
                <td><a href="download.php?table=notes&id=604&file=2017/notes/Cooling Tower2017-11-26 13:04:11.pdf">Cooling Tower</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>43</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>616.6KB</td>

              </tr>
                            <tr>
                <td>272</td>
                <td><a href="download.php?table=notes&id=603&file=2017/notes/CONDENSER2017-11-26 13:03:29.pdf">Condenser</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>668.3KB</td>

              </tr>
                            <tr>
                <td>273</td>
                <td><a href="download.php?table=notes&id=602&file=2017/notes/Compressor2017-11-26 13:02:19.pdf">Compressor</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>48</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>664.1KB</td>

              </tr>
                            <tr>
                <td>274</td>
                <td><a href="download.php?table=notes&id=601&file=2017/notes/Cold Storage2017-11-26 13:00:49.pdf">Cold Storage</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>40</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>73.7KB</td>

              </tr>
                            <tr>
                <td>275</td>
                <td><a href="download.php?table=notes&id=600&file=2017/notes/Air Washer2017-11-26 12:58:21.pdf">Air Washer</a></td>
                <td>Refrigeration and Air Conditioning</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>42</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>74.7KB</td>

              </tr>
                            <tr>
                <td>276</td>
                <td><a href="download.php?table=notes&id=599&file=2017/notes/PM-New2017-11-26 10:39:56.pdf">Project Management CPM and PERT</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>50</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>277</td>
                <td><a href="download.php?table=notes&id=598&file=2017/notes/Unit V Queuing Theory-New2017-11-26 10:36:14.pdf">Queing Theory</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>579.8KB</td>

              </tr>
                            <tr>
                <td>278</td>
                <td><a href="download.php?table=notes&id=597&file=2017/notes/Theory of Games or Competitive-NOTES2017-11-26 10:35:33.pdf">Theory of games or competetive</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>41</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>834.3KB</td>

              </tr>
                            <tr>
                <td>279</td>
                <td><a href="download.php?table=notes&id=596&file=2017/notes/Simulation-NOTES2017-11-26 10:34:47.pdf">Simulation</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>40</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>340.7KB</td>

              </tr>
                            <tr>
                <td>280</td>
                <td><a href="download.php?table=notes&id=595&file=2017/notes/My Transportation and Assignment problem2017-11-26 10:33:28.pdf">Transportation and Assignment Problem</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>42</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>281</td>
                <td><a href="download.php?table=notes&id=594&file=2017/notes/My Sequencing2017-11-26 10:32:43.pdf">Sequencing</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>42</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.2MB</td>

              </tr>
                            <tr>
                <td>282</td>
                <td><a href="download.php?table=notes&id=593&file=2017/notes/My Queuing Systems and Discrete System Simulation2017-11-26 10:31:42.pdf">Queing and Discrete System Simulation</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>39</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>595.5KB</td>

              </tr>
                            <tr>
                <td>283</td>
                <td><a href="download.php?table=notes&id=591&file=2017/notes/My Linear Programming-1-R12017-11-26 10:19:54.pdf">Linear Programming</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>45</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.4MB</td>

              </tr>
                            <tr>
                <td>284</td>
                <td><a href="download.php?table=notes&id=590&file=2017/notes/My DP2017-11-26 10:16:20.pdf">Dynamic Programming</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>35</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>351.2KB</td>

              </tr>
                            <tr>
                <td>285</td>
                <td><a href="download.php?table=notes&id=589&file=2017/notes/MyDecision Theoryx2017-11-26 10:12:09.pdf">Decision Theory</a></td>
                <td>Operations Research</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>35</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>438.8KB</td>

              </tr>
                            <tr>
                <td>286</td>
                <td><a href="download.php?table=notes&id=587&file=2017/notes/Weak Authentication2017-11-15 14:16:53.pptx">Weak Authentication</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>237</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>118.1KB</td>

              </tr>
                            <tr>
                <td>287</td>
                <td><a href="download.php?table=notes&id=585&file=2017/notes/EGL general help and Viva2017-11-14 18:04:09.pdf">EGL Viva</a></td>
                <td>Engineering Graphics Lab</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>464</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.4MB</td>

              </tr>
                            <tr>
                <td>288</td>
                <td><a href="download.php?table=notes&id=584&file=2017/notes/18477236-viva-questions-i2017-11-12 13:32:14.pdf">Chemistry Viva</a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>471</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>174.3KB</td>

              </tr>
                            <tr>
                <td>289</td>
                <td><a href="download.php?table=notes&id=583&file=2017/notes/Fundamentals of Electrical Engg2017-11-11 21:29:09.pdf">ET Viva Questions</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>552</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>282.9KB</td>

              </tr>
                            <tr>
                <td>290</td>
                <td><a href="download.php?table=notes&id=582&file=2017/notes/Phy Viva Unit 12017-11-11 20:40:59.pdf">Applied Physics Viva Questions</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>514</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>161.7KB</td>

              </tr>
                            <tr>
                <td>291</td>
                <td><a href="download.php?table=notes&id=581&file=2017/notes/engineering-graphics-lab-manual FINAL2017-11-11 19:10:45.pdf">EGL Lab Manual</a></td>
                <td>Engineering Graphics Lab</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>415</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.2MB</td>

              </tr>
                            <tr>
                <td>292</td>
                <td><a href="download.php?table=notes&id=580&file=2017/notes/DS - All Notes2017-11-11 16:36:18.docx">All Notes Word file contains download link as file is too large </a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>440</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.6KB</td>

              </tr>
                            <tr>
                <td>293</td>
                <td><a href="download.php?table=notes&id=579&file=2017/notes/DS - important questions2017-11-11 15:46:50.pdf">Important Questions</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>347</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>294</td>
                <td><a href="download.php?table=notes&id=578&file=2017/notes/EGL general help and Viva2017-11-08 22:08:16.pdf">General Viva</a></td>
                <td>Engineering Graphics Lab</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>622</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.4MB</td>

              </tr>
                            <tr>
                <td>295</td>
                <td><a href="download.php?table=notes&id=577&file=2017/notes/MP Imp ques2017-11-08 19:59:20.pdf">MP Important Questions For Externals</a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1008</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>296</td>
                <td><a href="download.php?table=notes&id=576&file=2017/notes/Maths Unit 32017-11-07 23:06:51.pdf">Asymptotes And Curve Tracing Notes</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>504</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.5MB</td>

              </tr>
                            <tr>
                <td>297</td>
                <td><a href="download.php?table=notes&id=575&file=2017/notes/combinepdf2017-11-06 12:30:17.pdf">HVPE Notes 1st Sem</a></td>
                <td>Human Values and Professional Ethics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>288</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.7MB</td>

              </tr>
                            <tr>
                <td>298</td>
                <td><a href="download.php?table=notes&id=573&file=2017/notes/chem_water2017-11-04 13:19:45.pdf">Water Notes Printed </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1097</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.7MB</td>

              </tr>
                            <tr>
                <td>299</td>
                <td><a href="download.php?table=notes&id=572&file=2017/notes/Chem Phase Rule And Water Handwritten2017-11-04 13:18:03.pdf">Phase Rule and Water Class Notes </a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>862</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.5MB</td>

              </tr>
                            <tr>
                <td>300</td>
                <td><a href="download.php?table=notes&id=571&file=2017/notes/2010chapter-6Phaseruleedited2017-11-03 21:23:16.pdf">Phase rule</a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>666</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>449KB</td>

              </tr>
                            <tr>
                <td>301</td>
                <td><a href="download.php?table=notes&id=570&file=2017/notes/Unit I - Water Technology2017-11-03 21:22:16.pdf">Water Technology</a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>816</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>189.6KB</td>

              </tr>
                            <tr>
                <td>302</td>
                <td><a href="download.php?table=notes&id=569&file=2017/notes/Corrosion Notes 1st Sem2017-11-03 19:48:27.pdf">Corrosion Notes</a></td>
                <td>Applied Chemistry</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1135</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.3MB</td>

              </tr>
                            <tr>
                <td>303</td>
                <td><a href="download.php?table=notes&id=567&file=2017/notes/Unit 4 Libre Offics Detailed2017-11-02 13:02:29.pdf">Libre Office Unit 4 Detailed Notes</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1327</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>590.4KB</td>

              </tr>
                            <tr>
                <td>304</td>
                <td><a href="download.php?table=notes&id=566&file=2017/notes/Unit 3 detailed notes2017-11-02 13:01:28.pdf">Unit 3 Detailed Notes </a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>924</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>753.7KB</td>

              </tr>
                            <tr>
                <td>305</td>
                <td><a href="download.php?table=notes&id=565&file=2017/notes/Unit 3 and 4 Short notes2017-11-02 13:00:21.pdf">Unit 3 And 4 Short Notes</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1053</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.5MB</td>

              </tr>
                            <tr>
                <td>306</td>
                <td><a href="download.php?table=notes&id=564&file=2017/notes/EMI Unit 3-42017-11-02 00:25:06.pdf">Unit 3 and 4</a></td>
                <td>Electronic Instruments and Measurements</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>456</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.4MB</td>

              </tr>
                            <tr>
                <td>307</td>
                <td><a href="download.php?table=notes&id=563&file=2017/notes/Testing Tools2017-11-01 22:44:44.pdf">Unit 4 Testing Tools</a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>332</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.6MB</td>

              </tr>
                            <tr>
                <td>308</td>
                <td><a href="download.php?table=notes&id=562&file=2017/notes/ET Unit 32017-11-01 21:57:25.pdf">Unit 3 </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1152</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.9MB</td>

              </tr>
                            <tr>
                <td>309</td>
                <td><a href="download.php?table=notes&id=561&file=2017/notes/ST unit 32017-11-01 21:52:07.pdf">Unit 3 Book Notes</a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>317</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>25.3MB</td>

              </tr>
                            <tr>
                <td>310</td>
                <td><a href="download.php?table=notes&id=560&file=2017/notes/Unit 4 Book Notes2017-10-31 22:57:15.pdf">Unit 4</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>435</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>60.1MB</td>

              </tr>
                            <tr>
                <td>311</td>
                <td><a href="download.php?table=notes&id=559&file=2017/notes/WC 2nd Sessionals2017-10-31 22:18:34.pdf">2nd Sessional model test papers</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>137</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.3MB</td>

              </tr>
                            <tr>
                <td>312</td>
                <td><a href="download.php?table=notes&id=558&file=2017/notes/MP 2nd Sessional2017-10-31 15:32:05.pdf">MP 2nd Sessional</a></td>
                <td>Manufacturing Processes</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1236</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.8MB</td>

              </tr>
                            <tr>
                <td>313</td>
                <td><a href="download.php?table=notes&id=557&file=2017/notes/unit4_system_security2017-10-30 21:25:27.pdf">Unit 4</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>417</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>314</td>
                <td><a href="download.php?table=notes&id=556&file=2017/notes/side channel attacks2017-10-30 21:24:47.pdf">Unit 3 Side Channel Attacks</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>291</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>251.1KB</td>

              </tr>
                            <tr>
                <td>315</td>
                <td><a href="download.php?table=notes&id=555&file=2017/notes/buffer overflow2017-10-30 21:23:00.docx">Unit 3 Buffer Overflow Attack</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>296</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.6KB</td>

              </tr>
                            <tr>
                <td>316</td>
                <td><a href="download.php?table=notes&id=554&file=2017/notes/S_BOXES2017-10-30 21:20:31.pdf">Unit 3 S Boxes</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>282</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>904.1KB</td>

              </tr>
                            <tr>
                <td>317</td>
                <td><a href="download.php?table=notes&id=553&file=2017/notes/Unit 32017-10-30 21:09:05.pdf">Unit 3</a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>280</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.2MB</td>

              </tr>
                            <tr>
                <td>318</td>
                <td><a href="download.php?table=notes&id=552&file=2017/notes/Unit 4 - Type 22017-10-30 21:08:13.pdf">Unit 4 Type 2 </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>279</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.2MB</td>

              </tr>
                            <tr>
                <td>319</td>
                <td><a href="download.php?table=notes&id=551&file=2017/notes/Unit 42017-10-30 21:06:42.pdf">Unit 4 Type 1 </a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>308</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.6MB</td>

              </tr>
                            <tr>
                <td>320</td>
                <td><a href="download.php?table=notes&id=550&file=2017/notes/Radioactivity2017-10-30 19:46:42.pdf">Radioactivity And Nuclear Physics</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1264</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.8MB</td>

              </tr>
                            <tr>
                <td>321</td>
                <td><a href="download.php?table=notes&id=549&file=2017/notes/Special Theory Of Relativity2017-10-30 19:44:49.pdf">Special Theory Of Relativity</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>843</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.4MB</td>

              </tr>
                            <tr>
                <td>322</td>
                <td><a href="download.php?table=notes&id=548&file=2017/notes/Polarization corrected2017-10-30 19:22:33.pdf">Polarization</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>748</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13MB</td>

              </tr>
                            <tr>
                <td>323</td>
                <td><a href="download.php?table=notes&id=547&file=2017/notes/Unit -4 machine notes2017-10-30 00:41:21.pdf">Unit 4</a></td>
                <td>Electrical Machines</td>
                <!--<td></td>-->
                <td>MAE, EEE</td>
                <td>157</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.4MB</td>

              </tr>
                            <tr>
                <td>324</td>
                <td><a href="download.php?table=notes&id=546&file=2017/notes/ACN UNIT 42017-10-29 19:47:16.pdf">Unit 4 Book Notes </a></td>
                <td>Advanced Computer Networks</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>343</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.9MB</td>

              </tr>
                            <tr>
                <td>325</td>
                <td><a href="download.php?table=notes&id=545&file=2017/notes/Successive Differentiation2017-10-29 13:15:08.pdf">Successive Diffrentiation</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>404</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.7MB</td>

              </tr>
                            <tr>
                <td>326</td>
                <td><a href="download.php?table=notes&id=544&file=2017/notes/Reduction Formula2017-10-29 13:12:50.pdf">Reduction Formula</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>368</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.4MB</td>

              </tr>
                            <tr>
                <td>327</td>
                <td><a href="download.php?table=notes&id=543&file=2017/notes/Linear Differential Equation of Higher Order2017-10-29 13:10:44.pdf">Linear Diffrential Equation</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>423</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.5MB</td>

              </tr>
                            <tr>
                <td>328</td>
                <td><a href="download.php?table=notes&id=542&file=2017/notes/Infinite Series2017-10-29 13:06:50.pdf">Infinite Series</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>323</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.3MB</td>

              </tr>
                            <tr>
                <td>329</td>
                <td><a href="download.php?table=notes&id=541&file=2017/notes/Differential Equation2017-10-29 13:06:09.pdf">Diffrential Equation</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>413</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>330</td>
                <td><a href="download.php?table=notes&id=540&file=2017/notes/Expansion of Function2017-10-29 13:05:30.pdf">Expansioin of function</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>254</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.8MB</td>

              </tr>
                            <tr>
                <td>331</td>
                <td><a href="download.php?table=notes&id=539&file=2017/notes/Curvature2017-10-29 13:04:17.pdf">Curvature</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>262</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.3MB</td>

              </tr>
                            <tr>
                <td>332</td>
                <td><a href="download.php?table=notes&id=538&file=2017/notes/Beta Gamma Function2017-10-29 13:03:03.pdf">Beta Gamma</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>391</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.1MB</td>

              </tr>
                            <tr>
                <td>333</td>
                <td><a href="download.php?table=notes&id=537&file=2017/notes/Asymptotes2017-10-29 13:02:15.pdf">Asymptotes</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>262</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.7MB</td>

              </tr>
                            <tr>
                <td>334</td>
                <td><a href="download.php?table=notes&id=536&file=2017/notes/Approximate Calculation2017-10-29 13:01:17.pdf">Approximates</a></td>
                <td>Applied Mathematics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>234</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.8MB</td>

              </tr>
                            <tr>
                <td>335</td>
                <td><a href="download.php?table=notes&id=535&file=2017/notes/et lecture2017-10-29 12:51:40.pdf">ET lecture notes </a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1119</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.4MB</td>

              </tr>
                            <tr>
                <td>336</td>
                <td><a href="download.php?table=notes&id=534&file=2017/notes/Btech 1sem memory2017-10-29 12:48:09.pdf">Memory</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>533</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>132.2KB</td>

              </tr>
                            <tr>
                <td>337</td>
                <td><a href="download.php?table=notes&id=533&file=2017/notes/Btech 1sem ROM and its types2017-10-29 12:47:24.pdf">ROM its types</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>503</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>105.5KB</td>

              </tr>
                            <tr>
                <td>338</td>
                <td><a href="download.php?table=notes&id=532&file=2017/notes/Btech 1sem MSDOS2017-10-29 12:46:40.pdf">MSDOS</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>610</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>184.7KB</td>

              </tr>
                            <tr>
                <td>339</td>
                <td><a href="download.php?table=notes&id=531&file=2017/notes/Btech 1sem Types of Computer2017-10-29 12:46:04.pdf">Types of computers</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>422</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>162.3KB</td>

              </tr>
                            <tr>
                <td>340</td>
                <td><a href="download.php?table=notes&id=530&file=2017/notes/Btech 1sem Computer Generations2017-10-29 12:45:20.pdf">Computer Generations</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>453</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>217.7KB</td>

              </tr>
                            <tr>
                <td>341</td>
                <td><a href="download.php?table=notes&id=529&file=2017/notes/Btech 1sem output devices2017-10-29 12:44:05.pdf">Output devices</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>357</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>199.8KB</td>

              </tr>
                            <tr>
                <td>342</td>
                <td><a href="download.php?table=notes&id=528&file=2017/notes/Btech 1sem input devises2017-10-29 12:43:26.pdf">Input devices</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>348</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>208.8KB</td>

              </tr>
                            <tr>
                <td>343</td>
                <td><a href="download.php?table=notes&id=527&file=2017/notes/Components of computer2017-10-29 12:38:54.pdf">Components of computer</a></td>
                <td>Fundamentals of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>428</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>301.7KB</td>

              </tr>
                            <tr>
                <td>344</td>
                <td><a href="download.php?table=notes&id=526&file=2017/notes/et lecture2017-10-27 15:28:40.pdf">ET Complete 1st semester notes</a></td>
                <td>Electrical Technology</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>2158</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.4MB</td>

              </tr>
                            <tr>
                <td>345</td>
                <td><a href="download.php?table=notes&id=525&file=2017/notes/ACN Unit 32017-10-27 14:50:03.pdf">ACN Unit 3 Book Notes </a></td>
                <td>Advanced Computer Networks</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>313</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.2MB</td>

              </tr>
                            <tr>
                <td>346</td>
                <td><a href="download.php?table=notes&id=522&file=2017/notes/ENGG PHYSICS_CLASS_NOTES2017-09-30 11:31:43.pdf">Short Class Notes</a></td>
                <td>Applied Physics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>856</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.2MB</td>

              </tr>
                            <tr>
                <td>347</td>
                <td><a href="download.php?table=notes&id=521&file=2017/notes/DS sem 32017-09-26 23:13:28.pdf">Supreme DS notes I</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, EEE, ECE</td>
                <td>426</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>348</td>
                <td><a href="download.php?table=notes&id=519&file=2017/notes/AE NOTES PART 22017-09-26 22:24:32.pdf">Notes Part 2 Photocopied Notes</a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>401</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17MB</td>

              </tr>
                            <tr>
                <td>349</td>
                <td><a href="download.php?table=notes&id=518&file=2017/notes/AE NOTES PART 12017-09-26 22:17:29.pdf">Notes Part 1 Photocopied Notes</a></td>
                <td>Analog Electronics I</td>
                <!--<td></td>-->
                <td>EEE, ECE</td>
                <td>478</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>350</td>
                <td><a href="download.php?table=notes&id=517&file=2017/notes/Unit 1 (c)2017-09-23 18:13:09.pdf">Unit 1 c Handwritten Notes</a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>125</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.9MB</td>

              </tr>
                            <tr>
                <td>351</td>
                <td><a href="download.php?table=notes&id=516&file=2017/notes/Unit 1 (b)2017-09-23 17:56:11.pdf">Unit 1 b Handwritten Notes</a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>95</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.1MB</td>

              </tr>
                            <tr>
                <td>352</td>
                <td><a href="download.php?table=notes&id=515&file=2017/notes/Unit 1 (a)2017-09-23 17:54:22.pdf">Unit 1 a Handwritten Notes</a></td>
                <td>Radar and Navigation</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>131</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.8MB</td>

              </tr>
                            <tr>
                <td>353</td>
                <td><a href="download.php?table=notes&id=512&file=2017/notes/Unit-1 Cloud Computing2017-09-22 19:52:27.pdf">Unit 1</a></td>
                <td>Cloud Computing </td>
                <!--<td></td>-->
                <td>IT</td>
                <td>188</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>354</td>
                <td><a href="download.php?table=notes&id=511&file=2017/notes/Unit 2 Cloud Computing2017-09-22 19:33:38.pdf">Unit 2</a></td>
                <td>Cloud Computing </td>
                <!--<td></td>-->
                <td>IT</td>
                <td>142</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>355</td>
                <td><a href="download.php?table=notes&id=510&file=2017/notes/Mastering Cloud Computing2017-09-22 19:21:05.pdf">Mastering Cloud Computing Foundations and Applications Programming</a></td>
                <td>Cloud Computing </td>
                <!--<td></td>-->
                <td>IT</td>
                <td>161</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26.8MB</td>

              </tr>
                            <tr>
                <td>356</td>
                <td><a href="download.php?table=notes&id=509&file=2017/notes/xmlndado2017-09-22 16:19:02.pdf">XML and ADO NET</a></td>
                <td>Dot Net and C Sharp Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>175</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>724.4KB</td>

              </tr>
                            <tr>
                <td>357</td>
                <td><a href="download.php?table=notes&id=508&file=2017/notes/questionbank2017-09-22 16:17:52.pdf">Question Bank</a></td>
                <td>Dot Net and C Sharp Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>174</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>434.2KB</td>

              </tr>
                            <tr>
                <td>358</td>
                <td><a href="download.php?table=notes&id=507&file=2017/notes/Impques32017-09-22 16:17:10.pdf">Notes Part 3 </a></td>
                <td>Dot Net and C Sharp Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>187</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>427.6KB</td>

              </tr>
                            <tr>
                <td>359</td>
                <td><a href="download.php?table=notes&id=506&file=2017/notes/ImpQues22017-09-22 16:16:34.pdf">Notes Part 2 </a></td>
                <td>Dot Net and C Sharp Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>185</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>195.8KB</td>

              </tr>
                            <tr>
                <td>360</td>
                <td><a href="download.php?table=notes&id=505&file=2017/notes/ImpQues2017-09-22 16:16:06.pdf">Notes Part 1 </a></td>
                <td>Dot Net and C Sharp Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>237</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>215.7KB</td>

              </tr>
                            <tr>
                <td>361</td>
                <td><a href="download.php?table=notes&id=504&file=2017/notes/SandS2017-09-22 15:49:01.pdf">S and S Notes</a></td>
                <td>Signals and Systems</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>532</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26.9MB</td>

              </tr>
                            <tr>
                <td>362</td>
                <td><a href="download.php?table=notes&id=503&file=2017/notes/Riveted Joints notes2017-09-21 21:23:51.pdf">Riveted Joints</a></td>
                <td>Machine Design</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>82</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.9MB</td>

              </tr>
                            <tr>
                <td>363</td>
                <td><a href="download.php?table=notes&id=502&file=2017/notes/Welded Joints notes2017-09-21 21:23:01.pdf">Welded Joints</a></td>
                <td>Machine Design</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>73</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.4MB</td>

              </tr>
                            <tr>
                <td>364</td>
                <td><a href="download.php?table=notes&id=501&file=2017/notes/digital-modulation2017-09-21 16:57:42.pdf">Digital modulation</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>271</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>339.7KB</td>

              </tr>
                            <tr>
                <td>365</td>
                <td><a href="download.php?table=notes&id=500&file=2017/notes/pulse-modulation2017-09-21 16:56:56.pdf">Pulse Modulation</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>153</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>137.3KB</td>

              </tr>
                            <tr>
                <td>366</td>
                <td><a href="download.php?table=notes&id=499&file=2017/notes/angle-modulation2017-09-21 16:56:14.pdf">Angle modulation</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>113</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>206KB</td>

              </tr>
                            <tr>
                <td>367</td>
                <td><a href="download.php?table=notes&id=497&file=2017/notes/amplitude-modulation2017-09-21 16:55:22.pdf">Amplitude modulation </a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>114</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>323.9KB</td>

              </tr>
                            <tr>
                <td>368</td>
                <td><a href="download.php?table=notes&id=495&file=2017/notes/comm-system-intro2017-09-21 16:53:48.pdf">Intro Communication systems </a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>140</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>588KB</td>

              </tr>
                            <tr>
                <td>369</td>
                <td><a href="download.php?table=notes&id=494&file=2017/notes/CS MAM2017-09-21 16:34:20.pdf">Unit 1 and 2 Handwritten </a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT, EEE</td>
                <td>1038</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>46.9MB</td>

              </tr>
                            <tr>
                <td>370</td>
                <td><a href="download.php?table=notes&id=493&file=2017/notes/DS sem 32017-09-21 16:00:38.pdf">DS UNIT 1 and 2</a></td>
                <td>Data Structure</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE, EEE</td>
                <td>569</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>371</td>
                <td><a href="download.php?table=notes&id=492&file=2017/notes/EC6501 Digital Communication Lecture Notes2017-09-21 14:14:47.pdf">Reference Notes</a></td>
                <td>Digital Communication</td>
                <!--<td></td>-->
                <td>CSE, ECE</td>
                <td>265</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.3MB</td>

              </tr>
                            <tr>
                <td>372</td>
                <td><a href="download.php?table=notes&id=491&file=2017/notes/ADBA-Unit 12017-09-21 07:39:20.pdf">Unit 1</a></td>
                <td>Advanced Database Administration</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>385</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>795.3KB</td>

              </tr>
                            <tr>
                <td>373</td>
                <td><a href="download.php?table=notes&id=490&file=2017/notes/Unit 12017-09-21 07:28:30.pdf">Unit 1 Book Notes </a></td>
                <td>Software Testing and Quality Assurance</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>252</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>374</td>
                <td><a href="download.php?table=notes&id=489&file=2017/notes/Structural Testing2017-09-21 07:27:28.pdf">Structural Testing Book Notes </a></td>
                <td>Software Testing and Quality Assurance</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>198</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.2MB</td>

              </tr>
                            <tr>
                <td>375</td>
                <td><a href="download.php?table=notes&id=486&file=2017/notes/Unit 12017-09-21 07:11:35.pdf">Unit 1 Book Notes Complete</a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>302</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>376</td>
                <td><a href="download.php?table=notes&id=485&file=2017/notes/Structural Testing2017-09-21 06:55:59.pdf">Unit 2 Structural Testing</a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>263</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.2MB</td>

              </tr>
                            <tr>
                <td>377</td>
                <td><a href="download.php?table=notes&id=484&file=2017/notes/Functional Testing2017-09-21 06:42:59.pdf">Unit 2 Functional Testing</a></td>
                <td>Software Testing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>252</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>15MB</td>

              </tr>
                            <tr>
                <td>378</td>
                <td><a href="download.php?table=notes&id=483&file=2017/notes/Java II2017-09-20 19:21:44.pdf">Java Notes Part II</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>311</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>39.5MB</td>

              </tr>
                            <tr>
                <td>379</td>
                <td><a href="download.php?table=notes&id=481&file=2017/notes/Java I2017-09-20 18:51:48.pdf">Java Notes Part I till Threading </a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE, IT</td>
                <td>362</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>56.4MB</td>

              </tr>
                            <tr>
                <td>380</td>
                <td><a href="download.php?table=notes&id=480&file=2017/notes/Unit 2 Part II2017-09-19 21:30:35.pdf">Unit 2 Notes Part II</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>244</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.5MB</td>

              </tr>
                            <tr>
                <td>381</td>
                <td><a href="download.php?table=notes&id=479&file=2017/notes/Unit 2 Part I2017-09-19 20:58:24.pdf">Unit 2 Notes Part I</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>301</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>37.4MB</td>

              </tr>
                            <tr>
                <td>382</td>
                <td><a href="download.php?table=notes&id=478&file=2017/notes/WC Chapter 32017-09-19 17:27:48.pdf">Unit 1 Part B</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>238</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.5MB</td>

              </tr>
                            <tr>
                <td>383</td>
                <td><a href="download.php?table=notes&id=477&file=2017/notes/WC Chapter 1,22017-09-19 17:24:41.pdf">Unit 1 Part A</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>415</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>61MB</td>

              </tr>
                            <tr>
                <td>384</td>
                <td><a href="download.php?table=notes&id=476&file=2017/notes/viden-K66-STQA-22017-09-18 22:31:42.pdf">Unit 2</a></td>
                <td>Software Testing and Quality Assurance</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>242</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>151.6KB</td>

              </tr>
                            <tr>
                <td>385</td>
                <td><a href="download.php?table=notes&id=475&file=2017/notes/viden-K66-STQA-12017-09-18 22:30:25.pdf">Unit 1</a></td>
                <td>Software Testing and Quality Assurance</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>246</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>814.3KB</td>

              </tr>
                            <tr>
                <td>386</td>
                <td><a href="download.php?table=notes&id=474&file=2017/notes/Functional Testing2017-09-18 21:11:30.pdf">Functional Testing Book Notes </a></td>
                <td>Software Testing and Quality Assurance</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>200</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>15MB</td>

              </tr>
                            <tr>
                <td>387</td>
                <td><a href="download.php?table=notes&id=473&file=2017/notes/mms 12017-09-18 21:10:03.pdf">Sessional 1 Important topics</a></td>
                <td>Management of Manufacturing Systems</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>85</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>388</td>
                <td><a href="download.php?table=notes&id=472&file=2017/notes/cns2017-09-18 20:54:59.pdf">Notes Complete Syllabus</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>493</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>699.2KB</td>

              </tr>
                            <tr>
                <td>389</td>
                <td><a href="download.php?table=notes&id=471&file=2017/notes/Cryptography Sem 72017-09-18 20:44:12.pdf">Cryptography Unit 2</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>441</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>593KB</td>

              </tr>
                            <tr>
                <td>390</td>
                <td><a href="download.php?table=notes&id=470&file=2017/notes/Crypto Sem 72017-09-18 20:42:46.pdf">Cryptography Unit 1</a></td>
                <td>Cryptography and Network Security</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>537</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>379.4KB</td>

              </tr>
                            <tr>
                <td>391</td>
                <td><a href="download.php?table=notes&id=462&file=2017/notes/WC - UNIT 12017-09-17 14:09:17.pdf">Unit 1 Book Notes</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE, IT, ECE</td>
                <td>347</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16MB</td>

              </tr>
                            <tr>
                <td>392</td>
                <td><a href="download.php?table=notes&id=453&file=CS UNIT 3 and 459360cd41f7ae4.12372937.pdf">Unit 3 and 4</a></td>
                <td>Control Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>708</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>64.2MB</td>

              </tr>
                            <tr>
                <td>393</td>
                <td><a href="download.php?table=notes&id=452&file=CS UNIT 1 and 259360b9a263ed6.76158598.pdf">UNIT 1 and 2</a></td>
                <td>Control Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>714</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>55MB</td>

              </tr>
                            <tr>
                <td>394</td>
                <td><a href="download.php?table=notes&id=451&file=Control Systems Engineering_I5936091727e190.09848153.pdf">MATLAB Programs For Every CS Program </a></td>
                <td>Control Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>358</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>395</td>
                <td><a href="download.php?table=notes&id=450&file=Control Systems Engineering_I593604c9626c34.12325407.pdf">MATLAB Programs For Every CS Program </a></td>
                <td>Control Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>501</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>396</td>
                <td><a href="download.php?table=notes&id=449&file=138143450-Automatic-Control-System-S-Hasan-Saeed5933ecd6c97a01.05149449.pdf">Hasan Saeed</a></td>
                <td>Control Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>558</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>46.9MB</td>

              </tr>
                            <tr>
                <td>397</td>
                <td><a href="download.php?table=notes&id=445&file=8085592ebb35ac2d65.14639369.pdf">8085</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>628</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>398</td>
                <td><a href="download.php?table=notes&id=444&file=8085592ebb35ac2d65.14639369.pdf">8085</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>631</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>399</td>
                <td><a href="download.php?table=notes&id=443&file=8085592ebb35ac2d65.14639369.pdf">8085</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>489</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.6MB</td>

              </tr>
                            <tr>
                <td>400</td>
                <td><a href="download.php?table=notes&id=442&file=cao 4th unit592ebaa443fa53.89409729.pdf">UNIT 4 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>493</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>36.8MB</td>

              </tr>
                            <tr>
                <td>401</td>
                <td><a href="download.php?table=notes&id=441&file=cao 4th unit592ebaa443fa53.89409729.pdf">UNIT 4 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>533</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>36.8MB</td>

              </tr>
                            <tr>
                <td>402</td>
                <td><a href="download.php?table=notes&id=440&file=cao 4th unit592ebaa443fa53.89409729.pdf">UNIT 4 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>544</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>36.8MB</td>

              </tr>
                            <tr>
                <td>403</td>
                <td><a href="download.php?table=notes&id=439&file=cao 3rd unit592eba0ee9d732.70551750.pdf">UNIT 3 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>660</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.9MB</td>

              </tr>
                            <tr>
                <td>404</td>
                <td><a href="download.php?table=notes&id=438&file=cao 3rd unit592eba0ee9d732.70551750.pdf">UNIT 3 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>641</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.9MB</td>

              </tr>
                            <tr>
                <td>405</td>
                <td><a href="download.php?table=notes&id=437&file=cao 3rd unit592eba0ee9d732.70551750.pdf">UNIT 3 New Syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>436</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.9MB</td>

              </tr>
                            <tr>
                <td>406</td>
                <td><a href="download.php?table=notes&id=436&file=CAO-1st unit592eb8c923d482.53096627.pdf">UNIT 1 New syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>563</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4MB</td>

              </tr>
                            <tr>
                <td>407</td>
                <td><a href="download.php?table=notes&id=435&file=CAO-1st unit592eb8c923d482.53096627.pdf">UNIT 1 New syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>534</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4MB</td>

              </tr>
                            <tr>
                <td>408</td>
                <td><a href="download.php?table=notes&id=434&file=CAO-1st unit592eb8c923d482.53096627.pdf">UNIT 1 New syllabus</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>464</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4MB</td>

              </tr>
                            <tr>
                <td>409</td>
                <td><a href="download.php?table=notes&id=433&file=INTERFACING with 8086592b4e5b730973.91672921.pdf">Interfacing with 8086 Diagrams</a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>624</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>410</td>
                <td><a href="download.php?table=notes&id=432&file=INTERFACING with 8086592b4e5b730973.91672921.pdf">Interfacing with 8086 Diagrams</a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>563</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>411</td>
                <td><a href="download.php?table=notes&id=431&file=INTERFACING with 8086592b4e5b730973.91672921.pdf">Interfacing with 8086 Diagrams</a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>563</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>412</td>
                <td><a href="download.php?table=notes&id=430&file=INTERFACING with 8086592b4e5b730973.91672921.pdf">Interfacing with 8086 Diagrams</a></td>
                <td>Microprocessor and Microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>473</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.4MB</td>

              </tr>
                            <tr>
                <td>413</td>
                <td><a href="download.php?table=notes&id=429&file=ASD notes592adf714c6749.74598738.pdf">seismic and tank </a></td>
                <td>Advance Structural Design </td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>399</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.6MB</td>

              </tr>
                            <tr>
                <td>414</td>
                <td><a href="download.php?table=notes&id=423&file=Computer notes59293b0e562403.56509705.pdf">C Language Complete</a></td>
                <td>Introduction to Programming</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1942</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.3MB</td>

              </tr>
                            <tr>
                <td>415</td>
                <td><a href="download.php?table=notes&id=417&file=EVS Complete5925cec5b8e578.94624355.pdf">Complete</a></td>
                <td>Environmental Studies</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>3127</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>416</td>
                <td><a href="download.php?table=notes&id=416&file=New Doc 2017-04-15 (1)592439f6343884.66084953.pdf">UNIT 4 B</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>341</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6MB</td>

              </tr>
                            <tr>
                <td>417</td>
                <td><a href="download.php?table=notes&id=415&file=New Doc 2017-04-15 (1)592439f6343884.66084953.pdf">UNIT 4 B</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>553</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6MB</td>

              </tr>
                            <tr>
                <td>418</td>
                <td><a href="download.php?table=notes&id=414&file=UNIT 4 A592439810e9d42.89585629.pdf">UNIT 4 A</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>528</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.8MB</td>

              </tr>
                            <tr>
                <td>419</td>
                <td><a href="download.php?table=notes&id=413&file=UNIT 4 A592439810e9d42.89585629.pdf">UNIT 4 A</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>397</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.8MB</td>

              </tr>
                            <tr>
                <td>420</td>
                <td><a href="download.php?table=notes&id=412&file=CMOS UNIT 3 (2)592438e04274e1.02766313.pdf">CMOS B </a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>538</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.1MB</td>

              </tr>
                            <tr>
                <td>421</td>
                <td><a href="download.php?table=notes&id=411&file=CMOS UNIT 3 (2)592438e04274e1.02766313.pdf">CMOS B </a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>417</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.1MB</td>

              </tr>
                            <tr>
                <td>422</td>
                <td><a href="download.php?table=notes&id=410&file=CMOS UNIT 3592438aa0b6276.47562532.pdf">CMOS A </a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>384</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>423</td>
                <td><a href="download.php?table=notes&id=409&file=CMOS UNIT 3592438aa0b6276.47562532.pdf">CMOS A </a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>555</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>424</td>
                <td><a href="download.php?table=notes&id=408&file=UNIT 3 B5924387889da12.67633185.pdf">unit 3 B</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>359</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>425</td>
                <td><a href="download.php?table=notes&id=407&file=UNIT 3 B5924387889da12.67633185.pdf">unit 3 B</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>417</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>426</td>
                <td><a href="download.php?table=notes&id=406&file=UNIT 3 A59243855ac5822.28678602.pdf">Unit 3 A</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>358</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.6MB</td>

              </tr>
                            <tr>
                <td>427</td>
                <td><a href="download.php?table=notes&id=405&file=UNIT 3 A59243855ac5822.28678602.pdf">Unit 3 A</a></td>
                <td>VLSI Design</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>442</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.6MB</td>

              </tr>
                            <tr>
                <td>428</td>
                <td><a href="download.php?table=notes&id=404&file=Neural Network5923e667b1abc9.06978987.pdf">Neural Network</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>488</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>429</td>
                <td><a href="download.php?table=notes&id=403&file=Neural Network5923e667b1abc9.06978987.pdf">Neural Network</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>576</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.5MB</td>

              </tr>
                            <tr>
                <td>430</td>
                <td><a href="download.php?table=notes&id=402&file=Genetic-Algorithms5923e5f42d0e97.76883620.pdf">Genetic Algorithms</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>488</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.1MB</td>

              </tr>
                            <tr>
                <td>431</td>
                <td><a href="download.php?table=notes&id=401&file=Genetic-Algorithms5923e5f42d0e97.76883620.pdf">Genetic Algorithms</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>449</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.1MB</td>

              </tr>
                            <tr>
                <td>432</td>
                <td><a href="download.php?table=notes&id=400&file=expert system592356d3bc95b5.08498110.pdf">Expert Systems</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>360</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>507.7KB</td>

              </tr>
                            <tr>
                <td>433</td>
                <td><a href="download.php?table=notes&id=399&file=expert system592356d3bc95b5.08498110.pdf">Expert Systems</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>381</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>507.7KB</td>

              </tr>
                            <tr>
                <td>434</td>
                <td><a href="download.php?table=notes&id=397&file=dcn unit 4_20170519133918591ef8c79655b7.65611129.pdf">unit 4 Transport App layer </a></td>
                <td>Data Communication and Networks</td>
                <!--<td></td>-->
                <td>IT, ECE, MAE</td>
                <td>606</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>22.2MB</td>

              </tr>
                            <tr>
                <td>435</td>
                <td><a href="download.php?table=notes&id=395&file=TheoryOfComputation591dc0b6f20233.38084680.pdf">Whole Theory </a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>799</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>436</td>
                <td><a href="download.php?table=notes&id=394&file=TheoryOfComputation591dc0b6f20233.38084680.pdf">Whole Theory </a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>562</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>437</td>
                <td><a href="download.php?table=notes&id=393&file=blg252e_complete591dbda0f41922.09744679.pdf">Theory Slides</a></td>
                <td>Object Oriented Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>614</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.1MB</td>

              </tr>
                            <tr>
                <td>438</td>
                <td><a href="download.php?table=notes&id=392&file=blg252e_complete591dbda0f41922.09744679.pdf">Theory Slides</a></td>
                <td>Object Oriented Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>689</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.1MB</td>

              </tr>
                            <tr>
                <td>439</td>
                <td><a href="download.php?table=notes&id=391&file=Cpp_by_Sourav_Kumar_Giri591dbd588f96f5.32590106.pdf">Important Programs </a></td>
                <td>Object Oriented Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>551</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>853.5KB</td>

              </tr>
                            <tr>
                <td>440</td>
                <td><a href="download.php?table=notes&id=390&file=Cpp_by_Sourav_Kumar_Giri591dbd588f96f5.32590106.pdf">Important Programs </a></td>
                <td>Object Oriented Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>561</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>853.5KB</td>

              </tr>
                            <tr>
                <td>441</td>
                <td><a href="download.php?table=notes&id=389&file=adhoc3a591c9eeecd11d1.88717331.pdf">singh singh UNIT 3 4</a></td>
                <td>Ad hoc and Sensor Networks</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>503</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20.8MB</td>

              </tr>
                            <tr>
                <td>442</td>
                <td><a href="download.php?table=notes&id=388&file=adhoc2a591c9d6b201c79.23090663.pdf">singh singh UNIT 2</a></td>
                <td>Ad hoc and Sensor Networks</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>535</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.2MB</td>

              </tr>
                            <tr>
                <td>443</td>
                <td><a href="download.php?table=notes&id=387&file=adhoc1591c9b124ca2f6.59323814.pdf">singh singh UNIT 1 </a></td>
                <td>Ad hoc and Sensor Networks</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>715</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>42.8MB</td>

              </tr>
                            <tr>
                <td>444</td>
                <td><a href="download.php?table=notes&id=386&file=Compiler Design-Important5919d192132260.55116776.pdf">Important Notes</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>473</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.8MB</td>

              </tr>
                            <tr>
                <td>445</td>
                <td><a href="download.php?table=notes&id=385&file=Compiler Design-Important5919d192132260.55116776.pdf">Important Notes</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>662</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.8MB</td>

              </tr>
                            <tr>
                <td>446</td>
                <td><a href="download.php?table=notes&id=379&file=Physics Unit 4 5919c6cb2f7e82.11018641.pdf">Unit 4</a></td>
                <td>Applied Physics II</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1941</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.1MB</td>

              </tr>
                            <tr>
                <td>447</td>
                <td><a href="download.php?table=notes&id=377&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>386</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>448</td>
                <td><a href="download.php?table=notes&id=376&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>488</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>449</td>
                <td><a href="download.php?table=notes&id=375&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>418</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>450</td>
                <td><a href="download.php?table=notes&id=374&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>380</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>451</td>
                <td><a href="download.php?table=notes&id=373&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>515</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>452</td>
                <td><a href="download.php?table=notes&id=372&file=hv unit 3591049cf121a91.89472748.pdf">bhavya unit 3</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>544</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.4MB</td>

              </tr>
                            <tr>
                <td>453</td>
                <td><a href="download.php?table=notes&id=371&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>536</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>454</td>
                <td><a href="download.php?table=notes&id=370&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>432</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>455</td>
                <td><a href="download.php?table=notes&id=369&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>321</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>456</td>
                <td><a href="download.php?table=notes&id=368&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>453</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>457</td>
                <td><a href="download.php?table=notes&id=367&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>458</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>458</td>
                <td><a href="download.php?table=notes&id=366&file=hv unit 4591047016f4dd7.04427497.pdf">bhavya unit 4</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>523</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.3MB</td>

              </tr>
                            <tr>
                <td>459</td>
                <td><a href="download.php?table=notes&id=359&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>419</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>460</td>
                <td><a href="download.php?table=notes&id=358&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>MAE</td>
                <td>443</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>461</td>
                <td><a href="download.php?table=notes&id=357&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>435</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>462</td>
                <td><a href="download.php?table=notes&id=356&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>480</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>463</td>
                <td><a href="download.php?table=notes&id=355&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>453</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>464</td>
                <td><a href="download.php?table=notes&id=354&file=hv unit 1 - 259104434e7ae77.65232027.pdf">bhavya unit 1 2</a></td>
                <td>Human Values and Professional Ethics II</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>531</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>29.6MB</td>

              </tr>
                            <tr>
                <td>465</td>
                <td><a href="download.php?table=notes&id=353&file=dsp5905baa6d7a238.27917891.pdf">Unit 3 4 </a></td>
                <td>Digital Signal Processing</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>406</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>56.2MB</td>

              </tr>
                            <tr>
                <td>466</td>
                <td><a href="download.php?table=notes&id=352&file=dsp5905baa6d7a238.27917891.pdf">Unit 3 4 </a></td>
                <td>Digital Signal Processing</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>583</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>56.2MB</td>

              </tr>
                            <tr>
                <td>467</td>
                <td><a href="download.php?table=notes&id=351&file=dsp unit 1-25905b5ba0ad781.29214164.pdf">Unit 1 2 </a></td>
                <td>Digital Signal Processing</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>454</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>468</td>
                <td><a href="download.php?table=notes&id=350&file=dsp unit 1-25905b5ba0ad781.29214164.pdf">Unit 1 2 </a></td>
                <td>Digital Signal Processing</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>480</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.4MB</td>

              </tr>
                            <tr>
                <td>469</td>
                <td><a href="download.php?table=notes&id=349&file=itc 2 session590414aa918fe8.81787729.pdf">Second sessional</a></td>
                <td>Information Theory and Coding</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>387</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.1MB</td>

              </tr>
                            <tr>
                <td>470</td>
                <td><a href="download.php?table=notes&id=348&file=WholeDbms58ff8d1893ee69.85298461.pdf">Whole Syllabus</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>659</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>471</td>
                <td><a href="download.php?table=notes&id=347&file=WholeDbms58ff8d1893ee69.85298461.pdf">Whole Syllabus</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>688</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>472</td>
                <td><a href="download.php?table=notes&id=346&file=ASD Retaining Wall58ff8c808b3c80.38478829.pdf">ASD Retaining Wall</a></td>
                <td>Advance Structural Design </td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>322</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.7MB</td>

              </tr>
                            <tr>
                <td>473</td>
                <td><a href="download.php?table=notes&id=345&file=ASD intze tank58ff8bf67c96e1.16501939.pdf">Intze tank</a></td>
                <td>Advance Structural Design </td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>318</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4.9MB</td>

              </tr>
                            <tr>
                <td>474</td>
                <td><a href="download.php?table=notes&id=344&file=Concept of Geo-informatics58ff891638b958.57989491.pdf">Concept of Geo informatics </a></td>
                <td>Applications of Remote Sensing and GIS</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>363</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.8MB</td>

              </tr>
                            <tr>
                <td>475</td>
                <td><a href="download.php?table=notes&id=343&file=Transportation Engineering -I58ff87a15d6c26.77963361.pdf">Transportation Engineering I unit 3</a></td>
                <td>Transportation Engineering 1</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>424</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.8MB</td>

              </tr>
                            <tr>
                <td>476</td>
                <td><a href="download.php?table=notes&id=342&file=Wastewater Engineering and Reuse58ff83f4c895f8.34088449.pdf">Wastewater Engineering and Reuse</a></td>
                <td>Wastewater Engineering and Reuse</td>
                <!--<td></td>-->
                <td>CIVIL</td>
                <td>478</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.7MB</td>

              </tr>
                            <tr>
                <td>477</td>
                <td><a href="download.php?table=notes&id=341&file=Unit 2 Math58fe481aca1485.80435445.pdf">UNIT 2</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>548</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>33.7MB</td>

              </tr>
                            <tr>
                <td>478</td>
                <td><a href="download.php?table=notes&id=340&file=Unit 2 Math58fe481aca1485.80435445.pdf">UNIT 2</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>617</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>33.7MB</td>

              </tr>
                            <tr>
                <td>479</td>
                <td><a href="download.php?table=notes&id=339&file=COMPUTER SYSTEM ARCHITECTURE - M58fe41489ef596.78184458.pdf">Computer Organisation And Architecture</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>515</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.1MB</td>

              </tr>
                            <tr>
                <td>480</td>
                <td><a href="download.php?table=notes&id=338&file=COMPUTER SYSTEM ARCHITECTURE - M58fe41489ef596.78184458.pdf">Computer Organisation And Architecture</a></td>
                <td>Computer Organization and Architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>481</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.1MB</td>

              </tr>
                            <tr>
                <td>481</td>
                <td><a href="download.php?table=notes&id=337&file=AI (Unit 4)58fa35d29876e8.81865414.pdf">Unit 4</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>538</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.5MB</td>

              </tr>
                            <tr>
                <td>482</td>
                <td><a href="download.php?table=notes&id=336&file=AI (Unit 4)58fa35d29876e8.81865414.pdf">Unit 4</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>535</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.5MB</td>

              </tr>
                            <tr>
                <td>483</td>
                <td><a href="download.php?table=notes&id=330&file=Communication Skills (Unit 4)58fa16698c4240.10657442.pdf">Unit 4</a></td>
                <td>Communication Skills</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1300</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.6MB</td>

              </tr>
                            <tr>
                <td>484</td>
                <td><a href="download.php?table=notes&id=324&file= Mechanics(unit 3)58f9f08d4c7ea6.49781934.pdf">Unit 3</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1890</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.3MB</td>

              </tr>
                            <tr>
                <td>485</td>
                <td><a href="download.php?table=notes&id=318&file=Mechanics (unit 4)58f9f0277db840.35276565.pdf">Unit 4</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1610</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.7MB</td>

              </tr>
                            <tr>
                <td>486</td>
                <td><a href="download.php?table=notes&id=312&file=Mechanics (unit 2)58f9efd5acce92.96625581.pdf">Unit 2</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1999</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6.3MB</td>

              </tr>
                            <tr>
                <td>487</td>
                <td><a href="download.php?table=notes&id=306&file= mechanics(unit 3) Theory (2nd sem)(1st year)58f9eeebad3743.30811005.pdf">Unit 1</a></td>
                <td>Engineering Mechanics</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>2914</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.2MB</td>

              </tr>
                            <tr>
                <td>488</td>
                <td><a href="download.php?table=notes&id=305&file=WE UNIT 3 and 458f8d8ee5f04a5.84211924.pdf">WE UNIT 3 4 Option 2 </a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>606</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.5MB</td>

              </tr>
                            <tr>
                <td>489</td>
                <td><a href="download.php?table=notes&id=304&file=WE UNIT 3 and 458f8d8ee5f04a5.84211924.pdf">WE UNIT 3 4 Option 2 </a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>487</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.5MB</td>

              </tr>
                            <tr>
                <td>490</td>
                <td><a href="download.php?table=notes&id=303&file=WE UNIT 3,458f8d062f20ac9.05596649.pdf">UNIT 3 4</a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>477</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>23.6MB</td>

              </tr>
                            <tr>
                <td>491</td>
                <td><a href="download.php?table=notes&id=302&file=WE UNIT 3,458f8d062f20ac9.05596649.pdf">UNIT 3 4</a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>385</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>23.6MB</td>

              </tr>
                            <tr>
                <td>492</td>
                <td><a href="download.php?table=notes&id=301&file=Term2DBMS58f8a0f7b81643.55940331.pdf">Unit 3 and 4</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>497</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>493</td>
                <td><a href="download.php?table=notes&id=300&file=Term2DBMS58f8a0f7b81643.55940331.pdf">Unit 3 and 4</a></td>
                <td>Database Management Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>537</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>494</td>
                <td><a href="download.php?table=notes&id=299&file=AI NOTES- UNIT 3-458f63217a7bf75.91161400.pdf">UNIT 3 4</a></td>
                <td>Artificial Intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>726</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>53.4MB</td>

              </tr>
                            <tr>
                <td>495</td>
                <td><a href="download.php?table=notes&id=298&file=OS UNIT 458f63042ba0d14.55823191.pdf">UNIT 4</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>607</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.2MB</td>

              </tr>
                            <tr>
                <td>496</td>
                <td><a href="download.php?table=notes&id=297&file=OS UNIT 358f62fadc2e981.37394063.pdf">UNIT 3</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>494</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.6MB</td>

              </tr>
                            <tr>
                <td>497</td>
                <td><a href="download.php?table=notes&id=295&file=New Doc 2017-04-17-158f4b440c97360.82789767.pdf">Unit 3</a></td>
                <td>Data Communication and Networks</td>
                <!--<td></td>-->
                <td>IT, ECE, MAE</td>
                <td>638</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>498</td>
                <td><a href="download.php?table=notes&id=293&file=DOC-20170417-WA000058f4b3358d0c09.08248836.pdf">FOROUZAN book </a></td>
                <td>Data Communication and Networks</td>
                <!--<td></td>-->
                <td>IT, ECE, MAE</td>
                <td>633</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.8MB</td>

              </tr>
                            <tr>
                <td>499</td>
                <td><a href="download.php?table=notes&id=292&file=Untitled58f4a52436fce7.39685903.pdf">Toc Unit 3 and Unit 4</a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>638</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.3MB</td>

              </tr>
                            <tr>
                <td>500</td>
                <td><a href="download.php?table=notes&id=291&file=Untitled58f4a52436fce7.39685903.pdf">Toc Unit 3 and Unit 4</a></td>
                <td>Theory of Computation</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>616</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.3MB</td>

              </tr>
                            <tr>
                <td>501</td>
                <td><a href="download.php?table=notes&id=290&file=unit 3 part two_2017041612563258f32a45df02b4.00668442.pdf">Unit 3 Part 2</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>424</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.3MB</td>

              </tr>
                            <tr>
                <td>502</td>
                <td><a href="download.php?table=notes&id=289&file=unit 3 part two_2017041612563258f32a45df02b4.00668442.pdf">Unit 3 Part 2</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>579</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.3MB</td>

              </tr>
                            <tr>
                <td>503</td>
                <td><a href="download.php?table=notes&id=288&file=unit 3 cd_2017041609185858f329c36a30f6.24004886.pdf">Unit 3 Part 1</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>450</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6MB</td>

              </tr>
                            <tr>
                <td>504</td>
                <td><a href="download.php?table=notes&id=287&file=unit 3 cd_2017041609185858f329c36a30f6.24004886.pdf">Unit 3 Part 1</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>437</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>6MB</td>

              </tr>
                            <tr>
                <td>505</td>
                <td><a href="download.php?table=notes&id=286&file=unit 2 of cd_2017041609102258f324a37914c0.01074025.pdf">Unit 2</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>393</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>506</td>
                <td><a href="download.php?table=notes&id=285&file=unit 2 of cd_2017041609102258f324a37914c0.01074025.pdf">Unit 2</a></td>
                <td>Compiler Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>455</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>507</td>
                <td><a href="download.php?table=notes&id=284&file=New Doc 2017-04-1258f1d60c43ee66.87647919.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>577</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>508</td>
                <td><a href="download.php?table=notes&id=283&file=New Doc 2017-04-1258f1d60c43ee66.87647919.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>547</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>509</td>
                <td><a href="download.php?table=notes&id=282&file=New Doc 2017-04-1258f1d60c43ee66.87647919.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>494</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>510</td>
                <td><a href="download.php?table=notes&id=281&file=New Doc 2017-04-1258f1d4fac65460.42846966.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>EEE</td>
                <td>370</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>511</td>
                <td><a href="download.php?table=notes&id=280&file=New Doc 2017-04-1258f1d4fac65460.42846966.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>402</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>512</td>
                <td><a href="download.php?table=notes&id=279&file=New Doc 2017-04-1258f1d4fac65460.42846966.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>488</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>513</td>
                <td><a href="download.php?table=notes&id=278&file=New Doc 2017-04-1258f1d4fac65460.42846966.pdf">Unit 3 Curve fitting</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>372</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>514</td>
                <td><a href="download.php?table=notes&id=277&file=at r u doing online58f1cfec381bd7.55651330.pdf">Unit 4 Compressed File</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>378</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20MB</td>

              </tr>
                            <tr>
                <td>515</td>
                <td><a href="download.php?table=notes&id=276&file=at r u doing online58f1cfec381bd7.55651330.pdf">Unit 4 Compressed File</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>420</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20MB</td>

              </tr>
                            <tr>
                <td>516</td>
                <td><a href="download.php?table=notes&id=275&file=Unit 3 (1)58f1cf84636e30.39589425.pdf">Unit 3 Compressed File</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>500</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.1MB</td>

              </tr>
                            <tr>
                <td>517</td>
                <td><a href="download.php?table=notes&id=274&file=Unit 3 (1)58f1cf84636e30.39589425.pdf">Unit 3 Compressed File</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>430</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.1MB</td>

              </tr>
                            <tr>
                <td>518</td>
                <td><a href="download.php?table=notes&id=273&file=Unit 358f1cba5bfad22.12604588.pdf">Unit 3</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>391</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>519</td>
                <td><a href="download.php?table=notes&id=272&file=Unit 358f1cba5bfad22.12604588.pdf">Unit 3</a></td>
                <td>Applied Mathematics IV</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>527</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26MB</td>

              </tr>
                            <tr>
                <td>520</td>
                <td><a href="download.php?table=notes&id=271&file=mobile_computing558ad9eccb3eda6.49069223.pdf">Mobile Computing 5</a></td>
                <td>Mobile Computing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>596</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>43.3MB</td>

              </tr>
                            <tr>
                <td>521</td>
                <td><a href="download.php?table=notes&id=270&file=mobile_computing458ad9b0381d0f0.35570161.pdf">Mobile Computing 4</a></td>
                <td>Mobile Computing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>587</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>46.3MB</td>

              </tr>
                            <tr>
                <td>522</td>
                <td><a href="download.php?table=notes&id=269&file=mobile_computing358ad973ebd77c7.64331060.pdf">Mobile Computing 3</a></td>
                <td>Mobile Computing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>692</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>33.9MB</td>

              </tr>
                            <tr>
                <td>523</td>
                <td><a href="download.php?table=notes&id=268&file=mobile_computing258ad943a4b71b7.27694797.pdf">Mobile Computing 2</a></td>
                <td>Mobile Computing</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>585</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>30.3MB</td>

              </tr>
                            <tr>
                <td>524</td>
                <td><a href="download.php?table=notes&id=267&file=mobile_computing158ad8fd7662644.60109806.pdf">Mobile Computing 1</a></td>
                <td>Mobile Computing </td>
                <!--<td></td>-->
                <td>IT</td>
                <td>790</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>46.1MB</td>

              </tr>
                            <tr>
                <td>525</td>
                <td><a href="download.php?table=notes&id=266&file=WE NOTES DTD58a069b8dad426.25218538.pdf">DTD</a></td>
                <td>Web Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>404</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.8MB</td>

              </tr>
                            <tr>
                <td>526</td>
                <td><a href="download.php?table=notes&id=263&file=OS Unit 1- Part A587e530f3b43c7.86339802.pdf">Unit 1 Part A</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>512</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.1MB</td>

              </tr>
                            <tr>
                <td>527</td>
                <td><a href="download.php?table=notes&id=262&file=OS Unit 1- Part A587e530f3b43c7.86339802.pdf">Unit 1 Part A</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>665</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.1MB</td>

              </tr>
                            <tr>
                <td>528</td>
                <td><a href="download.php?table=notes&id=261&file=STLD UNIT3 ONWARDS585f52a0923b97.17100600.pdf">UNIT 3 Onwards</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>512</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.4MB</td>

              </tr>
                            <tr>
                <td>529</td>
                <td><a href="download.php?table=notes&id=260&file=STLD UNIT3 ONWARDS585f52a0923b97.17100600.pdf">UNIT 3 Onwards</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>680</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.4MB</td>

              </tr>
                            <tr>
                <td>530</td>
                <td><a href="download.php?table=notes&id=259&file=ASM STLD585f521ea302c1.26258430.pdf">ASM</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>501</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.4MB</td>

              </tr>
                            <tr>
                <td>531</td>
                <td><a href="download.php?table=notes&id=258&file=ASM STLD585f521ea302c1.26258430.pdf">ASM</a></td>
                <td>Switching Theory and Logic Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>492</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.4MB</td>

              </tr>
                            <tr>
                <td>532</td>
                <td><a href="download.php?table=notes&id=257&file=c and s notws (1)585f51e02939e8.43618874.pdf">Notes</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>611</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>533</td>
                <td><a href="download.php?table=notes&id=256&file=c and s notws (1)585f51e02939e8.43618874.pdf">Notes</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>549</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>13.2MB</td>

              </tr>
                            <tr>
                <td>534</td>
                <td><a href="download.php?table=notes&id=255&file=Filters585f51a4614fc7.57433542.pdf">Filters</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>600</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>535</td>
                <td><a href="download.php?table=notes&id=254&file=Filters585f51a4614fc7.57433542.pdf">Filters</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>554</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>536</td>
                <td><a href="download.php?table=notes&id=251&file=Filters585f50a67babc1.02706301.pdf">Filters</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>458</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>537</td>
                <td><a href="download.php?table=notes&id=250&file=Filters585f50a67babc1.02706301.pdf">Filters</a></td>
                <td>Circuits and Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>418</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.2MB</td>

              </tr>
                            <tr>
                <td>538</td>
                <td><a href="download.php?table=notes&id=247&file=Collection Interfaces585be8b8e0b261.53651799.pdf">Unit 4 Collection Interfaces</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>379</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>539</td>
                <td><a href="download.php?table=notes&id=246&file=Collection Interfaces585be8b8e0b261.53651799.pdf">Unit 4 Collection Interfaces</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>518</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>540</td>
                <td><a href="download.php?table=notes&id=245&file=Java Native Interfaces (JNI)585b84ce723a70.88236256.pdf">Unit 4 Java Native Interfaces JNI </a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>420</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>541</td>
                <td><a href="download.php?table=notes&id=244&file=Java Native Interfaces (JNI)585b84ce723a70.88236256.pdf">Unit 4 Java Native Interfaces JNI </a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>408</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.7MB</td>

              </tr>
                            <tr>
                <td>542</td>
                <td><a href="download.php?table=notes&id=243&file=JDBC585b846d052fb3.39055415.pdf">Unit 4 JDBC</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>430</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>543</td>
                <td><a href="download.php?table=notes&id=242&file=JDBC585b846d052fb3.39055415.pdf">Unit 4 JDBC</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>496</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.4MB</td>

              </tr>
                            <tr>
                <td>544</td>
                <td><a href="download.php?table=notes&id=241&file=unit-4_java58593a0dc89457.89577218.docx">File Handling Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>566</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20KB</td>

              </tr>
                            <tr>
                <td>545</td>
                <td><a href="download.php?table=notes&id=240&file=unit-4_java58593a0dc89457.89577218.docx">File Handling Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>482</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20KB</td>

              </tr>
                            <tr>
                <td>546</td>
                <td><a href="download.php?table=notes&id=239&file=java-b585937d9384755.24956206.docx">Tokenizers Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>388</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>86KB</td>

              </tr>
                            <tr>
                <td>547</td>
                <td><a href="download.php?table=notes&id=238&file=java-b585937d9384755.24956206.docx">Tokenizers Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>478</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>86KB</td>

              </tr>
                            <tr>
                <td>548</td>
                <td><a href="download.php?table=notes&id=237&file=awt58593703189b20.89314860.pdf">AWT Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>468</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>679.2KB</td>

              </tr>
                            <tr>
                <td>549</td>
                <td><a href="download.php?table=notes&id=236&file=awt58593703189b20.89314860.pdf">AWT Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>455</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>679.2KB</td>

              </tr>
                            <tr>
                <td>550</td>
                <td><a href="download.php?table=notes&id=235&file=multithreading585936b1f15666.71497038.docx">Multithreading Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>411</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.7KB</td>

              </tr>
                            <tr>
                <td>551</td>
                <td><a href="download.php?table=notes&id=234&file=multithreading585936b1f15666.71497038.docx">Multithreading Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>498</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16.7KB</td>

              </tr>
                            <tr>
                <td>552</td>
                <td><a href="download.php?table=notes&id=233&file=Sockets58593616775dc2.23895868.docx">Sockets Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>507</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>259KB</td>

              </tr>
                            <tr>
                <td>553</td>
                <td><a href="download.php?table=notes&id=232&file=Sockets58593616775dc2.23895868.docx">Sockets Java</a></td>
                <td>Java Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>398</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>259KB</td>

              </tr>
                            <tr>
                <td>554</td>
                <td><a href="download.php?table=notes&id=229&file=IM UNIT 4 COMPLETE5857af3a8b5361.35854206.pdf">IM Unit 4 Complete</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>758</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>555</td>
                <td><a href="download.php?table=notes&id=228&file=IM UNIT 4 COMPLETE5857af3a8b5361.35854206.pdf">IM Unit 4 Complete</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>ECE</td>
                <td>442</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>556</td>
                <td><a href="download.php?table=notes&id=227&file=IM UNIT 4 COMPLETE5857af3a8b5361.35854206.pdf">IM Unit 4 Complete</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>420</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>557</td>
                <td><a href="download.php?table=notes&id=226&file=IM UNIT 4 COMPLETE5857af3a8b5361.35854206.pdf">IM Unit 4 Complete</a></td>
                <td>Industrial Management</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>522</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>11.1MB</td>

              </tr>
                            <tr>
                <td>558</td>
                <td><a href="download.php?table=notes&id=225&file=CS UNIT 15852f3c8ef30c9.76711922.pdf">UNIT 1 COMPLETE FOR ENDSEM</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT,EEE</td>
                <td>904</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.3MB</td>

              </tr>
                            <tr>
                <td>559</td>
                <td><a href="download.php?table=notes&id=217&file=part 1 cs notes584128dae26a23.88119159.pdf">Unit 2 Part 1 </a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT,EEE</td>
                <td>828</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>19.8MB</td>

              </tr>
                            <tr>
                <td>560</td>
                <td><a href="download.php?table=notes&id=216&file=CS UNIT 1584121ebda49b1.76834596.pdf">Unit 1</a></td>
                <td>Communication Systems</td>
                <!--<td></td>-->
                <td>IT,EEE</td>
                <td>943</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10.8MB</td>

              </tr>
                            <tr>
                <td>561</td>
                <td><a href="download.php?table=notes&id=164&file=ADA_UNIT-1583490dd4661a8.99578588.pdf">Unit 1</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>671</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>32.8MB</td>

              </tr>
                            <tr>
                <td>562</td>
                <td><a href="download.php?table=notes&id=162&file=ADA_UNIT_25834856f5a9478.02346554.pdf">Unit 2</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>430</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10MB</td>

              </tr>
                            <tr>
                <td>563</td>
                <td><a href="download.php?table=notes&id=161&file=ADA_UNIT_358347f4822fb29.85667371.pdf">Unit 3</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>465</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20.3MB</td>

              </tr>
                            <tr>
                <td>564</td>
                <td><a href="download.php?table=notes&id=160&file=ADA_UNIT_458347c8232af44.82019088.pdf">Unit 4</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>579</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9MB</td>

              </tr>
                            <tr>
                <td>565</td>
                <td><a href="download.php?table=notes&id=159&file=wc2_15830a81dedf531.09319810.pdf">Wireless Channels and Diversity</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE,ECE</td>
                <td>558</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.5MB</td>

              </tr>
                            <tr>
                <td>566</td>
                <td><a href="download.php?table=notes&id=158&file=wc1582aed454b38e3.09422763.pdf">Intro to Wireless PCS </a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>CSE,ECE</td>
                <td>585</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>61MB</td>

              </tr>
                            <tr>
                <td>567</td>
                <td><a href="download.php?table=notes&id=157&file=CS UNIT 4582326ff869be4.47934086.pdf">CS Unit 4</a></td>
                <td>Communication systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>506</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.2MB</td>

              </tr>
                            <tr>
                <td>568</td>
                <td><a href="download.php?table=notes&id=156&file=os notes unit 35821b8193a1322.00122970.pdf">OS Notes Unit 3</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>385</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.3MB</td>

              </tr>
                            <tr>
                <td>569</td>
                <td><a href="download.php?table=notes&id=155&file=Random Variables58172a6dec65b5.90204577.pdf">Random Variables Unit 1</a></td>
                <td>Communication systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>715</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.9MB</td>

              </tr>
                            <tr>
                <td>570</td>
                <td><a href="download.php?table=notes&id=154&file=software_engineering5814cd5e5e4e85.13430981.pdf">Unit 1 4 important topics</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>458</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.7MB</td>

              </tr>
                            <tr>
                <td>571</td>
                <td><a href="download.php?table=notes&id=153&file=chapter 6 Software Metrics5814790e04ffc8.72403601.pdf">Unit 1 part Software metrices</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>566</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>908.5KB</td>

              </tr>
                            <tr>
                <td>572</td>
                <td><a href="download.php?table=notes&id=152&file=Chapter 9 Software Maintenance5814789d4af4b5.40580300.pdf">Unit 4 part 2</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>452</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>545.6KB</td>

              </tr>
                            <tr>
                <td>573</td>
                <td><a href="download.php?table=notes&id=151&file=Chapter 8 Software Testing581473ff7ad607.75964319.pdf">Unit 4 part 1</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>470</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2MB</td>

              </tr>
                            <tr>
                <td>574</td>
                <td><a href="download.php?table=notes&id=150&file=Chapter 5 Software Design5814734be7af90.34247804.pdf">Unit 3 Software Design</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>515</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>575</td>
                <td><a href="download.php?table=notes&id=149&file=Chapter 4 Software Project planning5814727bbeae16.02243432.pdf">Chapter 4 Software Project planning</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>373</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>576</td>
                <td><a href="download.php?table=notes&id=148&file=Chapter 2 Software Development Life Cycle Models58147202e3a106.94497741.pdf">Chapter 2 Software Life Cycle</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>422</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>611.2KB</td>

              </tr>
                            <tr>
                <td>577</td>
                <td><a href="download.php?table=notes&id=147&file=8085_is_details581462a2b0a9e0.20616929.pdf">8085 DETAILS</a></td>
                <td>Computer organization and architecture</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>421</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>280.1KB</td>

              </tr>
                            <tr>
                <td>578</td>
                <td><a href="download.php?table=notes&id=146&file=csp 10-145813b5cb0ca525.49160667.pdf">Chapter 10 14</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>428</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>30.6MB</td>

              </tr>
                            <tr>
                <td>579</td>
                <td><a href="download.php?table=notes&id=145&file=csp 7,8,95813b446895936.81318465.pdf">Chapter 7 8 9</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>376</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>37.9MB</td>

              </tr>
                            <tr>
                <td>580</td>
                <td><a href="download.php?table=notes&id=144&file=csp 4,5,65813b179d12748.07679026.pdf">Chapter 4 5 6</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>514</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.9MB</td>

              </tr>
                            <tr>
                <td>581</td>
                <td><a href="download.php?table=notes&id=143&file=csp 1,2,35813abe3c4d623.81002370.pdf">Chapter 1 2 3</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>446</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.9MB</td>

              </tr>
                            <tr>
                <td>582</td>
                <td><a href="download.php?table=notes&id=139&file=Digital Design, 5th Edition by M58134cfdb883a2.11880899.pdf">Digital Design 5th Edition by M Morris Mano and Michael Ciletti</a></td>
                <td>Switching Theory And Logic Design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>380</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>583</td>
                <td><a href="download.php?table=notes&id=138&file=cgm-Multimedia58137e55a90ab2.63308244.pptx">Multimedia</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>727</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>459.2KB</td>

              </tr>
                            <tr>
                <td>584</td>
                <td><a href="download.php?table=notes&id=137&file=cgm-Multimedia Systems58137e254edef2.44316935.pptx">Multimedia Systems</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>602</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>571.2KB</td>

              </tr>
                            <tr>
                <td>585</td>
                <td><a href="download.php?table=notes&id=135&file=relations581348e6c069f0.80661781.pdf">Relations</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>583</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.2MB</td>

              </tr>
                            <tr>
                <td>586</td>
                <td><a href="download.php?table=notes&id=134&file=recurrance relation581348abd0b6c7.89515579.pdf">Recurance Relation</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>446</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.5MB</td>

              </tr>
                            <tr>
                <td>587</td>
                <td><a href="download.php?table=notes&id=133&file=algebric structures581348646e12c4.29377233.pdf">Algebric Structures</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>576</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.7MB</td>

              </tr>
                            <tr>
                <td>588</td>
                <td><a href="download.php?table=notes&id=132&file=cgm-jpeg5813475860fd36.95828154.docx">JPEG notes</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>546</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>186.1KB</td>

              </tr>
                            <tr>
                <td>589</td>
                <td><a href="download.php?table=notes&id=131&file=Assembler581327c50a7260.19001491.pdf">Assembler</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>506</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>164.6KB</td>

              </tr>
                            <tr>
                <td>590</td>
                <td><a href="download.php?table=notes&id=130&file=lecture2581327560b4330.69535466.pdf">Lecture 2</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>599</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>291.1KB</td>

              </tr>
                            <tr>
                <td>591</td>
                <td><a href="download.php?table=notes&id=129&file=lecture1581327239e4843.58210937.pdf">Lecture 1</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>534</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>427.7KB</td>

              </tr>
                            <tr>
                <td>592</td>
                <td><a href="download.php?table=notes&id=128&file=8086581308f7939295.16351175.pdf">8086</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>622</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>401.8KB</td>

              </tr>
                            <tr>
                <td>593</td>
                <td><a href="download.php?table=notes&id=127&file=bootstraping (compiler)581308b208a686.75646435.pdf">Bootstrapping</a></td>
                <td>Compiler design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>474</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.4MB</td>

              </tr>
                            <tr>
                <td>594</td>
                <td><a href="download.php?table=notes&id=126&file=Microprocessor581307ea3ba242.79338260.pdf">Microprocessors Notes</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>557</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>689.2KB</td>

              </tr>
                            <tr>
                <td>595</td>
                <td><a href="download.php?table=notes&id=125&file=8085581307b81c5406.14640255.pdf">8085</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>359</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>309.2KB</td>

              </tr>
                            <tr>
                <td>596</td>
                <td><a href="download.php?table=notes&id=123&file=CGM Unit 1581303c3c12da4.69465670.pdf">Unit 1</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>598</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>38.9MB</td>

              </tr>
                            <tr>
                <td>597</td>
                <td><a href="download.php?table=notes&id=122&file=os_notes15813030ba3c6c1.96889088.pdf">OS Notes1</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>536</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>32.9MB</td>

              </tr>
                            <tr>
                <td>598</td>
                <td><a href="download.php?table=notes&id=114&file=Shading Models5812552c84b591.22310939.pdf">Buffer Shading Model</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>371</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>599</td>
                <td><a href="download.php?table=notes&id=113&file=CGM-Unit 45812535f6c05f4.86105521.pdf">Unit 4</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>560</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.7MB</td>

              </tr>
                            <tr>
                <td>600</td>
                <td><a href="download.php?table=notes&id=112&file=CGM Unit 3581251b2007785.02698130.pdf">Unit 3</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>455</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.1MB</td>

              </tr>
                            <tr>
                <td>601</td>
                <td><a href="download.php?table=notes&id=111&file=CGM Unit 258125137c20dc3.40590983.pdf">UNIT 2</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>621</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.1MB</td>

              </tr>
                            <tr>
                <td>602</td>
                <td><a href="download.php?table=notes&id=110&file=se notes58124e7b870a76.38794814.docx">SE Notes</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>621</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>603</td>
                <td><a href="download.php?table=notes&id=109&file=os_notes25812392ed931a4.72738879.pdf">Process Synchronization</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>449</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.3MB</td>

              </tr>
                            <tr>
                <td>604</td>
                <td><a href="download.php?table=notes&id=108&file=Web-Engg-Servlet581236d7d20df8.17756498.pdf">Servlets</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>450</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>606.3KB</td>

              </tr>
                            <tr>
                <td>605</td>
                <td><a href="download.php?table=notes&id=107&file=Web-Engg-JSP581236b0035c83.26929206.pdf">JSP</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>370</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>494.8KB</td>

              </tr>
                            <tr>
                <td>606</td>
                <td><a href="download.php?table=notes&id=106&file=Web-Engg-JavaScript581235fb6dd551.29876614.pdf">JavaScript</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>423</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>607</td>
                <td><a href="download.php?table=notes&id=105&file=artificial intelligence unit 1-25811e36c339771.18713903.pdf">AI unit 1 2</a></td>
                <td>Artificial intelligence</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>514</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26.5MB</td>

              </tr>
                            <tr>
                <td>608</td>
                <td><a href="download.php?table=notes&id=104&file=operating_system_tutorial5811fc72aacee4.78637471.pdf">OS tutorial</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>353</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.9MB</td>

              </tr>
                            <tr>
                <td>609</td>
                <td><a href="download.php?table=notes&id=103&file=basics_compiler5811d6b141c355.10023703.pdf">Basics Compiler</a></td>
                <td>Compiler design</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>589</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.2MB</td>

              </tr>
                            <tr>
                <td>610</td>
                <td><a href="download.php?table=notes&id=102&file=oops5810e9774cb4d1.22724298.docx">File handling</a></td>
                <td>Object oriented programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>547</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>41.8KB</td>

              </tr>
                            <tr>
                <td>611</td>
                <td><a href="download.php?table=notes&id=101&file=JAVA UNIT 4580e5a64c150a6.21469787.pdf">Unit 4</a></td>
                <td>Java programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>352</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.7MB</td>

              </tr>
                            <tr>
                <td>612</td>
                <td><a href="download.php?table=notes&id=100&file=JAVA UNIT 3580e4dc21b3491.97396257.pdf">Unit 3</a></td>
                <td>JAVA Programming</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>493</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.4MB</td>

              </tr>
                            <tr>
                <td>613</td>
                <td><a href="download.php?table=notes&id=99&file=se notes58066fcd1b4c33.40494160.docx">3rd and 4th Unit</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>462</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>614</td>
                <td><a href="download.php?table=notes&id=98&file=SurveyCompression(1)5810e90218e921.66922957.pdf">Compression techniques</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>CSE</td>
                <td>359</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4MB</td>

              </tr>
                            <tr>
                <td>615</td>
                <td><a href="download.php?table=notes&id=97&file=ADA_UNIT-1583490dd4661a8.99578588.pdf">Unit 1</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>799</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>32.8MB</td>

              </tr>
                            <tr>
                <td>616</td>
                <td><a href="download.php?table=notes&id=95&file=ADA_UNIT_25834856f5a9478.02346554.pdf">Unit 2</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>529</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>10MB</td>

              </tr>
                            <tr>
                <td>617</td>
                <td><a href="download.php?table=notes&id=94&file=ADA_UNIT_358347f4822fb29.85667371.pdf">Unit 3</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>603</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20.3MB</td>

              </tr>
                            <tr>
                <td>618</td>
                <td><a href="download.php?table=notes&id=93&file=ADA_UNIT_458347c8232af44.82019088.pdf">Unit 4</a></td>
                <td>Algorithms Design and Analysis</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>595</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9MB</td>

              </tr>
                            <tr>
                <td>619</td>
                <td><a href="download.php?table=notes&id=92&file=wc2_15830a81dedf531.09319810.pdf">Wireless Channels and Diversity</a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>545</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.5MB</td>

              </tr>
                            <tr>
                <td>620</td>
                <td><a href="download.php?table=notes&id=91&file=wc1582aed454b38e3.09422763.pdf">Intro to Wireless PCS </a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>481</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>61MB</td>

              </tr>
                            <tr>
                <td>621</td>
                <td><a href="download.php?table=notes&id=90&file=acn3582a745c9dcff8.47707553.pdf">ACN3</a></td>
                <td>Advanced Computer Networks</td>
                <!--<td></td>-->
                <td>IT, CSE</td>
                <td>684</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>34.6MB</td>

              </tr>
                            <tr>
                <td>622</td>
                <td><a href="download.php?table=notes&id=89&file=acn2582a704a1adaa9.45705222.pdf">ACN2</a></td>
                <td>Advanced Computer Networks</td>
                <!--<td></td>-->
                <td>IT,CSE</td>
                <td>776</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.3MB</td>

              </tr>
                            <tr>
                <td>623</td>
                <td><a href="download.php?table=notes&id=88&file=acn1582a6ba7932ce8.36396764.pdf">ACN1</a></td>
                <td>Advanced Computer Networks</td>
                <!--<td></td>-->
                <td>IT,CSE</td>
                <td>754</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>45.1MB</td>

              </tr>
                            <tr>
                <td>624</td>
                <td><a href="download.php?table=notes&id=86&file=CS UNIT 4582326ff869be4.47934086.pdf">CS Unit 4</a></td>
                <td>Communication systems</td>
                <!--<td></td>-->
                <td>IT,EEE</td>
                <td>747</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.2MB</td>

              </tr>
                            <tr>
                <td>625</td>
                <td><a href="download.php?table=notes&id=85&file=os notes unit 35821b8193a1322.00122970.pdf">OS Notes Unit 3</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>357</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.3MB</td>

              </tr>
                            <tr>
                <td>626</td>
                <td><a href="download.php?table=notes&id=84&file=Random Variables58172a6dec65b5.90204577.pdf">Random Variables Unit 1</a></td>
                <td>Communication systems</td>
                <!--<td></td>-->
                <td>IT,EEE</td>
                <td>582</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.9MB</td>

              </tr>
                            <tr>
                <td>627</td>
                <td><a href="download.php?table=notes&id=83&file=software_engineering5814cd5e5e4e85.13430981.pdf">Unit 1 4 important topics</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>623</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3.7MB</td>

              </tr>
                            <tr>
                <td>628</td>
                <td><a href="download.php?table=notes&id=81&file=chapter 6 Software Metrics5814790e04ffc8.72403601.pdf">Unit 1 part Software metrices</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>627</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>908.5KB</td>

              </tr>
                            <tr>
                <td>629</td>
                <td><a href="download.php?table=notes&id=80&file=Chapter 9 Software Maintenance5814789d4af4b5.40580300.pdf">Unit 4 part 2</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>452</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>545.6KB</td>

              </tr>
                            <tr>
                <td>630</td>
                <td><a href="download.php?table=notes&id=79&file=Chapter 8 Software Testing581473ff7ad607.75964319.pdf">Unit 4 part 1</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>471</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2MB</td>

              </tr>
                            <tr>
                <td>631</td>
                <td><a href="download.php?table=notes&id=78&file=Chapter 5 Software Design5814734be7af90.34247804.pdf">Unit 3 Software Design</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>485</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>632</td>
                <td><a href="download.php?table=notes&id=76&file=Chapter 4 Software Project planning5814727bbeae16.02243432.pdf">Chapter 4 Software Project planning</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>519</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.4MB</td>

              </tr>
                            <tr>
                <td>633</td>
                <td><a href="download.php?table=notes&id=75&file=Chapter 2 Software Development Life Cycle Models58147202e3a106.94497741.pdf">Chapter 2 Software Life Cycle</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>476</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>611.2KB</td>

              </tr>
                            <tr>
                <td>634</td>
                <td><a href="download.php?table=notes&id=74&file=8085_is_details581462a2b0a9e0.20616929.pdf">8085 DETAILS</a></td>
                <td>Computer organization and architecture</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>499</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>280.1KB</td>

              </tr>
                            <tr>
                <td>635</td>
                <td><a href="download.php?table=notes&id=73&file=Normalization_DBMS581462285995c8.72289032.pdf">NORMALIZATION </a></td>
                <td>Database management system</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>449</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>299.3KB</td>

              </tr>
                            <tr>
                <td>636</td>
                <td><a href="download.php?table=notes&id=72&file=bcnf581461a30f5063.18166205.pdf">FUNCTIONAL DEPENDENCY</a></td>
                <td>Database management system</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>458</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.1MB</td>

              </tr>
                            <tr>
                <td>637</td>
                <td><a href="download.php?table=notes&id=71&file=18_vorlesung5814614eb38074.78816478.pdf">TRANSACTION PROCESSING</a></td>
                <td>Database management system</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>498</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>232.1KB</td>

              </tr>
                            <tr>
                <td>638</td>
                <td><a href="download.php?table=notes&id=70&file=transaction notes581460c6a36a04.02713442.docx">TRANSACTION PROCESSING</a></td>
                <td>Database management system</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>313</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>7.3MB</td>

              </tr>
                            <tr>
                <td>639</td>
                <td><a href="download.php?table=notes&id=65&file=csp 10-145813b5cb0ca525.49160667.pdf">Chapter 10 14</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>552</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>30.6MB</td>

              </tr>
                            <tr>
                <td>640</td>
                <td><a href="download.php?table=notes&id=64&file=csp 7,8,95813b446895936.81318465.pdf">Chapter 7 8 9</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>479</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>37.9MB</td>

              </tr>
                            <tr>
                <td>641</td>
                <td><a href="download.php?table=notes&id=63&file=csp 4,5,65813b179d12748.07679026.pdf">Chapter 4 5 6</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>584</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>40.9MB</td>

              </tr>
                            <tr>
                <td>642</td>
                <td><a href="download.php?table=notes&id=62&file=csp 1,2,35813abe3c4d623.81002370.pdf">Chapter 1 2 3</a></td>
                <td>Communication Skills For Professionals</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>556</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>27.9MB</td>

              </tr>
                            <tr>
                <td>643</td>
                <td><a href="download.php?table=notes&id=58&file=cgm-Multimedia58137e55a90ab2.63308244.pptx">Multimedia</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>598</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>459.2KB</td>

              </tr>
                            <tr>
                <td>644</td>
                <td><a href="download.php?table=notes&id=57&file=cgm-Multimedia Systems58137e254edef2.44316935.pptx">Multimedia Systems</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>514</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>571.2KB</td>

              </tr>
                            <tr>
                <td>645</td>
                <td><a href="download.php?table=notes&id=55&file=Digital Design, 5th Edition by M58134cfdb883a2.11880899.pdf">Digital Design 5th Edition by M Morris Mano and Michael Ciletti</a></td>
                <td>Switching Theory And Logic Design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>446</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>3MB</td>

              </tr>
                            <tr>
                <td>646</td>
                <td><a href="download.php?table=notes&id=52&file=numerical  solution  of ordinary  differential  equations  58134c20975a39.52978992.pdf">Numerical solution of Ordinary Differential Equations </a></td>
                <td>Applied Maths 3</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>425</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>25.5MB</td>

              </tr>
                            <tr>
                <td>647</td>
                <td><a href="download.php?table=notes&id=51&file=numerical  methods  58134b9c3264f2.15812411.pdf">Numerical methods</a></td>
                <td>Applied Maths 3</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>430</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>25.6MB</td>

              </tr>
                            <tr>
                <td>648</td>
                <td><a href="download.php?table=notes&id=50&file=fourier series  58134b2a1c70b0.86837271.pdf">Fourier series</a></td>
                <td>Applied Maths 3</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>462</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>20.7MB</td>

              </tr>
                            <tr>
                <td>649</td>
                <td><a href="download.php?table=notes&id=49&file=finite difference and interpolation 58134aa2c89427.66622703.pdf">Finite difference and Interpolation</a></td>
                <td>Applied Maths 3</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>341</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>38.3MB</td>

              </tr>
                            <tr>
                <td>650</td>
                <td><a href="download.php?table=notes&id=48&file=difference equation  and z transformation  58134a01616622.67701880.pdf">Difference equation and z transformation</a></td>
                <td>Applied Maths 3</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>333</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>22.2MB</td>

              </tr>
                            <tr>
                <td>651</td>
                <td><a href="download.php?table=notes&id=46&file=relations581348e6c069f0.80661781.pdf">Relations</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>534</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.2MB</td>

              </tr>
                            <tr>
                <td>652</td>
                <td><a href="download.php?table=notes&id=45&file=recurrance relation581348abd0b6c7.89515579.pdf">Recurance Relation</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>568</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>8.5MB</td>

              </tr>
                            <tr>
                <td>653</td>
                <td><a href="download.php?table=notes&id=44&file=algebric structures581348646e12c4.29377233.pdf">Algebric Structures</a></td>
                <td>Foundation of computer science</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>560</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>17.7MB</td>

              </tr>
                            <tr>
                <td>654</td>
                <td><a href="download.php?table=notes&id=42&file=cgm-jpeg5813475860fd36.95828154.docx">JPEG notes</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>571</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>186.1KB</td>

              </tr>
                            <tr>
                <td>655</td>
                <td><a href="download.php?table=notes&id=41&file=Assembler581327c50a7260.19001491.pdf">Assembler</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>497</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>164.6KB</td>

              </tr>
                            <tr>
                <td>656</td>
                <td><a href="download.php?table=notes&id=40&file=lecture2581327560b4330.69535466.pdf">Lecture 2</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>477</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>291.1KB</td>

              </tr>
                            <tr>
                <td>657</td>
                <td><a href="download.php?table=notes&id=39&file=lecture1581327239e4843.58210937.pdf">Lecture 1</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>526</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>427.7KB</td>

              </tr>
                            <tr>
                <td>658</td>
                <td><a href="download.php?table=notes&id=38&file=8086581308f7939295.16351175.pdf">8086</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>485</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>401.8KB</td>

              </tr>
                            <tr>
                <td>659</td>
                <td><a href="download.php?table=notes&id=37&file=bootstraping (compiler)581308b208a686.75646435.pdf">Bootstrapping</a></td>
                <td>Compiler design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>498</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>5.4MB</td>

              </tr>
                            <tr>
                <td>660</td>
                <td><a href="download.php?table=notes&id=36&file=Microprocessor581307ea3ba242.79338260.pdf">Microprocessors Notes</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>571</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>689.2KB</td>

              </tr>
                            <tr>
                <td>661</td>
                <td><a href="download.php?table=notes&id=35&file=8085581307b81c5406.14640255.pdf">8085</a></td>
                <td>Microprocessor and microcontroller</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>454</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>309.2KB</td>

              </tr>
                            <tr>
                <td>662</td>
                <td><a href="download.php?table=notes&id=34&file=wireless58130694ef7050.67050870.pdf">Wireless Com </a></td>
                <td>Wireless Communication</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>372</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>35.7MB</td>

              </tr>
                            <tr>
                <td>663</td>
                <td><a href="download.php?table=notes&id=33&file=CGM Unit 1581303c3c12da4.69465670.pdf">Unit 1</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>585</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>38.9MB</td>

              </tr>
                            <tr>
                <td>664</td>
                <td><a href="download.php?table=notes&id=32&file=os_notes15813030ba3c6c1.96889088.pdf">OS Notes1</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>556</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>32.9MB</td>

              </tr>
                            <tr>
                <td>665</td>
                <td><a href="download.php?table=notes&id=31&file=Essays5812d5f4d888e3.09054394.pdf">Essays</a></td>
                <td>Communication Skills</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1283</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.2MB</td>

              </tr>
                            <tr>
                <td>666</td>
                <td><a href="download.php?table=notes&id=30&file=Solid_State_Electronics5812d2d0b72d40.28740105.pdf">Solid State Electronics ebook</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1039</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>19.9MB</td>

              </tr>
                            <tr>
                <td>667</td>
                <td><a href="download.php?table=notes&id=29&file=EDC p-s5812d1ae1ac738.69144954.pdf">Important topics and problems</a></td>
                <td>Electronic Devices</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>1507</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>12.8MB</td>

              </tr>
                            <tr>
                <td>668</td>
                <td><a href="download.php?table=notes&id=28&file=IT - Assignment 25812cfac6af7a8.60567162.docx">Assignment 2</a></td>
                <td>Fundamentals Of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>435</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>16KB</td>

              </tr>
                            <tr>
                <td>669</td>
                <td><a href="download.php?table=notes&id=27&file=PARTS OF A COMPUTER5812cf59857ae3.09415582.docx">Parts of computer</a></td>
                <td>Fundamentals Of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>711</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>93.4KB</td>

              </tr>
                            <tr>
                <td>670</td>
                <td><a href="download.php?table=notes&id=26&file=DISK OPERATING SYSTEM (DOS)5812ce70660730.50315076.pdf">Ms DOS</a></td>
                <td>Fundamentals Of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>746</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>326.9KB</td>

              </tr>
                            <tr>
                <td>671</td>
                <td><a href="download.php?table=notes&id=25&file=DBMS Notes5812cda1a77864.91621188.docx">DBMS</a></td>
                <td>Fundamentals Of Computing</td>
                <!--<td></td>-->
                <td>CSE, IT, MAE, CIVIL, EEE, ECE</td>
                <td>903</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>21.4KB</td>

              </tr>
                            <tr>
                <td>672</td>
                <td><a href="download.php?table=notes&id=24&file=Shading Models5812552c84b591.22310939.pdf">Buffer Shading Model</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>546</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>673</td>
                <td><a href="download.php?table=notes&id=23&file=CGM-Unit 45812535f6c05f4.86105521.pdf">Unit 4</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>489</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>24.7MB</td>

              </tr>
                            <tr>
                <td>674</td>
                <td><a href="download.php?table=notes&id=22&file=CGM Unit 3581251b2007785.02698130.pdf">Unit 3</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>565</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.1MB</td>

              </tr>
                            <tr>
                <td>675</td>
                <td><a href="download.php?table=notes&id=21&file=CGM Unit 258125137c20dc3.40590983.pdf">UNIT 2</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>545</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>18.1MB</td>

              </tr>
                            <tr>
                <td>676</td>
                <td><a href="download.php?table=notes&id=20&file=se notes58124e7b870a76.38794814.docx">SE Notes</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>568</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
                            <tr>
                <td>677</td>
                <td><a href="download.php?table=notes&id=19&file=os_notes25812392ed931a4.72738879.pdf">Process Synchronization</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>527</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.3MB</td>

              </tr>
                            <tr>
                <td>678</td>
                <td><a href="download.php?table=notes&id=18&file=Web-Engg-Servlet581236d7d20df8.17756498.pdf">Servlets</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>348</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>606.3KB</td>

              </tr>
                            <tr>
                <td>679</td>
                <td><a href="download.php?table=notes&id=17&file=Web-Engg-JSP581236b0035c83.26929206.pdf">JSP</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>482</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>494.8KB</td>

              </tr>
                            <tr>
                <td>680</td>
                <td><a href="download.php?table=notes&id=16&file=Web-Engg-JavaScript581235fb6dd551.29876614.pdf">JavaScript</a></td>
                <td>Web engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>464</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1MB</td>

              </tr>
                            <tr>
                <td>681</td>
                <td><a href="download.php?table=notes&id=15&file=operating_system_tutorial5811fc72aacee4.78637471.pdf">OS tutorial</a></td>
                <td>Operating Systems</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>554</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.9MB</td>

              </tr>
                            <tr>
                <td>682</td>
                <td><a href="download.php?table=notes&id=14&file=artificial intelligence unit 1-25811e36c339771.18713903.pdf">AI unit 1 2</a></td>
                <td>Artificial intelligence</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>525</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>26.5MB</td>

              </tr>
                            <tr>
                <td>683</td>
                <td><a href="download.php?table=notes&id=11&file=basics_compiler5811d6b141c355.10023703.pdf">Basics Compiler</a></td>
                <td>Compiler design</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>478</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>2.2MB</td>

              </tr>
                            <tr>
                <td>684</td>
                <td><a href="download.php?table=notes&id=10&file=oops5810e9774cb4d1.22724298.docx">File handling</a></td>
                <td>Object oriented programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>487</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>41.8KB</td>

              </tr>
                            <tr>
                <td>685</td>
                <td><a href="download.php?table=notes&id=9&file=Dbms5810e949ed42d7.65230785.docx">Triggers</a></td>
                <td>Database management system</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>463</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>368.7KB</td>

              </tr>
                            <tr>
                <td>686</td>
                <td><a href="download.php?table=notes&id=8&file=SurveyCompression(1)5810e90218e921.66922957.pdf">Compression techniques</a></td>
                <td>Computer graphics and multimedia</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>345</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>4MB</td>

              </tr>
                            <tr>
                <td>687</td>
                <td><a href="download.php?table=notes&id=5&file=JAVA UNIT 4580e5a64c150a6.21469787.pdf">Unit 4</a></td>
                <td>Java programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>452</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>9.7MB</td>

              </tr>
                            <tr>
                <td>688</td>
                <td><a href="download.php?table=notes&id=3&file=JAVA UNIT 3580e4dc21b3491.97396257.pdf">Unit 3</a></td>
                <td>JAVA Programming</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>473</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>14.4MB</td>

              </tr>
                            <tr>
                <td>689</td>
                <td><a href="download.php?table=notes&id=2&file=se notes58066fcd1b4c33.40494160.docx">3rd and 4th Unit</a></td>
                <td>Software Engineering</td>
                <!--<td></td>-->
                <td>IT</td>
                <td>610</td>
                <!--<td></td>-->
                <td>NotesHub</td>
                <td>1.3MB</td>

              </tr>
              
          </tbody>

        </table>

      </div>

      <br/>
      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
      <!-- text_and_display -->
      <ins class="adsbygoogle ad-type-1"
           style="display:block"
           data-ad-client="ca-pub-6153632791841759"
           data-ad-slot="9543810896"
           data-ad-format="auto"></ins>
      <script>
      (adsbygoogle = window.adsbygoogle || []).push({});
      </script>

      <br/>

<div class="container marketing">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script type="text/javascript">
//for dynamic subject list
$(document).ready(function(){
  $('#semester').on('change',function(){
    var semester = $(this).val();
    var branch = $('#branch').val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('#branch').on('change',function(){
    var semester = $('#semester').val();
    var branch = $(this).val();
    $.ajax({
        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('#subjects').html(html);
            $('.subjects1').html(html);
            $('.subjects2').html(html);
            $('.subjects3').html(html);
        }
    });
  });
  $('.load_sub1').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects1').last().html(html);
        }
    });
  });
  $('.load_sub2').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects2').last().html(html);
        }
    });
  });
  $('.load_sub3').on('click',function(){
    var semester = $('#semester').val();
    var branch = $('#branch').val();
    $.ajax({

        type:'POST',
        url:'getSubjects.php',
        data:'semester='+semester+'&branch='+branch,
        success:function(html){
            $('.subjects3').last().html(html);
        }
    });
  });
});
</script>

<!-- Three columns of text below the carousel -->
<div class="row">
  <div class="col-lg-4">
    <img class="img-circle" src="images/6.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Experience</h2>
    <p>Its been an year since we started NotesHub, therefore we know what you need, when you need and how much you need.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/7.png" alt="Generic placeholder image" width="140" height="140">
    <h2>100K+ Visits</h2>
    <p>We have seen 100 Thousand plus visits on
NotesHub and we are proud that we could
deliver so much value.</p>

  </div><!-- /.col-lg-4 -->
  <div class="col-lg-4">
    <img class="img-circle" src="images/8.png" alt="Generic placeholder image" width="140" height="140">
    <h2>Quality
</h2>
    <p>One of the most important thing to us is that the material
we provide you is of exquisite quality. We know its frustrating to spend time on useless material.</p>

  </div><!-- /.col-lg-4 -->
</div><!-- /.row -->



<!--CUSTOM ADVERTISEMENT True Value Smartphones-->
      <a href="https://goo.gl/WkPCzV" style="text-decoration:none;">
        <div class="container text-center">
        Sponsored
        <div class="row" style="background: #eee; font-size: 1.2em; padding: 15px;">

          <div class="col-lg-3 col-lg-3">
            <p><img style="width:100%;" src="images/ad.jpg"></p>
          </div>

          <div class="col-lg-6 col-lg-6">
            <p style="font-size: 2em; font-weight: bold; color:#225bc2;">True Value Smartphone</p>
            <p>We buy and sell used or preowned smartphone at <strong>Best Price</strong></p>

            <img src="https://www.apple.com/favicon.ico">
            <img src="https://statics.oneplus.net/v3/img/common/logo.png">
            <img src="https://www.skymartbw.com/wp-content/uploads/2010/04/lg-logo.png" width="96">
            <img src="https://www.senheng.com.my/media/catalog/category/xiaomi.png"> and more...
          </div>

          <div class="col-lg-3 col-md-3" style="text-align: center;">
            <p style="width: 100%;"><strong>Office address:</strong> 8/66, 3<sup>rd</sup> floor Vijay Nagar Double Storey, Delhi 110009<br/>Near North Campus DU</p>
            <p><a href="tel:8860828901"><span class="glyphicon glyphicon-earphone"></span> 8860828901</a></p>
          </div>
        </div>
        </div>
      </a>
      <br/>
      <hr>


<!-- START THE FEATURETTES -->
  <!--GOOGLE ADS-->
  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <!-- text_and_display -->
  <ins class="adsbygoogle ad-type-1"
       style="display:block"
       data-ad-client="ca-pub-6153632791841759"
       data-ad-slot="9543810896"
       data-ad-format="auto"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>

<hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">NOTES</h2>
      <p class="lead">NotesHub came into existence because we experienced the same problem that you all face during exams. Standing for hours at photocopy shops and gathering notes wastes alot of time..</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/1.jpg" alt="Find Notes and study material">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7 col-md-push-5">
      <h2 class="featurette-heading">BOOKS</h2>
      <p class="lead">Spending Rs. 5000+ every semester to buy books on rent and then receiving only 30% of the cost is wastage of money too. Using NotesHub, you can get the books at 50% price with all the supplementary material. We are also trying to arrange all the eBooks we can!
</p>
    </div>
    <div class="col-md-5 col-md-pull-7">
      <img class="featurette-image img-responsive center-block" src="images/2.jpg" alt="Engineering books">
    </div>
  </div>

  <hr class="featurette-divider">

  <div class="row featurette">
    <div class="col-md-7">
      <h2 class="featurette-heading">PRACTICAL FILES</h2>
      <p class="lead">We all HATE making practical files because they are nothing but making copies. Also, arranging the files and material is a task in itself. Here, we are trying to bridge the gap between the colleges so that everyone can make their files quick and easy and focus on whats more important i.e. learning to perform the practical</p>
    </div>
    <div class="col-md-5">
      <img class="featurette-image img-responsive center-block" src="images/3.jpg" alt="Find practical files">
    </div>
  </div>

  <hr class="featurette-divider">


        <div class="row featurette">
          <div class="col-md-7 col-md-push-5">
            <h2 class="featurette-heading">QUESTION PAPERS</h2>
            <p class="lead">NotesHub is also the place to get all the previous year question papers  with solutions. We also try to arrange for different types of assignments.
  </p>
          </div>
          <div class="col-md-5 col-md-pull-7">
            <img class="featurette-image img-responsive center-block" src="images/4.jpg" alt="Previous year question papers">
          </div>
        </div>

        <!--<hr class="featurette-divider">

        <div class="row featurette">
          <div class="col-md-7">
            <h2 class="featurette-heading">INTERNSHIPS</h2>
            <p class="lead">Most of us are not able to score an internship because we are looking at the wrong places. Also, due to lack of information, we miss opportunities. This is what we identified and hence NotesHub has a <b>Internship Feed</b>  that will keep you up to date with all the new opportunities in town.</p>

          </div>
          <div class="col-md-5">
            <img class="featurette-image img-responsive center-block" src="images/5.jpg" alt="Find Internships">
          </div>
        </div>!-->

        <hr class="featurette-divider ad-type-2">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    		<ins class="adsbygoogle"
    		     style="display:block"
    		     data-ad-format="fluid"
    		     data-ad-layout-key="-8i+1w-dq+e9+ft"
    		     data-ad-client="ca-pub-6153632791841759"
    		     data-ad-slot="7024802225"></ins>
    		<script>
    		     (adsbygoogle = window.adsbygoogle || []).push({});
    		</script>
</div>
  <!-- /.container -->
		<hr class="featurette-divider">

<!-- /END THE FEATURETTES -->


  <div class="container-fluid">

    <div class="row">

                  <div class="about-us-parallax">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofAboutUs">Your Last Minute Companion</span>
                      <br>
                      <br>
                      <p style="font-size:x-large; color: white;">Nothing makes a person more productive than the <b>"Last Minute"</b></p>
                    </div>
                  </div>
                  </div>

                  <div class="row" id="about">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">About Us</h3>
                    <p class="description-aboutus">Trying to make your lives easier. That&rsquo;s it. Nothing fancy.</p>
                  </div>
                  </div>

                  <div class="row">
                  <div class="contactus-parallax ">
                    <div class="caption col-md-12 col-sm-12 col-xs-12">
                      <span class="textofContactUs">Hello!<br>Let&rsquo;s Talk.</span>
                      <br>

                    </div>
                  </div>
                  </div>

                  <div class="row" id="contact">
                  <div class="about-us-text col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
                    <h3 class="heading-aboutUs">Suggestions, Feedback, Advice?</h3>

                    <p class="description-aboutus">We thrive to improve. Drop us a mail.</p>
                  </div>
                  </div>
      <br>
  </div>


      <!--############################# form ##########################################-->
        <div class="container-fluid">
            <div class="row">


                <div class="col-md-8">
                    <div class="well well-sm">
                        <form action="contact.php" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Enter name" required="required" name="name"/>
                                </div>
                                <div class="form-group">
                                    <label for="email">
                                        Email Address</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                        </span>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" required="required" name="email"/></div>
                                </div>
                                <div class="form-group">
                                    <label for="subject">
                                        Subject</label>
                                    <select class="form-control" required="required" name="subject">
                                        <option value="" selected disabled>Choose One:</option>
                                        <option value="Non-availability of material">Non-availability of material</option>
                                        <option value="Buy/Sell Book">Buy/Sell Book</option>
                                        <option value="Just to say Hello!">Just to say Hello!</option>
                                        <option value="Others">Others</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name">
                                        Message</label>
                                    <textarea id="message" class="form-control" rows="9" cols="25" required="required"
                                        placeholder="Message" name="message"></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                                    Send Message</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>


                <div class="col-md-4" style="text-align: center;">
                    <legend>Our Motto</legend>
                    <img src="images/back.jpg" style="min-height: 250px; width: 100%; margin-top: -15px;">

                </div>


            </div>

          </div><!--container fluid ends -->


      <!-- ############################# form ########################################## -->

        <br>
        <br>

   <div class="container-fluid">
                  <div class="row">
                    <div class="followUs-parallax">
                    <div class="caption col-md-9 col-sm-12 col-xs-12">
                    <br>
                    <br>
                    <br>
                      <div style="float: right;" class="social">
                      <span style="font-size: 25px; color: white;">We don&rsquo;t mind Stalking!</span>


                      <br>
                      <a href="https://www.facebook.com/TeamNotesHub/" target="blank" style="color: white  !important;"><i  class="fa fa-facebook-square fa-5x social"></i></a>
                      &nbsp;&nbsp;
                      <a href="https://www.instagram.com/_noteshub_/" target="blank" style="color: white  !important;"><i class="fa fa-instagram fa-5x" aria-hidden="true"></i></a>
                      </div>

                    </div>
                  </div>
                  </div>

    <br>
    <br>


                    <div class="row">
                      <div style="text-align: center;" >
                        <h2>Thank You.</h2>
                      </div>
                    </div>
    <br>
    <br>

    </div>







    <!-- FOOTER -->

  <footer class="footer-basic-centered" style="padding-top: 0 !important; padding-bottom: 10px;">


    <p class = "footer-company-motto" style="color: white;padding: 8px; font-style: 20px;" >NotesHub</p>

    <p class="footer-company-name">NotesHub | SPI &copy; 2016-18</p>

    <p class="footer-company-name"><a href="privacy_policy.html" target="_blank">Privacy Policy</a> | <a href="terms_and_conditions.html" target="_blank">Terms and Conditions</a></p>

  </footer>
  <!--INCLUDING SIGNIN SIGNUP MODALS -->
  <!--Modals-->

<!-- user login -->
<div class="modal fade"  id="userLogin" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">User Login</h4>
			</div>
			<form action="loginScript.php" method="post">
			<div class="modal-body">

					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword2">Password</label>
						<input required type="password" class="form-control" id="exampleInputPassword2" placeholder="Password" name="password">
						<span><a href="#" data-toggle="modal" data-target="#forgotPassword">Forgot Password?</a></span>

					</div>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Login</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- forgot password -->
<div class="modal fade"  id="forgotPassword" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Forgot Password?</h4>
			</div>
			<form action="recovery.php" method="post">
			<div class="modal-body">
					<div class="form-group">
						<label for="">Email address</label>
						<input required type="email" class="form-control"  placeholder="Your registered email id" name="email">
					</div>
			</div>
			<div class="modal-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- signup -->
<div class="modal fade" id="signUp" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Sign Up</h4>
			</div>
			<form action = "register.php" method="post">
				<div class="modal-body">
					<div class="form-group">
						<label for="">Name</label>
						<input required type="text" name="name" pattern="[a-zA-Z]+[a-zA-Z ]*" class="form-control"  placeholder="Name (only letters and spaces are alllowed)">
					</div>

					<div class="form-group">
						<label for="">Email ID</label>
						<input required type="email" name="email" class="form-control" placeholder="Email">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input required type="password" name="password" minlength="8" maxlength="32" class="form-control" id="exampleInputPassword1" placeholder="Password (must be of at least 8 characters)">
					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Mobile Number</label>
						<input required type="tel" name="phno" pattern="[7-9]{1}[0-9]{9}" class="form-control" id="phoneNumber" placeholder="Mobile Number (must start with7, 8, or 9 and be of 10 digits)">
					</div>

					<div class="form-group">
					<label for="college">College</label>
					<select required name="college" class="form-control">
							<option value="" selected disabled>Select College</option>
							<option value="Ambedkar Institute of Advanced Communication Technologies and Research">Ambedkar Institute of Advanced Communication Technologies and Research</option><option value="Amity School of Engineering and Technology">Amity School of Engineering and Technology</option><option value="B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat">B.M. Institute of Engineering and Technology (B.M.I.E.T.) Sonipat</option><option value="Bhagwan Parshuram Institute of Technology">Bhagwan Parshuram Institute of Technology</option><option value="Bharati Vidyapeeth's College of Engineering">Bharati Vidyapeeth's College of Engineering</option><option value="Ch. B.P. Government Engineering College, Delhi">Ch. B.P. Government Engineering College, Delhi</option><option value="Delhi Technical Campus">Delhi Technical Campus</option><option value="Guru Tegh Bahadur Institute of Technology">Guru Tegh Bahadur Institute of Technology</option><option value="HMR Institute of Technology & Management">HMR Institute of Technology & Management</option><option value="JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)">JIMS Engineering Management Technical Campus, Greater Noida (JEMTEC)</option><option value="Maharaja Agrasen Institute of Technology">Maharaja Agrasen Institute of Technology</option><option value="Maharaja Surajmal Institute of Technology">Maharaja Surajmal Institute of Technology</option><option value="Northern India Engineering College">Northern India Engineering College</option><option value="University School of Information and Communication Technology">University School of Information and Communication Technology</option>					</select>
					</div>

					<div class="form-group">
					<label for="college">Branch</label>
					<select required name = "branch" class="form-control">
							<option value="" selected disabled>Select Branch</option>
							<option value="cse">CSE</option>
							<option value="it">IT</option>
							<option value="mae">MAE</option>
							<option value="civil">CIVIL</option>
							<option value="eee">EEE</option>
							<option value="ece">ECE</option>
					</select>
					</div>

					<div class="form-group">
					<label for="college">Nearest Metro Station</label>
					<select required name = "nms" class="form-control">
							<option value="" selected disabled>Select Nearest Metro Station</option>
							<option value="ADARSH NAGAR">ADARSH NAGAR</option><option value="AIIMS">AIIMS</option><option value="AKSHARDHAM">AKSHARDHAM</option><option value="ANAND VIHAR">ANAND VIHAR</option><option value="ARJANGARH">ARJANGARH</option><option value="ASHOK PARK MAIN">ASHOK PARK MAIN</option><option value="AZADPUR">AZADPUR</option><option value="BADARPUR">BADARPUR</option><option value="BADKAL MOR">BADKAL MOR</option><option value="BARAKHAMBA">BARAKHAMBA</option><option value="BATA CHOWK">BATA CHOWK</option><option value="BOTANICAL GARDEN">BOTANICAL GARDEN</option><option value="CENTRAL SECRETARIAT">CENTRAL SECRETARIAT</option><option value="CHANDNI CHOWK">CHANDNI CHOWK</option><option value="CHAWRI BAZAR">CHAWRI BAZAR</option><option value="CHHATTARPUR">CHHATTARPUR</option><option value="CIVIL LINES">CIVIL LINES</option><option value="DELHI AERO CITY">DELHI AERO CITY</option><option value="DELHI GATE">DELHI GATE</option><option value="DHAULA KUAN">DHAULA KUAN</option><option value="DILSHAD GARDEN">DILSHAD GARDEN</option><option value="DWARKA">DWARKA</option><option value="DWARKA MOR">DWARKA MOR</option><option value="DWARKA SEC 10">DWARKA SEC 10</option><option value="DWARKA SEC 11">DWARKA SEC 11</option><option value="DWARKA SEC 12">DWARKA SEC 12</option><option value="DWARKA SEC 13">DWARKA SEC 13</option><option value="DWARKA SEC 14">DWARKA SEC 14</option><option value="DWARKA SEC 21">DWARKA SEC 21</option><option value="DWARKA SEC 8">DWARKA SEC 8</option><option value="DWARKA SEC 9">DWARKA SEC 9</option><option value="ESCORTS MUJESAR">ESCORTS MUJESAR</option><option value="G.T.B. NAGAR">G.T.B. NAGAR</option><option value="GHITORNI">GHITORNI</option><option value="GOLF COURSE">GOLF COURSE</option><option value="GOVIND PURI">GOVIND PURI</option><option value="GREEN PARK">GREEN PARK</option><option value="GURU DRONACHARYA">GURU DRONACHARYA</option><option value="HAIDERPUR BADLI MOR">HAIDERPUR BADLI MOR</option><option value="HAUZ KHAS">HAUZ KHAS</option><option value="HUDA CITY CENTRE">HUDA CITY CENTRE</option><option value="I.G.I. AIRPORT">I.G.I. AIRPORT</option><option value="IFFCO CHOWK">IFFCO CHOWK</option><option value="INA">INA</option><option value="INDER LOK">INDER LOK</option><option value="INDRAPRASTHA">INDRAPRASTHA</option><option value="ITO">ITO</option><option value="JAHANGIRPURI">JAHANGIRPURI</option><option value="JAMA MASJID">JAMA MASJID</option><option value="JAMIA MILIA ISLAMIYA">JAMIA MILIA ISLAMIYA</option><option value="JANAK PURI EAST">JANAK PURI EAST</option><option value="JANAK PURI WEST">JANAK PURI WEST</option><option value="JANGPURA">JANGPURA</option><option value="JANPATH">JANPATH</option><option value="JASOLA APOLLO">JASOLA APOLLO</option><option value="JASOLA VIHAR">JASOLA VIHAR</option><option value="JHANDEWALAN">JHANDEWALAN</option><option value="JHIL MIL">JHIL MIL</option><option value="JLN STADIUM">JLN STADIUM</option><option value="JORBAGH">JORBAGH</option><option value="KAILASH COLONY">KAILASH COLONY</option><option value="KALINDI KUNJ">KALINDI KUNJ</option><option value="KALKAJI MANDIR">KALKAJI MANDIR</option><option value="KANHAIYA NAGAR">KANHAIYA NAGAR</option><option value="KARKAR DUMA">KARKAR DUMA</option><option value="KAROL BAGH">KAROL BAGH</option><option value="KASHMERE GATE">KASHMERE GATE</option><option value="KAUSHAMBI">KAUSHAMBI</option><option value="KESHAV PURAM">KESHAV PURAM</option><option value="KHAN MARKET">KHAN MARKET</option><option value="KIRTI NAGAR">KIRTI NAGAR</option><option value="KOHAT ENCLAVE">KOHAT ENCLAVE</option><option value="LAJPAT NAGAR">LAJPAT NAGAR</option><option value="LAL QUILA">LAL QUILA</option><option value="LAXMI NAGAR">LAXMI NAGAR</option><option value="LOK KALYAN MARG">LOK KALYAN MARG</option><option value="M G ROAD">M G ROAD</option><option value="MADI PUR">MADI PUR</option><option value="MALVIYA NAGAR">MALVIYA NAGAR</option><option value="MANDI HOUSE">MANDI HOUSE</option><option value="MANSAROVAR PARK">MANSAROVAR PARK</option><option value="MAYUR VIHAR-I">MAYUR VIHAR-I</option><option value="MAYUR VIHAR-I EXT">MAYUR VIHAR-I EXT</option><option value="MEWALA MAHARAJPUR">MEWALA MAHARAJPUR</option><option value="MODEL TOWN">MODEL TOWN</option><option value="MOHAN ESTATE">MOHAN ESTATE</option><option value="MOOLCHAND">MOOLCHAND</option><option value="MOTI NAGAR">MOTI NAGAR</option><option value="MUNDKA">MUNDKA</option><option value="NANGLOI">NANGLOI</option><option value="NANGLOI RLY. STATION">NANGLOI RLY. STATION</option><option value="NAWADA">NAWADA</option><option value="NEELAM CHOWK AJRONDA">NEELAM CHOWK AJRONDA</option><option value="NEHRU PLACE">NEHRU PLACE</option><option value="NETAJI SUBHASH PLACE">NETAJI SUBHASH PLACE</option><option value="NEW ASHOK NAGAR">NEW ASHOK NAGAR</option><option value="NEW DELHI">NEW DELHI</option><option value="NHPC CHOWK">NHPC CHOWK</option><option value="NIRMAN VIHAR">NIRMAN VIHAR</option><option value="NOIDA CITY CENTRE">NOIDA CITY CENTRE</option><option value="NOIDA SEC 15">NOIDA SEC 15</option><option value="NOIDA SEC 16">NOIDA SEC 16</option><option value="NOIDA SEC 18">NOIDA SEC 18</option><option value="NSIC OKHLA">NSIC OKHLA</option><option value="OKHLA">OKHLA</option><option value="OKHLA BIRD SANCTUARY">OKHLA BIRD SANCTUARY</option><option value="OKHLA VIHAR">OKHLA VIHAR</option><option value="OLD FARIDABAD">OLD FARIDABAD</option><option value="PASCHIM VIHAR (EAST)">PASCHIM VIHAR (EAST)</option><option value="PASCHIM VIHAR (WEST)">PASCHIM VIHAR (WEST)</option><option value="PATEL CHOWK">PATEL CHOWK</option><option value="PATEL NAGAR">PATEL NAGAR</option><option value="PEERA GARHI">PEERA GARHI</option><option value="PITAM PURA">PITAM PURA</option><option value="PRAGATI MAIDAN">PRAGATI MAIDAN</option><option value="PRATAP NAGAR">PRATAP NAGAR</option><option value="PREET VIHAR">PREET VIHAR</option><option value="PUL BANGASH">PUL BANGASH</option><option value="PUNJABI BAGH">PUNJABI BAGH</option><option value="QUTAB MINAR">QUTAB MINAR</option><option value="RAJDHANI PARK">RAJDHANI PARK</option><option value="RAJENDRA PLACE">RAJENDRA PLACE</option><option value="RAJIV CHOWK">RAJIV CHOWK</option><option value="RAJOURI GARDEN">RAJOURI GARDEN</option><option value="RAMESH NAGAR">RAMESH NAGAR</option><option value="RITHALA">RITHALA</option><option value="RK ASHRAM MARG">RK ASHRAM MARG</option><option value="ROHINI EAST">ROHINI EAST</option><option value="ROHINI SECTOR 18,19">ROHINI SECTOR 18,19</option><option value="ROHINI WEST">ROHINI WEST</option><option value="SAKET">SAKET</option><option value="SAMAYPUR BADLI">SAMAYPUR BADLI</option><option value="SARAI">SARAI</option><option value="SARITA VIHAR">SARITA VIHAR</option><option value="SATGURU RAM SINGH MARG">SATGURU RAM SINGH MARG</option><option value="SECTOR-28">SECTOR-28</option><option value="SEELAMPUR">SEELAMPUR</option><option value="SHADIPUR">SHADIPUR</option><option value="SHAHDARA">SHAHDARA</option><option value="SHASTRI NAGAR">SHASTRI NAGAR</option><option value="SHASTRI PARK">SHASTRI PARK</option><option value="SHIVAJI PARK">SHIVAJI PARK</option><option value="SHIVAJI STADIUM">SHIVAJI STADIUM</option><option value="SIKANDARPUR">SIKANDARPUR</option><option value="SUBHASH NAGAR">SUBHASH NAGAR</option><option value="SUKHDEV VIHAR">SUKHDEV VIHAR</option><option value="SULTANPUR">SULTANPUR</option><option value="SURAJMAL STADIUM">SURAJMAL STADIUM</option><option value="TAGORE GARDEN">TAGORE GARDEN</option><option value="TILAK NAGAR">TILAK NAGAR</option><option value="TIS HAZARI">TIS HAZARI</option><option value="TUGHLAKABAD">TUGHLAKABAD</option><option value="UDYOG BHAWAN">UDYOG BHAWAN</option><option value="UDYOG NAGAR">UDYOG NAGAR</option><option value="UTTAM NAGAR EAST">UTTAM NAGAR EAST</option><option value="UTTAM NAGAR WEST">UTTAM NAGAR WEST</option><option value="VAISHALI">VAISHALI</option><option value="VIDHAN SABHA">VIDHAN SABHA</option><option value="VISHWAVIDYALAYA">VISHWAVIDYALAYA</option><option value="WELCOME">WELCOME</option><option value="YAMUNA BANK">YAMUNA BANK</option>					</select>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" value="Sign Up" />
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<!-- OPEN UPLOAD CSS FILE -->
<link rel="stylesheet" type="text/css" href="dist/css/openUpload.css">

<!-- OPEN UPLOAD BUTTON -->
<div href="#" id="open-upload-button" class="btn btn-circle btn-primary" data-toggle="modal" data-target="#openUpload">
	+ &nbsp;upload
</div>

<!-- OPEN UPLOAD MODAL -->
<div class="modal fade" id="openUpload" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<div class="container" style="padding:0;">
				<span class="close" type="button" data-dismiss="modal" aria-label="Close"><span style="vertical-align: text-top;" aria-hidden="true" class="glyphicon glyphicon-menu-left"></span></span>
				<h2 class="modal-title" style="display: inline-block;">&nbsp;&nbsp;Upload and Share</h2>
			</div>
		</div>
		
		<div class="modal-body container">
			<p>Upload your study material and be a helping hand to your buddies out there.</p>
			<br/>
			<div style="display:none;">
				<span id="uploadpercentage"></span>
				<div class="progress">
				    <div style="background:#000;" class="bar"></div >
				    <div class="percent">0%</div >
				</div>
				<div id="status"></div>
			</div>
			  <progress id="progressBar" value="0" max="100" style="width:100%; transition:.2s ease-in-out; display:none"></progress>
			  <h3 id="status"></h3>
			  <p id="loaded_n_total"></p>
			  
			  <!--<div id="bar_blank">
			   <div id="bar_color"></div>
			  </div>
			  <div id="status"></div>-->
			
			<form action="open_upload_request.php" enctype="multipart/form-data" method="post" class="form-horizontal" id="open-upload-form">
			           <!--<input type="hidden" value="open-upload-form"
    name="PHP_SESSION_UPLOAD_PROGRESS">-->

			        <div class="form-group container row">
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios1" value="notes" required>
			            <label class="form-check-label" for="exampleRadios1">
			              Notes
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios2" value="practicalfiles" required>
			            <label class="form-check-label" for="exampleRadios2">
			              Practical Files
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios3" value="questionpapers" required>
			            <label class="form-check-label" for="exampleRadios3">
			              Question Papers
			            </label>
			          </div>
			          <div class="form-check col-xs-3 text-center">
			            <input class="form-check-input" type="radio" name="category" id="exampleRadios4" value="ebooks" required>
			            <label class="form-check-label" for="exampleRadios4">
			              eBooks
			            </label>
			          </div>
			        </div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Attach file</label>
					<div class="col-sm-10">
						<input required type="file" class="form-control" placeholder="" name="file" accept=".pdf,.doc,.docx,.rtf,.ppt,.pptx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" >
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Topic</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Topic" name="topic">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-2 control-label" for="">Subject</label>
					<div class="col-sm-10">
						<input required type="text" class="form-control" placeholder="Subject" name="subject" id="subject" autocomplete="off">
						<div id="subjectList"></div>
					</div>
				</div>
			        <div class="form-group">
			          <label class="col-sm-2 control-label" for="">Credits</label>
			          <div class="col-sm-10">
			            <input required type="text" class="form-control" placeholder="Your Name" name="credit">
			          </div>
			        </div>
			
				<div class="col-sm-offset-2">
					<input type="submit" class="btn btn-primary" value="Upload :)" onSubmit="uploadFile();">
				</div>
			</form>
		</div>
		
	</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
 $(document).ready(function(){
	  $('#subject').keyup(function(e){
	  	var code= e.keycode | e.which;
	  	//alert(code);
	  	if(code!=38&&code!==40) { 
	  	//var e= $.Event('keyup'); e.which=code; $("#subject").trigger(e); 
		   var query = $(this).val();
		   if(query != '')
		   {
				$.ajax({
					 url:"subject_autocomplete.php",
					 method:"POST",
					 data:{query:query},
					 success:function(data)
					 {
						  $('#subjectList').fadeIn();
						  $('#subjectList').html(data);
					 }
				});
		   }else if(query == ''){
			$('#subjectList').fadeOut();
		   }
	  }
	  });
	  
	  $(document).on('click', '.list-group-item', function(){
		   $('#subject').val($(this).text());
		   $('#subjectList').fadeOut();
	  });
 });

</script>

<!--<script>

//Upload Progress bar
/*function toggleBarVisibility() {
    var e = document.getElementById("bar_blank");
   // e.style.display = (e.style.display == "block") ? "none" : "block";
}

function createRequestObject() {
    var http;
    if (navigator.appName == "Microsoft Internet Explorer") {
        http = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else {
        http = new XMLHttpRequest();
    }
    return http;
}

function sendRequest() {
    var http = createRequestObject();
    http.open("GET", "progress.php");
    http.onreadystatechange = function () { handleResponse(http); };
    http.send(null);
}

function handleResponse(http) {
    var response;
    if (http.readyState == 4) {
        response = http.responseText;
        alert("Response"+response);
        document.getElementById("bar_color").style.width = response + "%";
        document.getElementById("status").innerHTML = response + "%";

        if (response < 100) {
            setTimeout("sendRequest()", 1000);
        }
        else {
            toggleBarVisibility();
            document.getElementById("status").innerHTML = "Done.";
        }
    }
}

function startUpload() {
    toggleBarVisibility();
    setTimeout("sendRequest()", 1000);
}

(function () {
    document.getElementById("open-upload-form").onsubmit = startUpload;
})();*/
</script>-->

<script>

//FETCHING FILE UPLOAD PERCENTAGE 
function get(el) {
  return document.getElementById(el);
}

function uploadFile() {
  var file = $('input[name="file"]')[0].files[0];
  var title = $('input[name="title"]');
  var subject = $('input[name="subject"]');
  var credit = $('input[name="credit"]');
  var category = $('input[name="category"]');
  // alert(file.name+" | "+file.size+" | "+file.type);
  var formdata = new FormData();
  formdata.append("file", file);
  formdata.append("title", title);
  formdata.append("subject", subject);
  formdata.append("credit", credit);
  formdata.append("category", category);
  var ajax = new XMLHttpRequest();
  ajax.upload.addEventListener("progress", progressHandler, false);
  ajax.addEventListener("load", completeHandler, false);
  ajax.addEventListener("error", errorHandler, false);
  ajax.addEventListener("abort", abortHandler, false);
  ajax.open("POST", "open_upload_request.php");
  ajax.send(formdata);
}

function progressHandler(event) {
$('progress').show();
$('#open-upload-form').fadeOut();
  get("loaded_n_total").innerHTML = Number(event.loaded/event.total*100).toFixed(2) + " % Uploaded ";
  var percent = (event.loaded / event.total) * 100;
  get("progressBar").value = Math.round(percent);
  get("status").innerHTML = Math.round(percent) + "% uploaded... please wait";
}

function completeHandler(event) {
  get("status").innerHTML = event.target.responseText;
  get("progressBar").value = 0;
}

function errorHandler(event) {
  get("status").innerHTML = "Upload Failed";
}

function abortHandler(event) {
  get("status").innerHTML = "Upload Aborted";
}
</script>




     <!-- Bootstrap core JavaScript
     ================================================== -->
     <!-- Placed at the end of the document so the pages load faster -->
     <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="dist/js/bootstrap.min.js"></script>
<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="assets/js/vendor/holder.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="assets/js/ie10-viewport-bug-workaround.js"></script>


<!-- Datatables -->
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="tables/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>


<!--<script>
 $('#internTable').DataTable( {
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.modal( {
                    header: function ( row ) {
                        var data = row.data();
                        return 'Details for internship in '+data[1];
                    }
                } ),
                renderer: $.fn.dataTable.Responsive.renderer.tableAll( {
                    tableClass: 'table'
                } )
            }
        }
    } );
</script>-->

     <!--Banner type text effect , navbar out of focus close -->
     <script src="dist/js/typed.js"></script>
     <script src="dist/js/banner.js"></script>

     <script src="dist/js/sellBooks.js"></script>


     <script type="text/javascript">

               $('#resultsTable').DataTable( {
                "pagingType": "full",
               responsive: true,
               columnDefs: [
                   { responsivePriority: 1, targets: 0 },
                   { responsivePriority: 2, targets: 1 }
               ]
           } );
     </script>




     <script src="dist/js/select2.js"></script>

       <script type="text/javascript">

         $(document).ready(function() {
           $(".semester").select2({
             placeholder: "Select Semester",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".branch").select2({
             placeholder: "Select Branch",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

       <script type="text/javascript">
         $(document).ready(function() {
           $(".subject").select2({
             placeholder: "Select Subject",
    minimumResultsForSearch: -1

             //allowClear: true
           });
         });
       </script>

<!--<script>
      window.fbMessengerPlugins = window.fbMessengerPlugins || {
        init: function () {
          FB.init({
            appId            : '1678638095724206',
            autoLogAppEvents : true,
            xfbml            : true,
            version          : 'v2.10'
          });
        }, callable: []
      };
      window.fbAsyncInit = window.fbAsyncInit || function () {
        window.fbMessengerPlugins.callable.forEach(function (item) { item(); });
        window.fbMessengerPlugins.init();
      };
      setTimeout(function () {
        (function (d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) { return; }
          js = d.createElement(s);
          js.id = id;
          js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      }, 0);
      </script>

      <div
        class="fb-customerchat"
        page_id="910123809127452"
        ref="">
      </div>-->

     </body>
     </html>
