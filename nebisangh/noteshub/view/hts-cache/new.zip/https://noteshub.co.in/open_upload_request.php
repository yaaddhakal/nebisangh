<script>alert('Fill Required Fields');window.open('search.php','_self');</script>
