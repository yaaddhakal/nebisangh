<?php
$s="sanzok";
$salt=""
echo sha1($salt.$s);