<div class="clearfix">
</div>
<div class="footer">
		<div class="container">
			<div class="col-md-4 footer-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
				<h4>About NSU</h4>
				<p>NSU LEC is a association work for the student to get the benifit as their requirements</p>
				<img src="images/t4.jpg" class="img-responsive" alt="">
					<div class="bht1">
						
					</div>
			</div>
			<div class="col-md-4 footer-middle wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
			<h4>NSU LEC</h4>
			<div class="mid-btm">
				<p>NSU LEC was formally started in 2064 BS to fight for the student. We respect our elder to support to make NSU a best student friendly environment in the college </p>
			</div>
			
				
				
		
			</div>
			<div class="col-md-4 footer-right wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
				<h4>About Developer</h4>
				<p>This site has been developed by Sanjok Gyawali and supported by Milan Khadka Sunar.</p><p> Contact 
				Sanjok Gyawali:- 9812927525</p><p>Milan Khadka:- 9800790249</p>
						
						
							<div class="clearfix"> </div>
					
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="copyright wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
				<div class="container">
					<p>© Developed by Sanjok Gyawali and Supported by Milan Khadka Sunar Diploma Batch 2072</p>
				</div>
			</div>